#include "gfx.hpp"
#include "binary.hpp"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <malloc.h>
#include <new>

#include <pspdisplay.h>
#include <pspgu.h>
#include <pspkernel.h>
#include <zlib.h>

namespace badminton {
namespace {

constexpr int Width = 480;
constexpr int Height = 272;
constexpr int BufferWidth = 512;
constexpr int BufferBytes = BufferWidth * Height * 4;
constexpr float Scale = Height / 426.f;
constexpr float Left = (Width - 640.f * Scale) / 2;
constexpr unsigned Budget = 9U * 1024 * 1024;
constexpr unsigned ResidentBankBudget = 4U * 1024 * 1024;
constexpr std::uint32_t Gold = 0xff57deff;
constexpr int VertexFormat = GU_TEXTURE_32BITF | GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D;
alignas(64) std::uint32_t displayList[32768];

struct TextureVertex {
    float u, v;
    std::uint32_t color;
    float x, y, z;
};
struct ColorVertex {
    std::uint32_t color;
    float x, y, z;
};

bool powerOfTwo(int size) { return size >= 4 && size <= 512 && (size & (size - 1)) == 0; }

}  // namespace

Graphics::~Graphics() {
    for (auto& texture : textures_) std::free(texture.pixels);
    if (file_) std::fclose(file_);
    if (initialized_) sceGuTerm();
}

bool Graphics::openBank() {
    file_ = std::fopen("data/art.pak", "rb");
    if (!file_ || std::fseek(file_, 0, SEEK_END) != 0) return false;
    const long fileSize = std::ftell(file_);
    if (fileSize < 8 || fileSize > 16 * 1024 * 1024) return false;
    std::rewind(file_);
    std::uint8_t header[8];
    if (std::fread(header, 1, sizeof(header), file_) != sizeof(header) || std::memcmp(header, "SFB2", 4)) return false;
    const auto count = read32(header + 4);
    if (count == 0 || count > 2048) return false;
    textures_.resize(count);
    bankStart_ = 8 + 52 * count;
    std::uint32_t expected = bankStart_;
    for (std::size_t i = 0; i < count; ++i) {
        std::uint8_t record[52];
        if (std::fread(record, 1, sizeof(record), file_) != sizeof(record)) return false;
        auto& t = textures_[i];
        if (!std::memchr(record, 0, 32)) return false;
        std::memcpy(t.key, record, 32);
        if (i && std::strcmp(t.key, textures_[i - 1].key) <= 0) return false;
        t.x = static_cast<std::int16_t>(read16(record + 32));
        t.y = static_cast<std::int16_t>(read16(record + 34));
        t.width = read16(record + 36);
        t.height = read16(record + 38);
        t.stride = read16(record + 40);
        t.rows = read16(record + 42);
        t.offset = read32(record + 44);
        t.length = read32(record + 48);
        if (!powerOfTwo(t.stride) || !powerOfTwo(t.rows) || t.width <= 0 || t.width > t.stride ||
            t.height <= 0 || t.height > t.rows || t.offset != expected ||
            t.offset > static_cast<std::uint32_t>(fileSize) || t.length == 0 ||
            t.length > static_cast<std::uint32_t>(fileSize) - t.offset) return false;
        expected += t.length;
    }
    if (expected != static_cast<std::uint32_t>(fileSize)) return false;

    // Keep the compressed art in RAM so new animation frames never seek the Memory Stick.
    const auto bankBytes = expected - bankStart_;
    if (bankBytes <= ResidentBankBudget) {
        bank_.reset(new (std::nothrow) std::uint8_t[bankBytes]);
        if (bank_) {
            if (std::fread(bank_.get(), 1, bankBytes, file_) != bankBytes) return false;
            std::fclose(file_);
            file_ = nullptr;
        }
    }
    constexpr const char* faces[]{"text", "digits", "selection"};
    for (std::size_t face = 0; face < fonts_.size(); ++face) {
        for (unsigned c = 0; c < fonts_[face].size(); ++c) {
            char key[32];
            std::snprintf(key, sizeof(key), "%s/%u", faces[face], c);
            fonts_[face][c] = findTexture(key);
        }
    }
    return true;
}

bool Graphics::start() {
    if (!openBank()) return false;
    sceGuInit();
    initialized_ = true;
    sceGuStart(GU_DIRECT, displayList);
    sceGuDrawBuffer(GU_PSM_8888, nullptr, BufferWidth);
    sceGuDispBuffer(Width, Height, reinterpret_cast<void*>(BufferBytes), BufferWidth);
    sceGuOffset(2048 - Width / 2, 2048 - Height / 2);
    sceGuViewport(2048, 2048, Width, Height);
    sceGuScissor(0, 0, Width, Height);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuDisable(GU_DEPTH_TEST);
    sceGuDisable(GU_CULL_FACE);
    sceGuDisable(GU_TEXTURE_2D);
    sceGuEnable(GU_BLEND);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);
    sceGuTexMode(GU_PSM_4444, 0, 0, 0);
    sceGuTexFunc(GU_TFX_MODULATE, GU_TCC_RGBA);
    sceGuTexFilter(GU_LINEAR, GU_LINEAR);
    sceGuTexWrap(GU_CLAMP, GU_CLAMP);
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);
    guSwapBuffersBehaviour(PSP_DISPLAY_SETBUF_NEXTVSYNC);
    return true;
}

void Graphics::begin() {
    ++frame_;
    bound_ = nullptr;
    sceGuStart(GU_DIRECT, displayList);
    sceGuScissor(0, 0, Width, Height);
    sceGuClearColor(0xff000000);
    sceGuClear(GU_COLOR_BUFFER_BIT);
    sceGuScissor(static_cast<int>(Left), 0, Width - static_cast<int>(Left), Height);
}

std::uint32_t Graphics::finish() {
    sceGuFinish();
    sceGuSync(0, 0);
    const auto ready = sceKernelGetSystemTimeLow();
    // Queue the completed image for the next refresh before waiting to reuse the old buffer.
    sceGuSwapBuffers();
    sceDisplayWaitVblankStart();
    return ready;
}

void Graphics::preload(const char* prefix) {
    const auto length = std::strlen(prefix);
    // Validated sorted keys keep all prefix matches contiguous and in load order.
    auto texture = std::lower_bound(textures_.begin(), textures_.end(), prefix,
        [](const auto& t, const char* name) { return std::strcmp(t.key, name) < 0; });
    for (; texture != textures_.end() && std::strncmp(texture->key, prefix, length) == 0; ++texture) {
        loadTexture(*texture);
    }
}

Graphics::Texture* Graphics::findTexture(const char* key) {
    const auto match = std::lower_bound(textures_.begin(), textures_.end(), key, [](const auto& t, const char* name) {
        return std::strcmp(t.key, name) < 0;
    });
    if (match == textures_.end() || std::strcmp(match->key, key)) return nullptr;
    return &*match;
}

bool Graphics::loadTexture(Texture& t) {
    t.used = frame_;
    if (t.pixels) return true;

    const unsigned bytes = static_cast<unsigned>(t.stride * t.rows * 2);
    while (allocated_ + bytes > Budget) {
        Texture* oldest = nullptr;
        for (auto& entry : textures_) {
            if (entry.pixels && entry.used < frame_ && (!oldest || entry.used < oldest->used)) oldest = &entry;
        }
        if (!oldest) return false;
        allocated_ -= static_cast<unsigned>(oldest->stride * oldest->rows * 2);
        std::free(oldest->pixels);
        oldest->pixels = nullptr;
    }
    const std::uint8_t* source;
    if (bank_) {
        source = bank_.get() + (t.offset - bankStart_);
    } else {
        compressed_.resize(t.length);
        if (std::fseek(file_, static_cast<long>(t.offset), SEEK_SET) != 0 ||
            std::fread(compressed_.data(), 1, t.length, file_) != t.length) return false;
        source = compressed_.data();
    }
    auto* pixels = memalign(64, bytes);
    if (!pixels) return false;
    uLongf raw = bytes;
    if (uncompress(static_cast<Bytef*>(pixels), &raw, source, t.length) != Z_OK || raw != bytes) {
        std::free(pixels);
        return false;
    }
    sceKernelDcacheWritebackRange(pixels, bytes);
    t.pixels = pixels;
    allocated_ += bytes;
    return true;
}

void Graphics::sprite(const char* key, float x, float y, bool flip, float rotation, float scale, std::uint32_t color) {
    if (auto* texture = findTexture(key)) sprite(*texture, x, y, flip, rotation, scale, color);
}

void Graphics::sprite(Texture& t, float x, float y, bool flip, float rotation, float scale, std::uint32_t color) {
    if (!(color >> 24) || !loadTexture(t)) return;
    if (!textured_) {
        sceGuEnable(GU_TEXTURE_2D);
        textured_ = true;
    }
    if (bound_ != &t) {
        sceGuTexImage(0, t.stride, t.rows, t.stride, t.pixels);
        bound_ = &t;
    }

    const auto width = static_cast<float>(t.width);
    const auto height = static_cast<float>(t.height);
    const float centerX = Left + x * Scale;
    const float centerY = y * Scale;
    const float scaleX = flip ? -scale : scale;
    if (rotation == 0 && scale > 0) {
        const float u0 = flip ? width : 0;
        const float u1 = flip ? 0 : width;
        auto* vertices = static_cast<TextureVertex*>(sceGuGetMemory(sizeof(TextureVertex) * 2));
        vertices[0] = {u0, 0, color, centerX + (t.x + u0) * scaleX, centerY + t.y * scale, 0};
        vertices[1] = {u1, height, color, centerX + (t.x + u1) * scaleX, centerY + (t.y + height) * scale, 0};
        sceGuDrawArray(GU_SPRITES, VertexFormat, 2, nullptr, vertices);
        return;
    }

    const float cosine = std::cos(rotation * 0.01745329252f);
    const float sine = std::sin(rotation * 0.01745329252f);
    auto* vertices = static_cast<TextureVertex*>(sceGuGetMemory(sizeof(TextureVertex) * 4));
    for (int i = 0; i < 4; ++i) {
        const float u = i & 1 ? width : 0;
        const float v = i & 2 ? height : 0;
        const float tx = (t.x + u) * scaleX;
        const float ty = (t.y + v) * scale;
        vertices[i] = {u, v, color, centerX + tx * cosine - ty * sine, centerY + tx * sine + ty * cosine, 0};
    }
    sceGuDrawArray(GU_TRIANGLE_STRIP, VertexFormat, 4, nullptr, vertices);
}

void Graphics::text(const char* words, float x, float y, float scale, bool centered, std::uint32_t color, Font face) {
    if (!(color >> 24)) return;
    const auto& font = fonts_[static_cast<std::size_t>(face)];
    const auto* first = reinterpret_cast<const unsigned char*>(words);
    const auto advance = [&](const Texture* glyph) { return (glyph ? glyph->width + 1 : 5) * scale / Scale; };
    if (centered) {
        float width = 0;
        for (const auto* p = first; *p; ++p) width += advance(font[*p]);
        x -= width * 0.5f;
    }
    for (const auto* p = first; *p; ++p) {
        auto* glyph = font[*p];
        if (glyph) sprite(*glyph, x, y, false, 0, scale, color);
        x += advance(glyph);
    }
}

void Graphics::rect(float x, float y, float w, float h, std::uint32_t color) {
    auto* v = static_cast<ColorVertex*>(sceGuGetMemory(sizeof(ColorVertex) * 2));
    v[0] = {color, Left + x * Scale, y * Scale, 0};
    v[1] = {color, Left + (x + w) * Scale, (y + h) * Scale, 0};
    if (textured_) {
        sceGuDisable(GU_TEXTURE_2D);
        textured_ = false;
    }
    sceGuDrawArray(GU_SPRITES, GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D, 2, nullptr, v);
}

void Graphics::focus(float x, float y, float w, float h) {
    rect(x, y, w, 2, Gold);
    rect(x, y + h - 2, w, 2, Gold);
    rect(x, y, 2, h, Gold);
    rect(x + w - 2, y, 2, h, Gold);
}

}  // namespace badminton
