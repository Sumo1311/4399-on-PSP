#include "audio.hpp"
#include "binary.hpp"
#include "controller.hpp"
#include "game.hpp"
#include "link.hpp"
#include "save.hpp"
#include "stage_data.hpp"
#include "story.hpp"
#ifdef ELF_STORY_QA
#include "replay.hpp"
#endif

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <malloc.h>
#include <memory>
#include <utility>
#include <vector>

#include <pspctrl.h>
#include <pspdebug.h>
#include <pspdisplay.h>
#include <pspgu.h>
#include <pspkernel.h>
#include <psppower.h>
#include <psprtc.h>
#include <zlib.h>

PSP_MODULE_INFO("Elf Story", PSP_MODULE_USER, 1, 0);
PSP_MAIN_THREAD_ATTR(PSP_THREAD_ATTR_USER | PSP_THREAD_ATTR_VFPU);
PSP_HEAP_SIZE_KB(16 * 1024);

namespace {

constexpr int ScreenWidth = 480;
constexpr int ScreenHeight = 272;
constexpr int BufferWidth = 512;
constexpr int BufferBytes = BufferWidth * ScreenHeight * 4;
constexpr float Scale = static_cast<float>(ScreenHeight) / elf::source::ViewHeight;
constexpr float StageLeft = (ScreenWidth - elf::source::ViewWidth * Scale) * 0.5F;
constexpr int MaxTiles = 256;
constexpr int MaxTextureSize = 512;
constexpr std::size_t BankLimit = 10 * 1024 * 1024;
constexpr int EnemyAnchorX = 384;
constexpr int EnemyAnchorY = 400;
constexpr int FeedbackAnchorX = 256;
constexpr int FeedbackAnchorY = 128;
constexpr std::size_t TextureRecordSize = 18;
using elf::read16;
using elf::read32;

alignas(64) std::uint32_t displayList[32768];

struct FileCloser {
    void operator()(std::FILE* file) const { std::fclose(file); }
};

struct FreePixels {
    void operator()(std::uint8_t* pixels) const { std::free(pixels); }
};

struct Texture {
    int group;
    int x;
    int y;
    int width;
    int height;
    int stride;
    int rows;
    std::unique_ptr<std::uint8_t, FreePixels> pixels;
};

bool validDimension(int size) {
    return size >= 4 && size <= MaxTextureSize && (size & (size - 1)) == 0;
}

Texture textureInfo(const std::uint8_t* record) {
    return {read16(record), read16(record + 2), read16(record + 4), read16(record + 6),
            read16(record + 8), read16(record + 10), read16(record + 12), {}};
}

std::size_t textureBytes(const Texture& tile) {
    return static_cast<std::size_t>(tile.stride) * static_cast<std::size_t>(tile.rows) * 2;
}

bool validTexture(const Texture& tile, std::uint32_t packed) {
    return validDimension(tile.stride) && validDimension(tile.rows) &&
        tile.width > 0 && tile.width <= tile.stride && tile.height > 0 && tile.height <= tile.rows &&
        packed > 0 && packed <= compressBound(textureBytes(tile));
}

bool decodeTexture(Texture& tile, const std::uint8_t* input, std::uint32_t packed) {
    const std::size_t bytes = textureBytes(tile);
    tile.pixels.reset(static_cast<std::uint8_t*>(memalign(64, bytes)));
    if (!tile.pixels) {
        return false;
    }
    uLongf length = bytes;
    if (uncompress(tile.pixels.get(), &length, input, packed) != Z_OK || length != bytes) {
        return false;
    }
    sceKernelDcacheWritebackRange(tile.pixels.get(), bytes);
    return true;
}

class ArtBank {
public:
    bool load(const char* path, std::uint32_t skillMask = 0) {
        const std::unique_ptr<std::FILE, FileCloser> file(std::fopen(path, "rb"));
        std::uint8_t header[8];
        if (!file || std::fread(header, 1, sizeof(header), file.get()) != sizeof(header) ||
            std::memcmp(header, "ESAP", 4) != 0 || read16(header + 4) != 1) {
            return false;
        }

        const int count = read16(header + 6);
        if (count < 1 || count > MaxTiles) {
            return false;
        }
        std::size_t total = 0;
        std::vector<Texture> decoded;
        decoded.reserve(static_cast<std::size_t>(count));
        std::vector<std::uint8_t> input;
        for (int index = 0; index < count; ++index) {
            std::uint8_t record[TextureRecordSize];
            if (std::fread(record, 1, sizeof(record), file.get()) != sizeof(record)) {
                return false;
            }
            auto tile = textureInfo(record);
            const std::uint32_t packed = read32(record + 14);
            if (!validTexture(tile, packed)) {
                return false;
            }
            input.resize(packed);
            if (std::fread(input.data(), 1, packed, file.get()) != packed) {
                return false;
            }
            if (skillMask != 0) {
                const int kind = tile.group / 32;
                if (kind >= 32) {
                    return false;
                }
                if ((skillMask & (1U << kind)) == 0) {
                    continue;
                }
            }
            total += textureBytes(tile);
            if (total > BankLimit || !decodeTexture(tile, input.data(), packed)) {
                return false;
            }
            decoded.push_back(std::move(tile));
        }

        if (std::fgetc(file.get()) != EOF) {
            return false;
        }
        tiles_ = std::move(decoded);
        return true;
    }

    const std::vector<Texture>& tiles() const { return tiles_; }

private:
    std::vector<Texture> tiles_;
};

struct InterfaceArt {
    ArtBank hints, titlePanels, pausePanel;

    bool update(const elf::Game& game) {
        const auto screen = game.screen();
        const bool showPanel = screen == elf::Screen::Help || screen == elf::Screen::Credits ||
            screen == elf::Screen::Bindings;
        if (!showPanel && !titlePanels.tiles().empty()) {
            titlePanels = {};
        }
        if (!game.paused() && !pausePanel.tiles().empty()) {
            pausePanel = {};
        }
        return (!showPanel || !titlePanels.tiles().empty() || titlePanels.load("data/art/title_panels.pak")) &&
            (!game.paused() || !pausePanel.tiles().empty() || pausePanel.load("data/art/pause_panel.pak"));
    }
};

struct InputDisplay {
    const InterfaceArt& art;
    const elf::PadBindings& keys;
    const elf::BindingEditor& editor;
    int localRole;
};

int effectGroup(const elf::Effect& effect) {
    return effect.light == elf::Light::None ? -1 : static_cast<int>(effect.light) * 128 + effect.frame;
}

// Keep timeline frames compressed and decode the active frame in each slot.
template<std::size_t SlotCount>
class FrameArt {
public:
    bool load(const char* path) {
        const std::unique_ptr<std::FILE, FileCloser> file(std::fopen(path, "rb"));
        if (!file || std::fseek(file.get(), 0, SEEK_END) != 0) {
            return false;
        }
        const long size = std::ftell(file.get());
        if (size < 8 || size > 2 * 1024 * 1024 || std::fseek(file.get(), 0, SEEK_SET) != 0) {
            return false;
        }
        bytes_.resize(static_cast<std::size_t>(size));
        if (std::fread(bytes_.data(), 1, bytes_.size(), file.get()) != bytes_.size() ||
            std::memcmp(bytes_.data(), "ESAP", 4) != 0 || read16(bytes_.data() + 4) != 1) {
            return false;
        }
        const int count = read16(bytes_.data() + 6);
        if (count == 0 || count > 1024) {
            return false;
        }
        index_.reserve(static_cast<std::size_t>(count));
        std::size_t at = 8;
        int previousGroup = 0;
        for (int i = 0; i < count; ++i) {
            if (bytes_.size() - at < TextureRecordSize) {
                return false;
            }
            const auto* record = bytes_.data() + at;
            const auto tile = textureInfo(record);
            const auto packed = read32(record + 14);
            if (tile.group < previousGroup || !validTexture(tile, packed) ||
                packed > bytes_.size() - at - TextureRecordSize) {
                return false;
            }
            index_.push_back({tile.group, at});
            previousGroup = tile.group;
            at += TextureRecordSize + packed;
        }
        return at == bytes_.size();
    }

    bool loaded() const { return !index_.empty(); }
    const std::vector<Texture>& tiles(std::size_t index) const { return slots_[index].tiles; }

    void clear() {
        for (Slot& slot : slots_) {
            slot = {};
        }
    }

    bool select(std::size_t index, int group) {
        Slot& slot = slots_[index];
        if (slot.group == group) {
            return true;
        }
        slot.tiles.clear();
        slot.group = group;
        if (group < 0) {
            return true;
        }
        auto tileAt = std::lower_bound(index_.begin(), index_.end(), group,
            [](const Record& record, int requested) { return record.group < requested; });
        for (; tileAt != index_.end() && tileAt->group == group; ++tileAt) {
            const auto* record = bytes_.data() + tileAt->offset;
            auto tile = textureInfo(record);
            if (!decodeTexture(tile, record + TextureRecordSize, read32(record + 14))) {
                return false;
            }
            slot.tiles.push_back(std::move(tile));
        }
        return true;
    }

private:
    struct Record { int group; std::size_t offset; };
    struct Slot { int group = -1; std::vector<Texture> tiles; };

    std::vector<std::uint8_t> bytes_;
    std::vector<Record> index_;
    std::array<Slot, SlotCount> slots_;
};

class PlayerArt {
public:
    enum Layer { Shield, Body, Armor, Sword, Dual, Count };

    bool update(const elf::Player& player) {
        constexpr const char* prefixes[] = {"s", "body", "d", "ws", "wd"};
        const auto& stats = player.progress;
        const auto& gear = stats.gear;
        const int wanted[] = {gear.shield, stats.role, gear.armor, gear.sword, gear.dualSwords};
        const int pose = player.body.pose;
        for (int layer = 0; layer < Count; ++layer) {
            if ((stats.dualWield && (layer == Shield || layer == Sword)) ||
                (!stats.dualWield && layer == Dual)) {
                continue;
            }
            if (loaded_[layer] != wanted[layer]) {
                char path[40];
                std::snprintf(path, sizeof(path), "data/art/gear/%s%02d.pak", prefixes[layer], wanted[layer]);
                banks_[layer] = {};
                if (!banks_[layer].load(path)) {
                    return false;
                }
                loaded_[layer] = wanted[layer];
            }
            if (!banks_[layer].select(poseSlot(pose), pose)) {
                return false;
            }
        }
        return true;
    }

    const std::vector<Texture>& tiles(Layer layer, int pose) const {
        return banks_[layer].tiles(poseSlot(pose));
    }

private:
    static std::size_t poseSlot(int pose) { return static_cast<std::size_t>(pose) % 4; }

    std::array<int, Count> loaded_{};
    std::array<FrameArt<4>, Count> banks_;
};

class EffectArt : public FrameArt<10> {
public:
    static constexpr std::size_t WorldOffset = 6;

    bool update(const elf::Game& game) {
        for (int index = 0; index < game.playerCount(); ++index) {
            const auto& actor = game.participant(index);
            const auto slot = static_cast<std::size_t>(index) * 3;
            if (!select(slot, effectGroup(actor.attackEffect)) || !select(slot + 1, effectGroup(actor.levelEffect)) ||
                !select(slot + 2, effectGroup(actor.petEffect))) {
                return false;
            }
        }
        for (std::size_t i = 0; i < game.worldEffects().size(); ++i) {
            if (!select(WorldOffset + i, effectGroup(game.worldEffects()[i]))) {
                return false;
            }
        }
        return true;
    }
};

constexpr int FirstStreamedSpell = 15;
constexpr int PetSeedFrames = 6;
constexpr int PetFlameFrames = 15;

std::size_t petSpellSlot(const elf::Skill& skill) {
    return static_cast<std::size_t>(skill.pose - 1 + (skill.kind == FirstStreamedSpell ? 0 : PetSeedFrames));
}

class CompanionArt {
public:
    bool update(const elf::Player& owner) {
        const auto& pet = owner.progress.pet;
        const int index = pet.kind == 0 || owner.pet.removed ? 0 : pet.artIndex();
        if (actorIndex_ != index) {
            actor = {};
            if (index != 0) {
                char path[32];
                std::snprintf(path, sizeof(path), "data/art/pet%d%d.pak", pet.kind, pet.form());
                if (!actor.load(path)) {
                    return false;
                }
            }
            actorIndex_ = index;
        }
        return actor.select(0, index == 0 ? -1 : owner.pet.pose);
    }

    FrameArt<1> actor;

private:
    int actorIndex_ = 0;
};

class PartyArt {
public:
    bool update(const elf::Game& game) {
        if (hud.tiles().empty() && !hud.load("data/art/pet_hud.pak")) {
            return false;
        }
        if (game.mode() == elf::Mode::Coop && coopHud.tiles().empty() && !coopHud.load("data/art/coop_hud.pak")) {
            return false;
        }
        for (int index = 0; index < game.playerCount(); ++index) {
            const auto slot = static_cast<std::size_t>(index);
            const auto& actor = game.participant(index);
            if ((!actor.body.removed && !actors[slot].update(actor)) ||
                !companions[slot].update(actor) || !updateTip(slot, actor)) {
                return false;
            }
        }
        // Both companions can display the same frame. Decode it once for all casts.
        std::array<int, PetSeedFrames + PetFlameFrames> wanted;
        wanted.fill(-1);
        for (const auto& skill : game.skills()) {
            if (skill.kind >= FirstStreamedSpell) {
                if (!magic.loaded() && !magic.load("data/art/pet_magic.pak")) {
                    return false;
                }
                wanted[petSpellSlot(skill)] = skill.kind * 32 + skill.pose;
            }
        }
        for (std::size_t i = 0; i < wanted.size(); ++i) {
            if (!magic.select(i, wanted[i])) {
                return false;
            }
        }
        return true;
    }

    ArtBank hud, coopHud;
    std::array<PlayerArt, 2> actors;
    std::array<CompanionArt, 2> companions;
    std::array<FrameArt<1>, 2> tips;
    FrameArt<PetSeedFrames + PetFlameFrames> magic;

private:
    bool updateTip(std::size_t index, const elf::Player& player) {
        auto& art = tips[index];
        if (tipKinds_[index] != player.tip) {
            art = {};
            if (player.tip != elf::Tip::None) {
                char path[32];
                std::snprintf(path, sizeof(path), "data/art/tip%u_%02u.pak",
                              static_cast<unsigned>(index + 1), static_cast<unsigned>(player.tip));
                if (!art.load(path)) {
                    return false;
                }
            }
            tipKinds_[index] = player.tip;
        }
        return art.select(0, player.tip == elf::Tip::None ? -1 : player.tipFrame);
    }

    std::array<elf::Tip, 2> tipKinds_{};
};

class StageArt {
public:
    bool load(int number, const elf::source::Stage& stage) {
        background = {};
        for (ArtBank& bank : enemies) {
            bank = {};
        }
        char path[40];
        std::snprintf(path, sizeof(path), "data/art/level%02d.pak", number);
        if (!background.load(path) || !feedback.load("data/art/feedback.pak")) {
            return false;
        }
        for (int kind = 1; kind <= elf::source::EnemyKindCount; ++kind) {
            if (kind == elf::source::enemy::b7_1 || (stage.enemyMask & (1U << (kind - 1))) == 0) {
                continue;
            }
            std::snprintf(path, sizeof(path), "data/art/foe%02d.pak", kind);
            if (!enemies[kind - 1].load(path)) {
                return false;
            }
        }
        return true;
    }

    const ArtBank& enemy(int kind) const {
        return enemies[(kind == elf::source::enemy::b7_1 ? elf::source::enemy::b7 : kind) - 1];
    }

    void discardUnusedEnemies(const elf::Game& game) {
        std::uint32_t used = 0;
        for (const elf::Enemy& actor : game.enemies()) {
            if (actor.kind != 0 && !actor.body.removed) {
                const int kind = actor.kind == elf::source::enemy::b7_1 ? elf::source::enemy::b7 : actor.kind;
                used |= 1U << (kind - 1);
            }
        }
        for (std::size_t i = 0; i < enemies.size(); ++i) {
            if ((used & (1U << i)) == 0) {
                enemies[i] = {};
            }
        }
    }

    ArtBank background, feedback;
    FrameArt<1> defeat;

private:
    std::array<ArtBank, elf::source::EnemyKindCount> enemies;
};

struct TextureVertex {
    float u, v;
    std::uint32_t color;
    float x, y, z;
};

struct ColorVertex {
    std::uint32_t color;
    float x, y, z;
};

class Renderer {
public:
    void init() {
        sceGuInit();
        sceGuStart(GU_DIRECT, displayList);
        sceGuDrawBuffer(GU_PSM_8888, nullptr, BufferWidth);
        sceGuDispBuffer(ScreenWidth, ScreenHeight, reinterpret_cast<void*>(BufferBytes), BufferWidth);
        sceGuOffset(2048 - ScreenWidth / 2, 2048 - ScreenHeight / 2);
        sceGuViewport(2048, 2048, ScreenWidth, ScreenHeight);
        sceGuEnable(GU_SCISSOR_TEST);
        sceGuDisable(GU_DEPTH_TEST);
        sceGuDisable(GU_CULL_FACE);
        sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);
        sceGuEnable(GU_BLEND);
        sceGuTexMode(GU_PSM_4444, 0, 0, 0);
        sceGuTexFunc(GU_TFX_MODULATE, GU_TCC_RGBA);
        sceGuTexFilter(GU_LINEAR, GU_LINEAR);
        sceGuTexWrap(GU_CLAMP, GU_CLAMP);
        sceGuFinish();
        sceGuSync(0, 0);
        sceDisplayWaitVblankStart();
        sceGuDisplay(GU_TRUE);
    }

    void draw(const elf::Game& game, const ArtBank& menus, const ArtBank& coopRole, const ArtBank& lobby,
              elf::LinkStatus linkStatus, bool joinSelected, const StageArt& level,
              const PartyArt& party, const ArtBank& combat, const ArtBank& skills, const ArtBank& victory,
              const EffectArt& effects, const elf::StoryMovie& story, bool muted, const InputDisplay& input) {
        sceGuStart(GU_DIRECT, displayList);
        sceGuScissor(0, 0, ScreenWidth, ScreenHeight);
        sceGuClearColor(0xff000000);
        sceGuClear(GU_COLOR_BUFFER_BIT);
        sceGuScissor(22, 0, 458, ScreenHeight);

        if (game.screen() == elf::Screen::Stage) {
            stage(game, level, party, combat, skills, victory, effects, input);
            if (game.paused()) {
                drawPause(input);
            }
        } else if (game.screen() == elf::Screen::LinkLobby) {
            image(menus, 1, 0, 0);
            rect(0, 0, elf::source::ViewWidth, elf::source::ViewHeight, 0x66000000);
            image(lobby, 1, 0, 0);
            focus(304, joinSelected ? 285.0F : 211.0F, 352, 58);
            image(lobby, 10 + static_cast<int>(linkStatus), 0, 0);
        } else if (game.screen() == elf::Screen::WorldMap) {
            worldMap(game, menus, input.art.hints, true);
        } else if (game.screen() == elf::Screen::Intro || game.screen() == elf::Screen::Ending) {
            if (game.screen() == elf::Screen::Ending && game.storyFrame() == elf::Game::EndingFrames - 1) {
                image(menus, 1, 0, 0);
            } else {
                worldMap(game, menus, input.art.hints, false);
            }
            drawStory(story);
        } else if (game.screen() == elf::Screen::SelectRole && game.mode() == elf::Mode::Coop) {
            image(menus, 2, 0, 0);
            image(coopRole, input.localRole + 1, 0, 0);
            drawRoleKeys(input, true);
            focus(376, 495, 154, 41);
        } else if (game.screen() == elf::Screen::Bindings || game.screen() == elf::Screen::Help ||
                   game.screen() == elf::Screen::Credits) {
            image(menus, 1, 0, 0);
            if (game.screen() == elf::Screen::Bindings) {
                drawBindings(input);
            } else {
                const int panel = game.screen() == elf::Screen::Help ? game.helpPage() + 1 : 4;
                image(input.art.titlePanels, panel, 0, 0);
            }
        } else {
            int menu = static_cast<int>(game.screen()) + 1;
            if (game.screen() == elf::Screen::NewGame && game.hasSave()) {
                menu = 5;
            }
            image(menus, menu, 0, 0);
            if (game.screen() == elf::Screen::Title) {
                focus(81, 233.0F + static_cast<float>(game.titleChoice()) * 72, 179, 58);
            } else if (game.screen() == elf::Screen::NewGame) {
                const bool continuing = menu == 5 && game.continueSelected();
                focus(81, continuing ? 305.0F : 233.0F, 179, 58);
            } else if (game.screen() == elf::Screen::SelectRole) {
                focus(game.role() == 1 ? 291.0F : 524.0F, 141, 130, 155);
                drawRoleKeys(input, false);
            }
        }
        image(combat, muted ? 331 : 330, 0, 0);

        sceGuFinish();
        sceGuSync(0, 0);
        sceDisplayWaitVblankStart();
        sceGuSwapBuffers();
    }

private:
    void worldMap(const elf::Game& game, const ArtBank& menus, const ArtBank& hints, bool selectable) {
        image(menus, 4, 0, 0);
        for (int number = 1; number <= elf::source::StageCount; ++number) {
            if ((game.unlocked() & (1U << (number - 1))) != 0) {
                image(menus, 5 + number, 0, 0);
            }
        }
        if (selectable) {
            image(hints, 7, 0, 0);
            focusMapNode(menus, 5 + game.mapSelection());
        }
    }

    void padGlyph(const ArtBank& bank, int group, float x, float y) {
        image(bank, group, x - 24, y - 18);
    }

    void bindingGlyph(const ArtBank& bank, const elf::PadBindings& keys, elf::Binding action, float x, float y) {
        const int base = elf::keyGroup(action) == elf::KeyGroup::Shortcuts ? 120 : 100;
        padGlyph(bank, base + static_cast<int>(keys[action]), x, y);
    }

    void drawRoleKeys(const InputDisplay& input, bool coop) {
        struct Position { float x, y; };
        constexpr Position Solo[] = {{272,378},{359,378},{316,336},{316,378},{448,378},{504,378},{565,378},
                                     {419,338},{477,338},{532,338},{598,338},{644,378},{699,378}};
        constexpr Position Coop[] = {{338,205},{425,205},{382,163},{382,205},{514,205},{570,205},{631,205},
                                     {485,166},{543,166},{598,166},{664,166},{710,205},{765,205}};
        const auto& positions = coop ? Coop : Solo;
        const float offset = coop && input.localRole == 1 ? 179 : 0;
        for (std::size_t i = 0; i < std::size(positions); ++i) {
            bindingGlyph(input.art.hints, input.keys, static_cast<elf::Binding>(i),
                         positions[i].x, positions[i].y + offset);
        }
    }

    void drawBindings(const InputDisplay& input) {
        using Editor = elf::BindingEditor;
        const auto& editor = input.editor;
        image(input.art.titlePanels, 5, 0, 0);
        for (int row = 0; row < static_cast<int>(std::size(Editor::Columns)); ++row) {
            const float y = static_cast<float>(176 + row * 101);
            for (int column = 0; column < Editor::Columns[row]; ++column) {
                const float x = static_cast<float>(480 + column * 128 - 64 * (Editor::Columns[row] - 1));
                bindingGlyph(input.art.hints, editor.draft, Editor::Layout[row][column], x, y);
                if (editor.row == row && editor.column == column) {
                    focus(x - 28, y - 22, 56, 44);
                }
            }
        }
        const int group = editor.saveFailed ? 24 : editor.capturing ?
            21 + static_cast<int>(elf::keyGroup(editor.selection())) : 20;
        image(input.art.hints, group, 160, 450);
    }

    void drawPause(const InputDisplay& input) {
        using B = elf::Binding;
        image(input.art.pausePanel, 1, 0, 0);
        constexpr B First[] = {B::Right, B::Right, B::Up, B::Jump, B::Jump, B::Cast, B::Down};
        constexpr B Second[] = {B::Count, B::Attack, B::Attack, B::Attack, B::Count, B::Count, B::Cast};
        for (std::size_t i = 0; i < std::size(First); ++i) {
            const float y = static_cast<float>(172 + 45 * i);
            bindingGlyph(input.art.hints, input.keys, First[i], 390, y);
            if (Second[i] != B::Count) {
                bindingGlyph(input.art.hints, input.keys, Second[i], 497, y);
            }
        }
        for (int i = 0; i < 4; ++i) {
            bindingGlyph(input.art.hints, input.keys, static_cast<B>(static_cast<int>(B::HeavySlash) + i),
                         800, static_cast<float>(172 + 65 * i));
        }
        bindingGlyph(input.art.hints, input.keys, B::Pause, 350, 531);
    }

    void drawStory(const elf::StoryMovie& story) {
        using Movie = elf::StoryMovie;
        sceGuEnable(GU_TEXTURE_2D);
        sceGuTexMode(GU_PSM_8888, 0, 0, 0);
        sceGuTexImage(0, Movie::TextureSize, Movie::TextureSize, Movie::TextureSize, story.pixels());
        sceGuTexFlush();
        auto* vertices = static_cast<TextureVertex*>(sceGuGetMemory(sizeof(TextureVertex) * 2));
        vertices[0] = {0, 0, 0xffffffff, StageLeft, 0, 0};
        vertices[1] = {Movie::Width, Movie::Height, 0xffffffff,
                       StageLeft + elf::source::ViewWidth * Scale, ScreenHeight, 0};
        sceGuDrawArray(GU_SPRITES, GU_TEXTURE_32BITF | GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
                       2, nullptr, vertices);
        sceGuTexMode(GU_PSM_4444, 0, 0, 0);
    }

    static float gauge(int value, int maximum) {
        return static_cast<float>(value) / static_cast<float>(maximum);
    }

    void stage(const elf::Game& game, const StageArt& level, const PartyArt& party,
               const ArtBank& combat, const ArtBank& skills, const ArtBank& victory, const EffectArt& effects,
               const InputDisplay& input) {
        const auto& map = game.stage();
        const float cameraX = static_cast<float>(game.cameraX());
        const float cameraY = static_cast<float>(game.cameraY());
        image(level.background, 1, -cameraX / 5, -cameraY / 5);
        image(level.background, 2, -cameraX, -cameraY);
        if (game.doorOpen()) {
            const int pose = (game.victoryAge() - 79) % 16;
            image(combat, 100 + pose, static_cast<float>(map.exitX) - cameraX - 140,
                  static_cast<float>(map.exitY) - cameraY - 170);
            bindingGlyph(input.art.hints, input.keys, elf::Binding::Up, static_cast<float>(map.exitX) - cameraX + 20,
                         static_cast<float>(map.exitY) - cameraY - 110);
        }
        const elf::Enemy* boss = nullptr;
        for (const elf::Enemy& enemy : game.enemies()) {
            if (enemy.kind == 0 || enemy.body.removed) {
                continue;
            }
            const int alpha = enemy.body.action == elf::Action::Dash && enemy.body.actionAge < 15 ? 0 : 255;
            if (alpha != 0) {
                drawActor(level.enemy(enemy.kind), enemy.body.pose, enemy.body, game, EnemyAnchorX, EnemyAnchorY);
            }
            if (enemy.kind == map.boss && enemy.body.hp > 0) {
                boss = &enemy;
            }
            if (enemy.healthDisplay > 0) {
                const float x = static_cast<float>(enemy.body.x) - cameraX - 20;
                const float y = static_cast<float>(enemy.body.y) - cameraY - (enemy.kind >= elf::source::enemy::b1 ? 180 : 80);
                const int alpha = enemy.healthDisplay * 255 / 50;
                image(combat, 230, x, y, false, 1, alpha);
                image(combat, 231, x, y, false, gauge(enemy.body.hp, enemy.body.maxHp), alpha);
            }
        }
        for (int i = 0; i < game.playerCount(); ++i) {
            const auto index = static_cast<std::size_t>(i);
            const auto& actor = game.participant(i);
            const auto& body = actor.body;
            if (body.action == elf::Action::Dead || body.removed) {
                continue;
            }
            const auto drawLayer = [&](PlayerArt::Layer layer) {
                drawActor(party.actors[index].tiles(layer, body.pose), body.pose, body, game, 125, 161);
            };
            if (!actor.progress.dualWield) {
                drawLayer(PlayerArt::Shield);
            }
            drawLayer(PlayerArt::Body);
            drawLayer(PlayerArt::Armor);
            drawLayer(actor.progress.dualWield ? PlayerArt::Dual : PlayerArt::Sword);
            drawEffect(effects, index * 3, actor.attackEffect, body.x, body.y, body.facingLeft, game);
            drawEffect(effects, index * 3 + 1, actor.levelEffect, body.x, body.y, false, game);
        }
        for (int i = 0; i < game.playerCount(); ++i) {
            const auto index = static_cast<std::size_t>(i);
            const auto& owner = game.participant(i);
            const auto& pet = owner.progress.pet;
            const auto& body = owner.pet;
            if (pet.kind == 0 || body.removed) {
                continue;
            }
            drawActor(party.companions[index].actor.tiles(0), body.pose, body, game, EnemyAnchorX, EnemyAnchorY);
            const int iconHeight = pet.form() == 3 ? 120 : pet.artIndex() == 2 ? 100 : 70;
            image(party.hud, 20 + pet.artIndex(), static_cast<float>(body.x) - cameraX - 40,
                  static_cast<float>(body.y) - cameraY - static_cast<float>(iconHeight + 30));
            drawEffect(effects, index * 3 + 2, owner.petEffect, body.x, body.y, false, game);
        }
        for (const elf::Item& item : game.items()) {
            if (item.kind != elf::ItemKind::None) {
                const int alpha = item.collected < 0 ? 255 : (10 - item.collected) * 255 / 10;
                const int kind = static_cast<int>(item.kind);
                const int group = item.gearLevel > 2 ?
                    400 + (item.gearLevel - 3) * 4 + kind - static_cast<int>(elf::ItemKind::Shield) : 119 + kind;
                drawActor(combat, group, item.motion, game, 140, 170, alpha);
            }
        }
        for (const auto& skill : game.skills()) {
            if (skill.kind != 0) {
                drawSkill(skill.kind >= FirstStreamedSpell ? party.magic.tiles(petSpellSlot(skill)) : skills.tiles(),
                          skill, game);
            }
        }
        for (std::size_t i = 0; i < game.worldEffects().size(); ++i) {
            const auto& effect = game.worldEffects()[i];
            drawEffect(effects, EffectArt::WorldOffset + i, effect, effect.x, effect.y, effect.facingLeft, game);
        }
        drawHitFeedback(game, level.feedback);
        image(level.background, 3, -static_cast<float>(game.cameraX() % elf::source::ViewWidth), -cameraY);
        drawCombo(game, level.feedback);
        if (boss) {
            image(combat, 220, 330, 20);
            image(combat, 221, 330, 20, false, gauge(boss->body.hp, boss->body.maxHp));
        }
        for (int i = 0; i < game.playerCount(); ++i) {
            const auto& actor = game.participant(i);
            const auto& bank = i == 0 ? combat : party.coopHud;
            playerHud(actor, bank, combat, party.hud, i == 1, i == input.localRole ? &input : nullptr);
            if (actor.progress.pet.kind != 0) {
                petHud(actor, party, i == 1);
            }
        }
        drawScore(game, level.feedback);
        for (int i = 0; i < game.playerCount(); ++i) {
            const auto& tip = party.tips[static_cast<std::size_t>(i)];
            image(tip.tiles(0), game.participant(i).tipFrame, i == 0 ? 0.0F : 620.0F, 100);
        }
        if (game.victoryAge() >= 0 && !game.doorOpen()) {
            image(victory, 240 + game.victoryAge(), 0, 0);
        }
        if (game.lost()) {
            image(level.defeat.tiles(0), game.defeatFrame(), 0, 0);
        }
    }

    void feedbackImage(const ArtBank& bank, int group, float x, float y, bool mirror = false, int alpha = 255) {
        image(bank, group, x + (mirror ? FeedbackAnchorX : -FeedbackAnchorX), y - FeedbackAnchorY,
              mirror, 1, alpha);
    }

    void drawHitFeedback(const elf::Game& game, const ArtBank& bank) {
        const auto& hits = game.hitFeedback();
        for (std::size_t i = 0; i < game.hitCount(); ++i) {
            const auto& hit = hits[i];
            if (hit.age < 6 && hit.light != elf::HitLight::None) {
                const int group = 101 + static_cast<int>(hit.light) * 10 + hit.age;
                feedbackImage(bank, group, static_cast<float>(hit.x - game.cameraX()),
                              static_cast<float>(hit.y - game.cameraY()), hit.facingLeft);
            }
        }
        for (std::size_t i = 0; i < game.hitCount(); ++i) {
            const auto& hit = hits[i];
            const int x = hit.x - game.cameraX() - 80 + hit.age * hit.driftX;
            const int y = hit.y - game.cameraY() - 100 + hit.age * hit.driftY;
            char digits[12];
            std::snprintf(digits, sizeof(digits), "%d", hit.amount);
            feedbackImage(bank, (hit.party ? 60 : 50) + digits[0] - '0',
                          static_cast<float>(x), static_cast<float>(y - 10));
            std::uint32_t jitter = hit.digitJitter;
            for (int digit = 1; digits[digit] != '\0'; ++digit, jitter >>= 2) {
                const int offset = static_cast<int>(jitter & 3U) - 2;
                feedbackImage(bank, (hit.party ? 40 : 30) + digits[digit] - '0',
                              static_cast<float>(x + digit * 20 + 10), static_cast<float>(y + offset));
            }
        }
    }

    void drawCombo(const elf::Game& game, const ArtBank& bank) {
        const int alpha = (100 - 3 * game.comboAge()) * 255 / 100;
        if (game.comboHits() == 0 || alpha <= 0) {
            return;
        }
        feedbackImage(bank, 2, 770, 150, false, alpha);
        char digits[12];
        std::snprintf(digits, sizeof(digits), "%d", game.comboHits());
        for (int i = 0; digits[i] != '\0'; ++i) {
            feedbackImage(bank, (game.comboAge() == 0 ? 80 : 20) + digits[i] - '0',
                          static_cast<float>(830 + 30 * i), 105, false, alpha);
        }
    }

    void drawScore(const elf::Game& game, const ArtBank& bank) {
        if (!game.scoreVisible()) {
            return;
        }
        char digits[12];
        std::snprintf(digits, sizeof(digits), "%u", static_cast<unsigned>(game.score()));
        const int x = 440 - 7 * static_cast<int>(std::strlen(digits));
        feedbackImage(bank, 1, static_cast<float>(x), 570);
        for (int i = 0; digits[i] != '\0'; ++i) {
            feedbackImage(bank, 10 + digits[i] - '0', static_cast<float>(x + 70 + 15 * i), 582);
        }
    }

    void drawActor(const ArtBank& bank, int group, const elf::Motion& actor, const elf::Game& game,
                   int anchorX, int anchorY, int alpha = 255) {
        drawActor(bank.tiles(), group, actor, game, anchorX, anchorY, alpha);
    }

    void drawActor(const std::vector<Texture>& tiles, int group, const elf::Motion& actor, const elf::Game& game,
                   int anchorX, int anchorY, int alpha = 255) {
        const float x = static_cast<float>(actor.x - game.cameraX() + (actor.facingLeft ? anchorX : -anchorX));
        const float y = static_cast<float>(actor.y - game.cameraY() - anchorY);
        image(tiles, group, x, y, actor.facingLeft, 1, alpha);
    }

    void drawEffect(const EffectArt& effects, std::size_t slot, const elf::Effect& effect,
                    int x, int y, bool mirror, const elf::Game& game) {
        if (effect.light == elf::Light::None) {
            return;
        }
        image(effects.tiles(slot), effectGroup(effect),
              static_cast<float>(x - game.cameraX() + (mirror ? EnemyAnchorX : -EnemyAnchorX)),
              static_cast<float>(y - game.cameraY() - EnemyAnchorY), mirror);
    }

    void drawSkill(const std::vector<Texture>& tiles, const elf::Skill& skill, const elf::Game& game) {
        const int group = skill.kind * 32 + skill.pose;
        constexpr int Anchor = 256;
        if (skill.angle == 0) {
            drawActor(tiles, group, skill.motion, game, Anchor, Anchor);
            return;
        }
        const float originX = static_cast<float>(skill.motion.x - game.cameraX());
        const float originY = static_cast<float>(skill.motion.y - game.cameraY());
        const float radians = static_cast<float>(skill.angle) * (3.14159265F / 180.0F);
        const float sine = std::sin(radians);
        const float cosine = std::cos(radians);
        sceGuEnable(GU_TEXTURE_2D);
        for (const Texture& tile : tiles) {
            if (tile.group != group) {
                continue;
            }
            const float w = static_cast<float>(tile.width);
            const float h = static_cast<float>(tile.height);
            const float x = static_cast<float>(tile.x * 2 - Anchor);
            const float y = static_cast<float>(tile.y * 2 - Anchor);
            const auto vertex = [&](float u, float v) {
                const float dx = x + 2 * u;
                const float dy = y + 2 * v;
                return TextureVertex{u, v, 0xffffffff,
                    StageLeft + (originX + dx * cosine - dy * sine) * Scale,
                    (originY + dx * sine + dy * cosine) * Scale, 0};
            };
            auto* vertices = static_cast<TextureVertex*>(sceGuGetMemory(sizeof(TextureVertex) * 4));
            vertices[0] = vertex(0, 0);
            vertices[1] = vertex(w, 0);
            vertices[2] = vertex(0, h);
            vertices[3] = vertex(w, h);
            sceGuTexImage(0, tile.stride, tile.rows, tile.stride, tile.pixels.get());
            sceGuDrawArray(GU_TRIANGLE_STRIP,
                           GU_TEXTURE_32BITF | GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
                           4, nullptr, vertices);
        }
    }

    void statLabel(const ArtBank& digits, int current, int maximum, float x, float y) {
        char value[16];
        if (maximum < 0) {
            std::snprintf(value, sizeof(value), "%d", current);
        } else {
            std::snprintf(value, sizeof(value), "%d/%d", current, maximum);
        }
        for (const char* digit = value; *digit; ++digit, x += 8) {
            image(digits, *digit == '/' ? 40 : 30 + *digit - '0', x, y);
        }
    }

    void playerHud(const elf::Player& actor, const ArtBank& bank, const ArtBank& skills,
                   const ArtBank& digits, bool right, const InputDisplay* input) {
        const auto& stats = actor.progress;
        const auto& body = actor.body;
        const float x = right ? 750.0F : 10.0F;
        const float textX = right ? 786.0F : 100.0F;
        image(bank, 200 + stats.role + (stats.dualWield ? 2 : 0), x, 10);
        image(bank, 210, x, 10, false, gauge(body.hp, body.maxHp));
        image(bank, 211, x, 10, false, gauge(actor.mp, actor.maximumMp()));
        image(bank, 212, x, 10, false, stats.level == 40 ? 1 : gauge(stats.exp, actor.expTarget()));
        statLabel(digits, body.hp, body.maxHp, textX, 24);
        statLabel(digits, actor.mp, actor.maximumMp(), textX, 41);
        statLabel(digits, stats.level, -1, (right ? 917.0F : 36.0F) - (stats.level >= 10 ? 4 : 0), 81);
        if (stats.level == 40) {
            image(digits, 41, textX, 55);
        } else {
            statLabel(digits, stats.exp, actor.expTarget(), textX, 55);
        }
        if (const int count = actor.unlockedSkills(); count > 0) {
            const float left = right ? 750.0F : 65.0F;
            image(skills, 339 + count, left, 70);
            if (input) {
                rect(left, 104, 148, 18, 0xcc0c151f);
                padGlyph(input->art.hints, 160, left + 10, 113);
                for (int i = 0; i < count; ++i) {
                    const auto action = static_cast<elf::Binding>(static_cast<int>(elf::Binding::HeavySlash) + i);
                    padGlyph(input->art.hints, 140 + static_cast<int>(input->keys[action]),
                             left + static_cast<float>(31 + 33 * i), 113);
                }
            }
        }
    }

    void petHud(const elf::Player& owner, const PartyArt& art, bool right) {
        const auto& pet = owner.progress.pet;
        const auto& body = owner.pet;
        const auto& bank = right ? art.coopHud : art.hud;
        const auto& digits = art.hud;
        const int target = pet.expTarget();
        const float x = right ? 700.0F : -30.0F;
        image(bank, 1, x, 500);
        image(bank, 2, x, 500, false, gauge(body.hp, body.maxHp));
        image(bank, 3, x, 500, false, gauge(owner.petMp, owner.petMaximumMp()));
        image(bank, 4, x, 500, false, target == 0 ? 1 : gauge(pet.exp, target));
        image(art.hud, 10 + pet.artIndex(), right ? 985.0F : -30.0F, 500, right);
        statLabel(digits, pet.level, -1, (right ? 909.0F : 40.0F) - (pet.level >= 10 ? 4 : 0), 565);
        statLabel(digits, body.hp, body.maxHp, right ? 739.0F : 58.0F, 545);
        statLabel(digits, owner.petMp, owner.petMaximumMp(), right ? 827.0F : 146.0F, 545);
        if (target == 0) {
            image(digits, 41, right ? 779.0F : 98.0F, 561);
        } else {
            statLabel(digits, pet.exp, target, right ? 779.0F : 98.0F, 561);
        }
    }

    void image(const ArtBank& bank, int group, float originX, float originY, bool mirror = false,
               float fill = 1, int alpha = 255) {
        image(bank.tiles(), group, originX, originY, mirror, fill, alpha);
    }

    void image(const std::vector<Texture>& tiles, int group, float originX, float originY, bool mirror = false,
               float fill = 1, int alpha = 255) {
        if (fill <= 0) {
            return;
        }
        sceGuEnable(GU_TEXTURE_2D);
        const std::uint32_t color = (static_cast<std::uint32_t>(alpha) << 24) | 0x00ffffff;
        for (const Texture& tile : tiles) {
            if (tile.group != group) {
                continue;
            }
            const float width = static_cast<float>(tile.width);
            const float height = static_cast<float>(tile.height);
            const float x = static_cast<float>(tile.x) * 2;
            const float y = static_cast<float>(tile.y) * 2;
            const float left = mirror ? originX - x - width * 2 : originX + x;
            const float top = originY + y;
            const float right = left + width * 2 * fill;
            const float bottom = top + height * 2;
            if (right <= 0 || left >= elf::source::ViewWidth || bottom <= 0 || top >= elf::source::ViewHeight) {
                continue;
            }
            sceGuTexImage(0, tile.stride, tile.rows, tile.stride, tile.pixels.get());
            auto* vertices = static_cast<TextureVertex*>(sceGuGetMemory(sizeof(TextureVertex) * 2));
            vertices[0] = {mirror ? width : 0, 0, color, StageLeft + left * Scale, top * Scale, 0};
            vertices[1] = {mirror ? 0 : width, height, color, StageLeft + right * Scale, bottom * Scale, 0};
            sceGuDrawArray(GU_SPRITES, GU_TEXTURE_32BITF | GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
                           2, nullptr, vertices);
        }
    }

    void rect(float x, float y, float width, float height, std::uint32_t color) {
        sceGuDisable(GU_TEXTURE_2D);
        auto* vertices = static_cast<ColorVertex*>(sceGuGetMemory(sizeof(ColorVertex) * 2));
        vertices[0] = {color, StageLeft + x * Scale, y * Scale, 0};
        vertices[1] = {color, StageLeft + (x + width) * Scale, (y + height) * Scale, 0};
        sceGuDrawArray(GU_SPRITES, GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D, 2, nullptr, vertices);
    }

    void focus(float x, float y, float width, float height) {
        constexpr float Stroke = 3;
        constexpr std::uint32_t Gold = 0xff3ad9ff;
        rect(x, y, width, Stroke, Gold);
        rect(x, y + height - Stroke, width, Stroke, Gold);
        rect(x, y, Stroke, height, Gold);
        rect(x + width - Stroke, y, Stroke, height, Gold);
    }

    void focusMapNode(const ArtBank& bank, int group) {
        int left = elf::source::ViewWidth / 2;
        int top = elf::source::ViewHeight / 2;
        int right = 0;
        int bottom = 0;
        for (const Texture& tile : bank.tiles()) {
            if (tile.group == group) {
                left = std::min(left, tile.x);
                top = std::min(top, tile.y);
                right = std::max(right, tile.x + tile.width);
                bottom = std::max(bottom, tile.y + tile.height);
            }
        }
        if (right > left && bottom > top) {
            focus(static_cast<float>(2 * left - 4), static_cast<float>(2 * top - 4),
                  static_cast<float>(2 * (right - left) + 8), static_cast<float>(2 * (bottom - top) + 8));
        }
    }
};

int exitCallback(int, int, void*) {
    sceKernelExitGame();
    return 0;
}

int callbackThread(SceSize, void*) {
    const int callback = sceKernelCreateCallback("Exit Elf Story", exitCallback, nullptr);
    sceKernelRegisterExitCallback(callback);
    sceKernelSleepThreadCB();
    return 0;
}

void setupCallbacks() {
    const int thread = sceKernelCreateThread("Elf Story callbacks", callbackThread, 17, 0x1000, 0, nullptr);
    if (thread >= 0) {
        sceKernelStartThread(thread, 0, nullptr);
    }
}

std::uint32_t editBindings(elf::BindingEditor& editor, elf::BindingStore& store, elf::PadBindings& active,
                           std::uint32_t pressed, elf::Controls& input) {
    constexpr auto Confirm = 1U << static_cast<unsigned>(elf::Sound::Confirm);
    constexpr auto Move = 1U << static_cast<unsigned>(elf::Sound::MenuMove);
    input = {};
    if (pressed != 0) {
        editor.saveFailed = false;
    }
    if (editor.capturing) {
        if ((pressed & PSP_CTRL_SELECT) != 0) {
            editor.capturing = false;
            return Move;
        }
        const auto binding = editor.selection();
        const auto key = elf::pressedKey(binding, pressed);
        if (key != elf::PadKey::Count) {
            editor.draft.assign(binding, key);
            editor.capturing = false;
            return Confirm;
        }
        return 0;
    }
    if ((pressed & PSP_CTRL_START) != 0) {
        if (store.write(editor.draft)) {
            active = editor.draft;
            input.cancel = true;
            return Confirm;
        }
        editor.saveFailed = true;
        return 0;
    }
    if ((pressed & PSP_CTRL_CIRCLE) != 0) {
        input.cancel = true;
        return Move;
    }
    if ((pressed & PSP_CTRL_SELECT) != 0) {
        editor.draft = {};
        return Confirm;
    }
    if ((pressed & PSP_CTRL_CROSS) != 0) {
        editor.capturing = true;
        return Confirm;
    }
    const int dx = ((pressed & PSP_CTRL_RIGHT) != 0) - ((pressed & PSP_CTRL_LEFT) != 0);
    const int dy = ((pressed & PSP_CTRL_DOWN) != 0) - ((pressed & PSP_CTRL_UP) != 0);
    return editor.move(dx, dy) ? Move : 0;
}

using SaveStores = std::array<elf::SaveStore, 2>;

void loadLocalProgress(elf::Game& game, SaveStores& saves, std::uint32_t seed) {
    game = elf::Game(seed);
    for (unsigned i = 0; i < saves.size(); ++i) {
        elf::Progress progress{};
        if (saves[i].load(progress)) {
            game.restoreProgress(progress, static_cast<elf::Mode>(i));
        }
    }
}

std::uint32_t updateGame(elf::Game& game, SaveStores& saves, const elf::Controls& input,
                         const elf::Controls& second = {}, bool persist = true) {
    game.step(input, second);
    elf::Progress progress{};
    elf::Mode mode{};
    if (game.takePendingSave(progress, &mode) && persist && !saves[static_cast<unsigned>(mode)].write(progress)) {
        std::fputs("Elf Story: could not write progress.\n", stderr);
    }
    return game.takeSounds();
}

int mediaError(const char* message) {
    pspDebugScreenInit();
    pspDebugScreenPrintf("Elf Story: %s\n", message);
    sceKernelSleepThread();
    return 1;
}

#ifdef ELF_STORY_QA
int replay(elf::Game& game, SaveStores& saves, std::FILE* input, std::FILE* trace) {
    unsigned mask = 0;
    int read = 0;
    while ((read = std::fscanf(input, "%u", &mask)) == 1 && mask <= 0x3fffffffU) {
        const auto sounds = updateGame(game, saves, elf::qa::decodeControls(mask & 0x7fffU),
                                       elf::qa::decodeControls(mask >> 15));
        if (game.screen() == elf::Screen::LinkLobby) {
            game.beginLinkedCampaign(elf::Game::ReplaySeed, game.savedProgress(elf::Mode::Coop));
        }
        elf::qa::writeTrace(trace, game, sounds);
    }
    if (read != EOF || std::ferror(input) || std::fflush(trace) != 0 || std::ferror(trace)) {
        return 1;
    }
    const std::unique_ptr<std::FILE, FileCloser> done(std::fopen("ELF_DONE.TXT", "w"));
    if (!done) {
        return 1;
    }
    std::fputs("complete\n", done.get());
    return 0;
}
#endif

}  // namespace

int main() {
    setupCallbacks();
    scePowerSetClockFrequency(333, 333, 166);
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_DIGITAL);
    SaveStores saves{{elf::SaveStore(elf::Mode::Solo), elf::SaveStore(elf::Mode::Coop)}};
    std::uint64_t seed = 0;
    sceRtcGetCurrentTick(&seed);
#ifdef ELF_STORY_QA
    const auto localSeed = elf::Game::ReplaySeed;
#else
    const auto localSeed = static_cast<std::uint32_t>(seed ^ (seed >> 32));
#endif
    elf::Game game(localSeed);
    loadLocalProgress(game, saves, localSeed);
#ifdef ELF_STORY_QA
    const std::unique_ptr<std::FILE, FileCloser> trace(std::fopen("ELF_TRACE.TXT", "w"));
    const std::unique_ptr<std::FILE, FileCloser> route(std::fopen("ELF_ROUTE.TXT", "r"));
    if (route) {
        return trace ? replay(game, saves, route.get(), trace.get()) : 1;
    }
    const std::unique_ptr<std::FILE, FileCloser> renderRoute(std::fopen("ELF_ROUTE_RENDER.TXT", "r"));
    if (renderRoute && (!trace || replay(game, saves, renderRoute.get(), trace.get()) != 0)) {
        return 1;
    }
    std::unique_ptr<std::FILE, FileCloser> linkTrace;
    std::unique_ptr<std::FILE, FileCloser> linkInputs;
    std::uint32_t routeFrame = 0;
    elf::Controls routeInput{};
#endif
    constexpr char ArtError[] = "missing or invalid data/art files.";
    constexpr char StoryError[] = "missing or invalid story data.";
    ArtBank menus, coopRole, lobby, combat, skills, victory;
    InterfaceArt interfaceArt;
    elf::PadBindings bindings;
    elf::BindingStore bindingStore;
    elf::BindingEditor editor;
    bindingStore.load(bindings);
    PartyArt party;
    EffectArt effectArt;
    StageArt level;
    elf::StoryMovie story;
    elf::Screen movieScreen = elf::Screen::Title;
    int loadedStage = 0;
    if (!menus.load("data/art/menus.pak") || !combat.load("data/art/combat.pak") ||
        !interfaceArt.hints.load("data/art/input_hints.pak") || !effectArt.load("data/art/player_fx.pak")) {
        return mediaError(ArtError);
    }
    elf::Audio audio;
    if (!audio.start()) {
        return mediaError("cannot start audio. Check data/audio.pak.");
    }

    Renderer renderer;
    renderer.init();

    std::uint64_t previous = 0;
    sceRtcGetCurrentTick(&previous);
    const std::uint64_t resolution = sceRtcGetTickResolution();
    std::uint64_t accumulator = 0;
    std::uint32_t lastHeld = 0;
    std::uint32_t pending = 0;
    bool muted = false;
    bool joinSelected = false;
    bool linkedGame = false;
    elf::LinkSession link;
    while (true) {
        SceCtrlData pad{};
        sceCtrlPeekBufferPositive(&pad, 1);
        const std::uint32_t pressed = pad.Buttons & ~lastHeld;
        pending |= pressed;
        lastHeld = pad.Buttons;
        constexpr std::uint32_t Leave = PSP_CTRL_START | PSP_CTRL_SELECT;
        if (linkedGame && (lastHeld & Leave) == Leave && (pressed & Leave) != 0) {
            link.close();
            pending = 0;
        } else if ((pressed & PSP_CTRL_SELECT) != 0 && game.screen() != elf::Screen::Bindings) {
            muted = !muted;
        }

        std::uint64_t now = 0;
        sceRtcGetCurrentTick(&now);
        const auto networkTime = sceKernelGetSystemTimeWide();
        link.pump(networkTime);
        if (linkedGame && !link.active()) {
            loadLocalProgress(game, saves, localSeed);
            game.returnToLinkLobby();
            linkedGame = false;
            pending = 0;
            accumulator = 0;
        } else if (!linkedGame && link.active()) {
            game.beginLinkedCampaign(link.seed(), link.saved());
            linkedGame = true;
            pending = 0;
            accumulator = 0;
#ifdef ELF_STORY_QA
            linkTrace.reset(std::fopen("ELF_LINK_TRACE.TXT", "w"));
            linkInputs.reset(std::fopen("ELF_LINK_INPUTS.TXT", "r"));
            routeFrame = UINT32_MAX;
#endif
        }
        accumulator += std::min(now - previous, resolution / 8) * elf::source::TickRate;
        previous = now;
        std::uint32_t effects = 0;
        while (accumulator >= resolution) {
            const auto currentScreen = game.screen();
            const bool inStage = currentScreen == elf::Screen::Stage;
            auto input = elf::readPad(lastHeld, pending, bindings, inStage);
            elf::Controls second{};
            if (currentScreen == elf::Screen::Bindings) {
                effects |= editBindings(editor, bindingStore, bindings, pending, input);
            } else if (currentScreen == elf::Screen::Help) {
                input.left = (pending & (PSP_CTRL_LEFT | PSP_CTRL_LTRIGGER)) != 0;
                input.right = (pending & (PSP_CTRL_RIGHT | PSP_CTRL_RTRIGGER)) != 0;
            } else if (currentScreen == elf::Screen::LinkLobby) {
                if (link.busy()) {
                    if (input.cancel) {
                        link.close();
                    }
                    input = {};
                } else if (!input.cancel) {
                    const bool wasJoining = joinSelected;
                    if (input.up || input.left) {
                        joinSelected = false;
                    } else if (input.down || input.right) {
                        joinSelected = true;
                    }
                    if (wasJoining != joinSelected) {
                        effects |= 1U << static_cast<unsigned>(elf::Sound::MenuMove);
                    }
                    if (input.confirm) {
                        link.start(!joinSelected, localSeed,
                                   game.savedProgress(elf::Mode::Coop), networkTime);
                        effects |= 1U << static_cast<unsigned>(elf::Sound::Confirm);
                    }
                } else {
                    link.close();
                }
            }
            if ((currentScreen == elf::Screen::Ending && game.storyFrame() == elf::Game::EndingFrames - 1) ||
                (inStage && game.lost())) {
                input.confirm = pending != 0;
            }
            if (linkedGame) {
#ifdef ELF_STORY_QA
                if (linkInputs && routeFrame != link.frame()) {
                    unsigned mask = 0;
                    if (std::fscanf(linkInputs.get(), "%u", &mask) == 1 && mask <= 0xffffU) {
                        routeFrame = link.frame();
                        routeInput = elf::qa::decodeControls(mask);
                    } else {
                        linkInputs.reset();
                    }
                }
                if (linkInputs) {
                    input = routeInput;
                }
#endif
                if (link.submit(input)) {
                    pending = 0;
                }
                if (!link.takeFrame(input, second)) {
                    accumulator = resolution;
                    break;
                }
            } else {
                pending = 0;
            }
            const auto sounds = updateGame(game, saves, input, second, !linkedGame || link.host());
            if (currentScreen != elf::Screen::Bindings && game.screen() == elf::Screen::Bindings) {
                editor = {bindings};
            }
            effects |= sounds;
            accumulator -= resolution;
#ifdef ELF_STORY_QA
            if (trace) {
                elf::qa::writeTrace(trace.get(), game, sounds);
                std::fflush(trace.get());
            }
            if (linkedGame && linkTrace) {
                elf::qa::writeTrace(linkTrace.get(), game, sounds);
                std::fflush(linkTrace.get());
            }
#endif
            if (linkedGame && game.screen() == elf::Screen::Title) {
                link.close();
                loadLocalProgress(game, saves, localSeed);
                linkedGame = false;
                accumulator = 0;
            }
        }
        const bool intro = game.screen() == elf::Screen::Intro;
        const bool inMovie = intro || game.screen() == elf::Screen::Ending;
        if (!inMovie && movieScreen != elf::Screen::Title) {
            story.close();
            movieScreen = elf::Screen::Title;
        }
        if (game.screen() == elf::Screen::Stage && loadedStage != game.stageNumber()) {
            menus = {};
            if (!level.load(game.stageNumber(), game.stage()) ||
                !skills.load("data/art/skills.pak", game.stageSkillMask())) {
                return mediaError(ArtError);
            }
            loadedStage = game.stageNumber();
            sceRtcGetCurrentTick(&previous);
        } else if (game.screen() != elf::Screen::Stage && loadedStage != 0) {
            victory = {};
            skills = {};
            level = {};
            party = {};
            effectArt.clear();
            loadedStage = 0;
            if (!menus.load("data/art/menus.pak")) {
                return mediaError(ArtError);
            }
            sceRtcGetCurrentTick(&previous);
        }
        if (game.screen() == elf::Screen::SelectRole && game.mode() == elf::Mode::Coop) {
            if (coopRole.tiles().empty() && !coopRole.load("data/art/coop_role.pak")) {
                return mediaError(ArtError);
            }
        } else if (!coopRole.tiles().empty()) {
            coopRole = {};
        }
        if (game.screen() == elf::Screen::LinkLobby) {
            if (lobby.tiles().empty() && !lobby.load("data/art/link_lobby.pak")) {
                return mediaError(ArtError);
            }
        } else if (!lobby.tiles().empty()) {
            lobby = {};
        }
        if (!interfaceArt.update(game)) {
            return mediaError(ArtError);
        }
        if (game.screen() == elf::Screen::Stage &&
            (!party.update(game) || !effectArt.update(game))) {
            return mediaError(ArtError);
        }
        if (game.screen() == elf::Screen::Stage && game.lost()) {
            if ((!level.defeat.loaded() && !level.defeat.load("data/art/defeat.pak")) ||
                !level.defeat.select(0, game.defeatFrame())) {
                return mediaError(ArtError);
            }
        }
        if (game.screen() == elf::Screen::Stage && game.victoryAge() >= 0 && !game.doorOpen()) {
            if (victory.tiles().empty()) {
                level.discardUnusedEnemies(game);
                if (!victory.load("data/art/victory.pak")) {
                    return mediaError(ArtError);
                }
                sceRtcGetCurrentTick(&previous);
            }
        } else if (!victory.tiles().empty()) {
            victory = {};
        }
        if (inMovie) {
            if (movieScreen != game.screen()) {
                if (!story.open(intro ? "data/story/intro.esmv" : "data/story/ending.esmv",
                                intro ? elf::Game::IntroFrames : elf::Game::EndingFrames)) {
                    return mediaError(StoryError);
                }
                movieScreen = game.screen();
                sceRtcGetCurrentTick(&previous);
            }
            if (!story.advance(game.storyFrame())) {
                return mediaError(StoryError);
            }
        }
        audio.submit(game.musicTrack(), effects, muted);
        const InputDisplay input{interfaceArt, bindings, editor, linkedGame && !link.host() ? 1 : 0};
        renderer.draw(game, menus, coopRole, lobby, link.status(), joinSelected, level, party, combat, skills,
                      victory, effectArt, story, muted, input);
    }
}
