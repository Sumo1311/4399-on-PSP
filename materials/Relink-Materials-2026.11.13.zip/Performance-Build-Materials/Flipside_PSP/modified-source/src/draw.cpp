#include "draw.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <lz4.h>
#include <malloc.h>
#include <pspdisplay.h>
#include <pspgu.h>
#include <pspkernel.h>
#include <zlib.h>

namespace flipside {
namespace {

constexpr int PspWidth = 480, PspHeight = 272, Stride = 512;
constexpr float Scale = PspHeight/StageHeight, Offset = (PspWidth - StageWidth*Scale)/2;
constexpr int PageWidth = 512;
alignas(64) uint32_t displayList[128*1024];
constexpr int VertexFormat = GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_2D;
constexpr int ColorFormat = GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_2D;

struct Slice {
    int page, u, v, w, h;
    float x, y;
};
struct Entry { uint16_t id, frame, first, count; };
struct Glyph { int c, id, advance; };
struct ClipDef { int first, count, w, h, tw, th, x, y, logicalW, logicalH; };
struct ClipFrame { unsigned offset, size; };
#include "art_tables.inc"
#include "clip_tables.inc"
#include "small_font.inc"

constexpr auto spriteStarts = [] {
    std::array<uint16_t,entries[std::size(entries)-1].id+2> result{};
    unsigned entry = 0;
    for (unsigned id = 0; id < result.size(); ++id) {
        while (entry < std::size(entries) && entries[entry].id < id) ++entry;
        result[id] = entry;
    }
    return result;
}();

constexpr auto glyphLookup = [] {
    std::array<const Glyph*, 256> result{};
    for (const auto& g : glyphs) {
        if (g.c >= 0 && g.c < static_cast<int>(result.size()) && !result[g.c])
            result[g.c] = &g;  // Preserve the first matching Glyph.
    }
    return result;
}();

const Glyph* glyph(int letter) {
    letter = std::toupper(static_cast<unsigned char>(letter));
    return letter >= 0 && letter < static_cast<int>(glyphLookup.size())
        ? glyphLookup[letter] : nullptr;
}

}  // namespace

void Draw::Free::operator()(void* ptr) const { std::free(ptr); }

bool Draw::loadPages() {
    FILE* file = std::fopen("flipside.tex","rb");
    if (!file) return false;
    uint32_t head[2]{};
    bool ok = std::fread(head,sizeof(head),1,file) == 1 && head[0] == 0x32545346 && head[1] <= 32;
    if (ok) {
        for (unsigned i = 0; i < head[1]; ++i) {
            uint32_t desc[2];
            if (std::fread(desc,sizeof(desc),1,file) != 1 || desc[0] > PageWidth ||
                desc[0] < 8 || (desc[0] & (desc[0]-1)) || desc[1] > 2*1024*1024) {
                ok = false;
                break;
            }
            const size_t raw = PageWidth*desc[0]*4;
            Aligned data(static_cast<uint8_t*>(memalign(64,raw)));
            if (!data) {
                ok = false;
                break;
            }
            compressed_.resize(desc[1]);
            uLongf length = raw;
            if (std::fread(compressed_.data(),1,desc[1],file) != desc[1] ||
                uncompress(data.get(),&length,compressed_.data(),desc[1]) != Z_OK || length != raw) {
                ok = false;
                break;
            }
            sceKernelDcacheWritebackRange(data.get(),raw);
            pages_.push_back({std::move(data),static_cast<int>(desc[0])});
        }
    }
    std::fclose(file);
    return ok && !pages_.empty();
}

bool Draw::init() {
    if (!loadPages()) return false;
    animation_ = std::fopen("flipside.anim","rb");
    uint32_t magic = 0;
    if (!animation_ || std::fread(&magic,sizeof(magic),1,animation_) != 1 || magic != 0x32435346) return false;
    sceGuInit();
    sceGuStart(GU_DIRECT,displayList);
    sceGuDrawBuffer(GU_PSM_8888,reinterpret_cast<void*>(0),Stride);
    sceGuDispBuffer(PspWidth,PspHeight,reinterpret_cast<void*>(Stride*PspHeight*4),Stride);
    sceGuOffset(2048-PspWidth/2,2048-PspHeight/2);
    sceGuViewport(2048,2048,PspWidth,PspHeight);
    sceGuScissor(0,0,PspWidth,PspHeight);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuDisable(GU_DEPTH_TEST);
    sceGuDisable(GU_CULL_FACE);
    sceGuShadeModel(GU_SMOOTH);
    sceGuEnable(GU_BLEND);
    glow(false);
    sceGuTexMode(GU_PSM_8888,0,0,GU_TRUE);
    sceGuTexFilter(GU_LINEAR,GU_LINEAR);
    sceGuTexWrap(GU_CLAMP,GU_CLAMP);
    sceGuTexFunc(GU_TFX_MODULATE,GU_TCC_RGBA);
    sceGuFinish();
    sceGuSync(0,0);
    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);
    active_ = true;
    return true;
}

Draw::~Draw() {
    if (active_) sceGuTerm();
    if (animation_) std::fclose(animation_);
}

void Draw::begin() {
    sceGuStart(GU_DIRECT,displayList);
    sceGuScissor(0,0,PspWidth,PspHeight);
    sceGuClearColor(rgba(0,0,0));
    sceGuClear(GU_COLOR_BUFFER_BIT);
    sceGuScissor(static_cast<int>(Offset),0,PspWidth-static_cast<int>(Offset),PspHeight);
    texture_ = nullptr;
    textured_ = false;
    sceGuDisable(GU_TEXTURE_2D);
}

void Draw::end() {
    flushSprites();
    flushLines();
    sceGuFinish();
    sceGuSync(0,0);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();
}

void Draw::bind(const void* ptr, int width, int height) {
    if (!textured_) {
        flushLines();
        textured_ = true;
        sceGuEnable(GU_TEXTURE_2D);
    }
    if (texture_ != ptr) {
        flushSprites();
        texture_ = ptr;
        sceGuTexImage(0,width,height,width,ptr);
    }
}

void Draw::untextured() {
    if (textured_) {
        flushSprites();
        textured_ = false;
        sceGuDisable(GU_TEXTURE_2D);
    }
}

void Draw::flushSprites() {
    if (!spriteVertices_) return;
    const auto bytes = spriteVertices_*sizeof(Vertex);
    void* verts = sceGuGetMemory(bytes);
    std::memcpy(verts,sprites_.data(),bytes);
    sceGuDrawArray(GU_SPRITES,VertexFormat,spriteVertices_,nullptr,verts);
    spriteVertices_ = 0;
}

void Draw::flushLines() {
    if (!lineCount_) return;
    alignas(16) static constexpr auto indices = [] {
        std::array<uint16_t,6*LineBatchSize> result{};
        constexpr unsigned corners[] = {0,1,2,2,1,3};
        for (unsigned i = 0; i < LineBatchSize; ++i) {
            for (unsigned j = 0; j < 6; ++j) result[6*i+j] = 4*i+corners[j];
        }
        return result;
    }();
    const auto bytes = 4*lineCount_*sizeof(ColorVertex);
    void* vertices = sceGuGetMemory(bytes);
    std::memcpy(vertices,lines_.data(),bytes);
    sceGuDrawArray(GU_TRIANGLES,ColorFormat|GU_INDEX_16BIT,6*lineCount_,indices.data(),vertices);
    lineCount_ = 0;
}

void Draw::quad(const float* x, const float* y, float u, float v, float w, float h, uint32_t color) {
    flushSprites();
    flushLines();
    auto* verts = static_cast<Vertex*>(sceGuGetMemory(4*sizeof(Vertex)));
    for (int i = 0; i < 4; ++i) {
        verts[i] = {u + (i&1 ? w : 0),v + (i&2 ? h : 0),color,Offset+x[i]*Scale,y[i]*Scale,0};
    }
    sceGuDrawArray(GU_TRIANGLE_STRIP,VertexFormat,4,nullptr,verts);
}

void Draw::sprite(uint16_t id, float x, float y, int frame, float angle, float sx, float sy, uint32_t color) {
    if (id+1u >= spriteStarts.size() || (color >> 24) == 0) return;
    const auto* last = entries+spriteStarts[id+1];
    const auto* it = std::lower_bound(entries+spriteStarts[id],last,frame,
                                    [](const Entry& entry,int f){return entry.frame < f;});
    if (it == last || it->frame != frame) return;
    const float c = angle == 0 ? 1 : std::cos(angle), s = angle == 0 ? 0 : std::sin(angle);
    for (int j = 0; j < it->count; ++j) {
        const auto& slice = slices[it->first+j];
        if (angle == 0 && sx > 0 && sy > 0) {
            const float x0 = x + slice.x*sx, x1 = x + (slice.x+slice.w)*sx;
            const float y0 = y + slice.y*sy, y1 = y + (slice.y+slice.h)*sy;
            if (x1 <= 0 || x0 >= StageWidth || y1 <= 0 || y0 >= StageHeight) continue;
            const auto& page = pages_[slice.page];
            bind(page.bytes.get(),PageWidth,page.height);
            if (spriteVertices_ == sprites_.size()) flushSprites();
            sprites_[spriteVertices_++] = {float(slice.u),float(slice.v),color,Offset+x0*Scale,y0*Scale,0};
            sprites_[spriteVertices_++] = {float(slice.u+slice.w),float(slice.v+slice.h),color,Offset+x1*Scale,y1*Scale,0};
            continue;
        }
        float px[4],py[4];
        bool left = true, right = true, above = true, below = true;
        for (int i = 0; i < 4; ++i) {
            const float dx = (slice.x + (i&1 ? slice.w : 0))*sx;
            const float dy = (slice.y + (i&2 ? slice.h : 0))*sy;
            px[i] = x + c*dx - s*dy;
            py[i] = y + s*dx + c*dy;
            left &= px[i] <= 0;
            right &= px[i] >= StageWidth;
            above &= py[i] <= 0;
            below &= py[i] >= StageHeight;
        }
        if (left || right || above || below) continue;
        const auto& page = pages_[slice.page];
        bind(page.bytes.get(),PageWidth,page.height);
        quad(px,py,slice.u,slice.v,slice.w,slice.h,color);
    }
}

int Draw::clipLength(int id) const { return clips[id].count; }

void Draw::clip(int id, int frame, float x, float y, int channel) {
    if (!animation_) return;
    const auto& def = clips[id];
    const auto& data = clipFrames[def.first + std::clamp(frame,0,def.count-1)];
    auto& buffer = buffers_[channel];
    // Only the swizzled rows touched by the clip (including a filtering border) are stored.
    const unsigned length = def.tw*std::min(def.th,(def.h+8)&~7)*4;
    if (buffer.clip != id || buffer.frame != static_cast<int>(data.offset)) {
        if (buffer.clip != id) {
            const unsigned fullSize = def.tw*def.th*4;
            buffer.bytes.reset();
            buffer.clip = buffer.frame = -1;
            buffer.bytes.reset(static_cast<uint8_t*>(memalign(64,fullSize)));
            if (!buffer.bytes) return;
            if (length < fullSize) {
                std::memset(buffer.bytes.get()+length,0,fullSize-length);
                sceKernelDcacheWritebackRange(buffer.bytes.get()+length,fullSize-length);
            }
            buffer.clip = id;
        }
        buffer.frame = -1;
        compressed_.resize(data.size);
        if (std::fseek(animation_,data.offset,SEEK_SET) != 0 ||
            std::fread(compressed_.data(),1,data.size,animation_) != data.size) return;
        if (LZ4_decompress_safe(reinterpret_cast<const char*>(compressed_.data()),
                                reinterpret_cast<char*>(buffer.bytes.get()),data.size,length) != static_cast<int>(length)) return;
        sceKernelDcacheWritebackRange(buffer.bytes.get(),length);
        buffer.frame = data.offset;
    }
    bind(buffer.bytes.get(),def.tw,def.th);
    flushSprites();
    sceGuTexFlush();
    const float x0 = x + def.x, y0 = y + def.y;
    const float px[] = {x0,x0+def.logicalW,x0,x0+def.logicalW};
    const float py[] = {y0,y0,y0+def.logicalH,y0+def.logicalH};
    quad(px,py,0,0,def.w,def.h,White);
}

void Draw::reveal(float frame) {
    frame = std::max(frame,0.f);
    const auto index = static_cast<unsigned>(frame);
    if (index+1 >= std::size(revealAlpha)) return;
    const float opacity = revealAlpha[index]+(frame-index)*(revealAlpha[index+1]-revealAlpha[index]);
    rect(0,0,StageWidth,StageHeight,rgba(0,0,0,static_cast<unsigned>(opacity+.5f)));
}

void Draw::rect(float x, float y, float w, float h, uint32_t color) {
    untextured();
    const float px[] = {x,x+w,x,x+w};
    const float py[] = {y,y,y+h,y+h};
    quad(px,py,0,0,0,0,color);
}

void Draw::line(float x, float y, float x2, float y2, float width, uint32_t color) {
    const float dx=x2-x, dy=y2-y;
    const float len2=dx*dx+dy*dy;
    if ((color >> 24) == 0 || len2 < .0001f) return;
    untextured();
    if (lineCount_ == LineBatchSize) flushLines();
    const float k=width*.5f/std::sqrt(len2);
    const float px[] = {x-dy*k,x2-dy*k,x+dy*k,x2+dy*k};
    const float py[] = {y+dx*k,y2+dx*k,y-dx*k,y2-dx*k};
    for (unsigned i=0;i<4;++i) lines_[4*lineCount_+i] = {color,Offset+px[i]*Scale,py[i]*Scale,0};
    ++lineCount_;
}

void Draw::text(const char* string, float x, float y, float sy, float sx, uint32_t color, bool center, float maxWidth) {
    float length = 0;
    for (auto* p=string; *p; ++p) {
        const auto* g = glyph(*p);
        length += g ? g->advance + (*p == ' ' ? 3 : 2) : 11;
    }
    if (length * sx > maxWidth) sx = maxWidth/length;
    if (center) x -= length*sx/2;
    for (auto* p=string; *p; ++p) {
        const auto* g = glyph(*p);
        if (g) {
            sprite(g->id,x,y,1,0,sx,sy,color);
            x += (g->advance + (*p==' ' ? 3 : 2))*sx;
        } else {
            x += 11*sx;
        }
    }
}

void Draw::small(const char* string, float x, float y, uint32_t color, bool center) {
    constexpr float scale = 1.5f;
    constexpr float advance = scale*6;
    if (center) x -= std::strlen(string)*advance/2;
    untextured();
    flushLines();
    const unsigned limit = std::strlen(string)*70;
    auto* vertices = static_cast<ColorVertex*>(sceGuGetMemory(limit*sizeof(ColorVertex)));
    unsigned n = 0;
    for (auto* p=string; *p; ++p,x+=advance) {
        const unsigned c = std::toupper(static_cast<unsigned char>(*p));
        if (c < 32 || c > 95) continue;
        for (unsigned row = 0; row < 7; ++row) {
            unsigned bits = smallFont[c-32][row];
            for (unsigned column = 0; column < 5; ++column) {
                if (!(bits & (16u >> column))) continue;
                const float left = Offset+(x+column*scale)*Scale;
                const float top = (y+row*scale)*Scale;
                vertices[n++] = {color,left,top,0};
                vertices[n++] = {color,left+scale*Scale,top+scale*Scale,0};
            }
        }
    }
    if (n) sceGuDrawArray(GU_SPRITES,ColorFormat,n,nullptr,vertices);
}

void Draw::glow(bool additive) {
    flushSprites();
    flushLines();
    sceGuBlendFunc(GU_ADD,GU_SRC_ALPHA,additive ? GU_FIX : GU_ONE_MINUS_SRC_ALPHA,0,0xffffffff);
}

}  // namespace flipside
