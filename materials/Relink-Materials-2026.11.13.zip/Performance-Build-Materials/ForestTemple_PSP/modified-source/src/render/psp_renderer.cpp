#include "render/psp_renderer.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <cstdint>

#include <pspdisplay.h>
#include <pspgu.h>

#include "game/flash_physics.hpp"

#ifdef FFI_FOREST_TEMPLE
#include <random>

#include "render/forest_scene_effects.hpp"
#endif

namespace ffi::render {
namespace {

alignas(16) std::uint32_t g_display_list[262144]{};

constexpr int kScreenWidth = 480;
constexpr int kScreenHeight = 272;
constexpr int kBufferWidth = 512;
constexpr std::uintptr_t kBackBufferOffset = 0x88000U;
constexpr std::uintptr_t kDepthBufferOffset = 0x110000U;
constexpr float kPi = 3.14159265358979323846F;
constexpr float kFlashToPspScale = 0.8F;

#ifdef FFI_FOREST_TEMPLE
constexpr float kPulleyRopeEndOffset = 34.0F * kFlashToPspScale;

level::Vector2 pulley_cable(const game::RuntimePlatform& platform) noexcept {
    return {
        platform.x + platform.width * 0.5F - platform.anchor_x,
        platform.y + platform.height * 0.5F - kPulleyRopeEndOffset - platform.anchor_y,
    };
}
#endif

std::uint8_t mechanism_variant(const std::uint8_t color, const bool lit) noexcept {
    return static_cast<std::uint8_t>(
        (std::clamp<std::uint8_t>(color, 1U, 6U) - 1U) * 2U + 1U + lit);
}

constexpr float kWorldScale =
    static_cast<float>(kScreenHeight) / game::GameWorld::kStageHeight;
constexpr float kWorldViewportWidth =
    game::GameWorld::kStageWidth * kWorldScale;
constexpr float kWorldOffsetX =
    (static_cast<float>(kScreenWidth) - kWorldViewportWidth) * 0.5F;
constexpr float kPauseShownPosition = 90.0F;
constexpr float kPauseHiddenPosition = 480.0F;
constexpr float kResultInitialPosition = -164.35F;
constexpr float kResultShownPosition = 235.7F;
constexpr float kPanelShownY = 44.0F;

constexpr std::uint32_t kColorOutside = 0xFF16110CU;
constexpr std::uint32_t kColorWorld = 0xFF2A2118U;
constexpr std::uint32_t kColorPlatform = 0xFF5D5244U;
constexpr std::uint32_t kColorIce = 0xFFE6D08DU;
constexpr std::uint32_t kColorWater = 0xFFD98937U;
constexpr std::uint32_t kColorFire = 0xFF2850FFU;
constexpr std::uint32_t kColorAcid = 0xFF45C541U;
constexpr std::uint32_t kColorSharedGem = 0xFFD9D9D9U;
constexpr std::uint32_t kColorMechanism = 0xFF8E8C71U;
constexpr std::uint32_t kColorWind = 0x505ED9D9U;
constexpr std::uint32_t kColorDoor = 0xFFDAC9A6U;
constexpr std::uint32_t kColorFireboy = 0xFF2870FFU;
constexpr std::uint32_t kColorWatergirl = 0xFFFF9838U;
constexpr std::uint32_t kColorActive = 0xFFFFFFFFU;
constexpr std::uint32_t kColorPaused = 0xB0000000U;
constexpr std::uint32_t kColorOffline = 0xFF5070D0U;
constexpr std::uint32_t kColorConnected = 0xFF40C060U;
constexpr std::uint32_t kColorText = 0xFFF4E9D8U;
constexpr std::uint32_t kColorMutedText = 0xFFB9AA96U;
// A PSP Memory Stick can turn a multi-megabyte blocking fread into a visible
// menu hitch. Stream only one 64 KiB texture slice between rendered frames.
constexpr std::size_t kGameplayAssetWarmBytesPerFrame = 64U * 1024U;
constexpr std::uint32_t kColorPanel = 0xE8282018U;
constexpr std::uint32_t kColorError = 0xFF4050E0U;
constexpr std::size_t kDarknessRadiusPixels = 120U;
constexpr std::size_t kDarknessCellPixels = 8U;
constexpr float kDarknessCellSize =
    static_cast<float>(kDarknessCellPixels);
constexpr std::size_t kDarknessCellCountX =
    (static_cast<std::size_t>(game::GameWorld::kStageWidth) +
     kDarknessCellPixels - 1U) /
    kDarknessCellPixels;
constexpr std::size_t kDarknessCellCountY =
    (static_cast<std::size_t>(game::GameWorld::kStageHeight) +
     kDarknessCellPixels - 1U) /
    kDarknessCellPixels;
constexpr std::size_t kDarknessSourceCapacity =
    game::GameWorld::kPlayerCount +
    game::GameWorld::kMaximumRuntimePlatforms +
    game::GameWorld::kMaximumWindZones;
constexpr float kDarknessRadiusSquared =
    static_cast<float>(kDarknessRadiusPixels * kDarknessRadiusPixels);
constexpr std::size_t kDarknessDistanceLookupSize =
    kDarknessRadiusPixels * kDarknessRadiusPixels + 1U;

constexpr std::uint32_t source_rgb_to_abgr(
    const std::uint32_t rgb,
    const std::uint8_t alpha) noexcept {
    return static_cast<std::uint32_t>(alpha) << 24U |
           (rgb & 0x000000FFU) << 16U |
           (rgb & 0x0000FF00U) |
           (rgb & 0x00FF0000U) >> 16U;
}

const std::array<float, kDarknessDistanceLookupSize>& darkness_distance_ratio_lut()
    noexcept {
    static std::array<float, kDarknessDistanceLookupSize> table{};
    static bool initialized = false;
    if (initialized) {
        return table;
    }
    for (std::size_t distance_squared = 0U;
         distance_squared < table.size();
         ++distance_squared) {
        table[distance_squared] = std::sqrt(static_cast<float>(distance_squared));
    }
    initialized = true;
    return table;
}

std::array<std::uint8_t, 7> glyph_rows(const char character) noexcept {
    switch (character) {
        case 'A': return {14, 17, 17, 31, 17, 17, 17};
        case 'B': return {30, 17, 17, 30, 17, 17, 30};
        case 'C': return {15, 16, 16, 16, 16, 16, 15};
        case 'D': return {30, 17, 17, 17, 17, 17, 30};
        case 'E': return {31, 16, 16, 30, 16, 16, 31};
        case 'F': return {31, 16, 16, 30, 16, 16, 16};
        case 'G': return {14, 17, 16, 23, 17, 17, 14};
        case 'H': return {17, 17, 17, 31, 17, 17, 17};
        case 'I': return {31, 4, 4, 4, 4, 4, 31};
        case 'J': return {7, 2, 2, 2, 18, 18, 12};
        case 'K': return {17, 18, 20, 24, 20, 18, 17};
        case 'L': return {16, 16, 16, 16, 16, 16, 31};
        case 'M': return {17, 27, 21, 21, 17, 17, 17};
        case 'N': return {17, 25, 21, 19, 17, 17, 17};
        case 'O': return {14, 17, 17, 17, 17, 17, 14};
        case 'P': return {30, 17, 17, 30, 16, 16, 16};
        case 'Q': return {14, 17, 17, 17, 21, 18, 13};
        case 'R': return {30, 17, 17, 30, 20, 18, 17};
        case 'S': return {15, 16, 16, 14, 1, 1, 30};
        case 'T': return {31, 4, 4, 4, 4, 4, 4};
        case 'U': return {17, 17, 17, 17, 17, 17, 14};
        case 'V': return {17, 17, 17, 17, 17, 10, 4};
        case 'W': return {17, 17, 17, 21, 21, 21, 10};
        case 'X': return {17, 17, 10, 4, 10, 17, 17};
        case 'Y': return {17, 17, 10, 4, 4, 4, 4};
        case 'Z': return {31, 1, 2, 4, 8, 16, 31};
        case '0': return {14, 17, 19, 21, 25, 17, 14};
        case '1': return {4, 12, 4, 4, 4, 4, 14};
        case '2': return {14, 17, 1, 2, 4, 8, 31};
        case '3': return {30, 1, 1, 14, 1, 1, 30};
        case '4': return {2, 6, 10, 18, 31, 2, 2};
        case '5': return {31, 16, 16, 30, 1, 1, 30};
        case '6': return {14, 16, 16, 30, 17, 17, 14};
        case '7': return {31, 1, 2, 4, 8, 8, 8};
        case '8': return {14, 17, 17, 14, 17, 17, 14};
        case '9': return {14, 17, 17, 15, 1, 1, 14};
        case '-': return {0, 0, 0, 31, 0, 0, 0};
        case ':': return {0, 4, 4, 0, 4, 4, 0};
        case '.': return {0, 0, 0, 0, 0, 4, 4};
        case '/': return {1, 1, 2, 4, 8, 16, 16};
        default: return {};
    }
}

std::uint32_t darkness_sources_signature(
    const std::array<game::MapPoint, kDarknessSourceCapacity>& sources,
    const std::size_t source_count) noexcept {
    constexpr std::uint32_t kHashSeed = 2166136261U;
    constexpr std::uint32_t kHashPrime = 16777619U;
    std::uint32_t signature = kHashSeed;
    signature ^= static_cast<std::uint32_t>(source_count);
    signature *= kHashPrime;
    for (std::size_t index = 0U; index < source_count; ++index) {
        const auto quantized_x =
            static_cast<std::int32_t>(std::lroundf(sources[index].x * 4.0F));
        const auto quantized_y =
            static_cast<std::int32_t>(std::lroundf(sources[index].y * 4.0F));
        signature ^= static_cast<std::uint32_t>(quantized_x);
        signature *= kHashPrime;
        signature ^= static_cast<std::uint32_t>(quantized_y);
        signature *= kHashPrime;
    }
    return signature;
}

void format_error_code(const int error_code, char (&text)[11]) noexcept {
    constexpr char kHexDigits[] = "0123456789ABCDEF";
    text[0] = '0';
    text[1] = 'X';
    const std::uint32_t value = static_cast<std::uint32_t>(error_code);
    for (std::uint8_t index = 0; index < 8U; ++index) {
        const std::uint8_t shift = static_cast<std::uint8_t>((7U - index) * 4U);
        text[2U + index] = kHexDigits[(value >> shift) & 0xFU];
    }
    text[10] = '\0';
}

void format_two_digits(const std::uint8_t value, char (&text)[3]) noexcept {
    text[0] = static_cast<char>('0' + ((value / 10U) % 10U));
    text[1] = static_cast<char>('0' + (value % 10U));
    text[2] = '\0';
}

const char* mode_name(const level::LevelMode mode) noexcept {
    switch (mode) {
        case level::LevelMode::Adventure: return "ADVENTURE";
        case level::LevelMode::Puzzle: return "PUZZLE";
        case level::LevelMode::Speed: return "SPEED";
        case level::LevelMode::Dark: return "DARK";
    }
    return "UNKNOWN";
}

std::uint32_t mode_color(const level::LevelMode mode) noexcept {
    switch (mode) {
        case level::LevelMode::Adventure: return kColorConnected;
        case level::LevelMode::Puzzle: return 0xFFD060A0U;
        case level::LevelMode::Speed: return 0xFF40C8F0U;
        case level::LevelMode::Dark: return 0xFF806078U;
    }
    return kColorText;
}

WorldSprite slider_lever_light_sprite(
    const std::uint8_t light_index) noexcept {
    const std::uint8_t clamped = std::clamp<std::uint8_t>(
        light_index,
        1U,
        6U);
    return static_cast<WorldSprite>(
        static_cast<std::uint8_t>(WorldSprite::SliderLeverLight1) +
        clamped - 1U);
}

WorldSprite slider_endpoint_light_sprite(
    const std::uint8_t light_index) noexcept {
    const std::uint8_t clamped = std::clamp<std::uint8_t>(
        light_index,
        1U,
        6U);
    return static_cast<WorldSprite>(
        static_cast<std::uint8_t>(WorldSprite::SliderEndpointLight1) +
        clamped - 1U);
}

WorldSprite timed_bar_sprite(const std::uint8_t light_index) noexcept {
    const std::uint8_t clamped = std::clamp<std::uint8_t>(
        light_index,
        1U,
        6U);
    return static_cast<WorldSprite>(
        static_cast<std::uint8_t>(WorldSprite::TimedBar1) +
        clamped - 1U);
}

WorldSprite timed_bar_light_sprite(
    const std::uint8_t light_index) noexcept {
    const std::uint8_t clamped = std::clamp<std::uint8_t>(
        light_index,
        1U,
        6U);
    return static_cast<WorldSprite>(
        static_cast<std::uint8_t>(WorldSprite::TimedBarLight1) +
        clamped - 1U);
}

void advance_source_spring(
    float& position,
    float& velocity,
    const float target) noexcept {
    const bool far = std::fabs(position - target) > 100.0F;
    const float acceleration =
        -(position - target) / (far ? 20.0F : 10.0F);
    position += velocity;
    velocity += acceleration;
    velocity *= std::fabs(position - target) > 100.0F ? 0.8F : 0.6F;
    if (std::fabs(position - target) < 0.2F &&
        std::fabs(velocity) < 0.2F) {
        position = target;
        velocity = 0.0F;
    }
}

std::uint32_t black_alpha(const float normalized, const std::uint8_t maximum) noexcept {
    const auto alpha = static_cast<std::uint8_t>(std::clamp(
        normalized * static_cast<float>(maximum),
        0.0F,
        static_cast<float>(maximum)));
    return static_cast<std::uint32_t>(alpha) << 24U;
}

bool is_slope(const level::TileType tile) noexcept {
    return tile == level::TileType::SolidSlopeUpRight ||
           tile == level::TileType::SolidSlopeUpLeft ||
           tile == level::TileType::SolidSlopeDownLeft ||
           tile == level::TileType::SolidSlopeDownRight ||
           tile == level::TileType::IceSlopeUpRight ||
           tile == level::TileType::IceSlopeUpLeft ||
           tile == level::TileType::IceSlopeDownLeft ||
           tile == level::TileType::IceSlopeDownRight ||
           tile == level::TileType::FireSlopeLeft ||
           tile == level::TileType::FireSlopeRight ||
           tile == level::TileType::AcidSlopeLeft ||
           tile == level::TileType::AcidSlopeRight;
}

std::uint32_t tile_color(const level::TileType tile) noexcept {
    switch (tile) {
        case level::TileType::Solid:
        case level::TileType::SolidSlopeUpRight:
        case level::TileType::SolidSlopeUpLeft:
        case level::TileType::SolidSlopeDownLeft:
        case level::TileType::SolidSlopeDownRight:
            return kColorPlatform;
        case level::TileType::Ice:
        case level::TileType::IceSlopeUpRight:
        case level::TileType::IceSlopeUpLeft:
        case level::TileType::IceSlopeDownLeft:
        case level::TileType::IceSlopeDownRight:
        case level::TileType::FrozenStart:
            return kColorIce;
        case level::TileType::WaterMiddle:
        case level::TileType::WaterStart:
        case level::TileType::WaterEnd:
            return kColorWater;
        case level::TileType::Fire:
        case level::TileType::FireSlopeLeft:
        case level::TileType::FireSlopeRight:
            return kColorFire;
        case level::TileType::Acid:
        case level::TileType::AcidSlopeLeft:
        case level::TileType::AcidSlopeRight:
            return kColorAcid;
        case level::TileType::WatergirlGem:
            return kColorWatergirl;
        case level::TileType::FireboyGem:
            return kColorFireboy;
        case level::TileType::SharedGem:
            return kColorSharedGem;
        case level::TileType::Empty:
            break;
    }
    return 0U;
}

}  // namespace

bool PspRenderer::initialize() noexcept {
    if (initialized_) {
        return true;
    }

    sceGuInit();
    sceGuStart(GU_DIRECT, g_display_list);
    sceGuDrawBuffer(GU_PSM_8888, reinterpret_cast<void*>(0U), kBufferWidth);
    sceGuDispBuffer(
        kScreenWidth,
        kScreenHeight,
        reinterpret_cast<void*>(kBackBufferOffset),
        kBufferWidth);
    sceGuDepthBuffer(reinterpret_cast<void*>(kDepthBufferOffset), kBufferWidth);
    sceGuOffset(2048 - (kScreenWidth / 2), 2048 - (kScreenHeight / 2));
    sceGuViewport(2048, 2048, kScreenWidth, kScreenHeight);
    sceGuDepthRange(65535, 0);
    sceGuScissor(0, 0, kScreenWidth, kScreenHeight);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuDisable(GU_DEPTH_TEST);
    unbind_texture();
    sceGuEnable(GU_BLEND);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0U, 0U);
    sceGuShadeModel(GU_SMOOTH);
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);

    sceGuStart(GU_DIRECT, g_display_list);
    sceGuClearColor(kColorOutside);
    sceGuClear(GU_COLOR_BUFFER_BIT);
    draw_screen_rect(0.0F, 0.0F, 240.0F, 272.0F, 0xFF302018U);
    draw_screen_rect(240.0F, 0.0F, 240.0F, 272.0F, 0xFF182830U);
    draw_screen_rect(77.0F, 83.0F, 326.0F, 106.0F, kColorPanel);
    draw_screen_rect(77.0F, 83.0F, 163.0F, 4.0F, kColorFireboy);
    draw_screen_rect(240.0F, 83.0F, 163.0F, 4.0F, kColorWatergirl);
    draw_text(126.0F, 108.0F, "FOREST FIRE ICE", 2.0F, kColorText);
    draw_text(195.0F, 144.0F, "LOADING", 1.25F, kColorMutedText);
    draw_screen_rect(126.0F, 168.0F, 228.0F, 4.0F, 0xFF514438U);
    draw_screen_rect(126.0F, 168.0F, 114.0F, 4.0F, kColorConnected);
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();

    static_cast<void>(ui_textures_.initialize());
    render_frame_ = 0;
#ifdef FFI_FOREST_TEMPLE
    forest_effects_timeline_ = {};
#endif
    overlay_timeline_valid_ = false;
    gameplay_assets_ready_ = false;
    gameplay_character_attempted_ = false;
    gameplay_world_attempted_ = false;
    gameplay_death_attempted_ = false;
    gameplay_finish_attempted_ = false;
    tutorial_timeline_valid_ = false;
    initialized_ = true;
    return true;
}

void PspRenderer::preload_ui_texture(const UiTexture texture) noexcept {
    static_cast<void>(ui_textures_.preload(texture));
}

bool PspRenderer::preload_gameplay_assets() noexcept {
    if (!initialized_ || gameplay_assets_ready_) {
        return gameplay_assets_ready_;
    }

    if (!character_textures_.loaded() && !gameplay_character_attempted_) {
        const TextureWarmResult result = character_textures_.warm_initialize(
            "data/textures/characters.pack",
            "data/textures/fireboy.4444",
            "data/textures/watergirl.4444",
            kGameplayAssetWarmBytesPerFrame);
        gameplay_character_attempted_ = result == TextureWarmResult::Failed;
        return false;
    }

    if (!world_textures_.loaded() && !gameplay_world_attempted_) {
        const TextureWarmResult result = world_textures_.warm_initialize(
            "data/textures/world.pack",
            "data/textures/world.4444",
            "data/textures/background.4444",
            "data/textures/ground.4444",
            kGameplayAssetWarmBytesPerFrame);
        gameplay_world_attempted_ = result == TextureWarmResult::Failed;
        return false;
    }

    if (!death_texture_.loaded() && !gameplay_death_attempted_) {
        const TextureWarmResult result = death_texture_.warm_initialize(
            "data/textures/death.4444",
            kGameplayAssetWarmBytesPerFrame);
        gameplay_death_attempted_ = result == TextureWarmResult::Failed;
        return false;
    }

    if (!finish_texture_.loaded() && !gameplay_finish_attempted_) {
        const TextureWarmResult result = finish_texture_.warm_initialize(
            "data/textures/finish.4444",
            kGameplayAssetWarmBytesPerFrame);
        gameplay_finish_attempted_ = result == TextureWarmResult::Failed;
        return false;
    }

    gameplay_assets_ready_ = character_textures_.loaded() &&
        world_textures_.loaded() && death_texture_.loaded() &&
        finish_texture_.loaded();
    return gameplay_assets_ready_;
}

void PspRenderer::shutdown() noexcept {
    if (!initialized_) {
        return;
    }
    unbind_texture();
    sceGuDisplay(GU_FALSE);
    sceGuTerm();
    character_textures_.shutdown();
    death_texture_.shutdown();
    finish_texture_.shutdown();
    ui_textures_.shutdown();
    world_textures_.shutdown();
    gameplay_assets_ready_ = false;
    gameplay_character_attempted_ = false;
    gameplay_world_attempted_ = false;
    gameplay_death_attempted_ = false;
    gameplay_finish_attempted_ = false;
    map_cursor_timeline_valid_ = false;
    initialized_ = false;
}

void PspRenderer::render(
    const game::GameWorld& world,
    const RenderStatus& status) noexcept {
    if (!initialized_) {
        return;
    }

    render_quality_ = status.quality;
    unbind_texture();
    update_overlay_timeline(status);
    if (status.screen != UiScreen::LevelMap) {
        map_cursor_timeline_valid_ = false;
    }

    bool source_ui = false;
    if (status.screen == UiScreen::StartMenu ||
        status.screen == UiScreen::LevelMap) {
        const UiTexture requested_ui =
            status.screen == UiScreen::StartMenu
                ? UiTexture::Start
                : UiTexture::Map;
        source_ui = ui_textures_.select(requested_ui);
    } else {
        static_cast<void>(ui_textures_.select(UiTexture::Overlay));
    }

    sceGuStart(GU_DIRECT, g_display_list);
    sceGuClearColor(kColorOutside);
    sceGuClear(GU_COLOR_BUFFER_BIT);

    if (status.screen == UiScreen::StartMenu ||
        status.screen == UiScreen::LevelMap) {
        if (source_ui) {
            bind_texture(
                ui_textures_.data(),
                UiTextures::kTextureWidth,
                UiTextures::kTextureHeight,
                false,
                TextureFilter::Linear);
            draw_textured_screen_rect(
                kWorldOffsetX,
                0.0F,
                UiTextures::kViewportWidth,
                UiTextures::kViewportHeight,
                0.5F,
                0.5F,
                UiTextures::kViewportWidth - 0.5F,
                UiTextures::kViewportHeight - 0.5F);
            unbind_texture();
        } else if (world_textures_.loaded()) {
            draw_background();
        } else {
            draw_screen_rect(0.0F, 0.0F, 240.0F, 272.0F, 0xFF302018U);
            draw_screen_rect(240.0F, 0.0F, 240.0F, 272.0F, 0xFF182830U);
        }
        if (status.screen == UiScreen::StartMenu) {
            draw_start_menu(status);
        } else {
            draw_level_map(world, status);
        }
        draw_global_controls(status);
        if (status.transition_alpha > 0.0F) {
            // Trans 1053 is an exact 640x480 black shape. Keep it inside the
            // Flash stage so PSP-only hints remain isolated in the side bars.
            draw_world_rect(
                0.0F,
                0.0F,
                game::GameWorld::kStageWidth,
                game::GameWorld::kStageHeight,
                black_alpha(status.transition_alpha, 0xFFU));
        }
        sceGuFinish();
        sceGuSync(0, 0);
        sceDisplayWaitVblankStart();
        sceGuSwapBuffers();
        ++render_frame_;
        return;
    }

    if (world_textures_.loaded()) {
        draw_background();
    } else {
        draw_world_rect(
            0.0F,
            0.0F,
            game::GameWorld::kStageWidth,
            game::GameWorld::kStageHeight,
            kColorWorld);
    }

    const std::array<game::PlayerState, game::GameWorld::kPlayerCount>
        players = interpolated_players(world, status);

    update_tutorial_timeline(world, players, status);

    draw_level(world);
    draw_objects(world);
#ifdef FFI_FOREST_TEMPLE
    if (world_textures_.forest_effects_data() != nullptr) {
        draw_forest_effects(world, status);
    }
#endif

    for (const game::PlayerState& player : players) {
        if (player.dead || status.completion_frame > 0U) {
            continue;
        }
        float contact_normal_x = 0.0F;
        float contact_normal_y = -1.0F;
        bool contact_normal_valid = false;
        world.player_contact_normal(
            player,
            contact_normal_x,
            contact_normal_y,
            contact_normal_valid);
        if (!draw_player_sprite(
                player,
                contact_normal_valid ? contact_normal_x : 0.0F,
                contact_normal_valid ? contact_normal_y : -1.0F)) {
            const std::uint32_t color =
                player.id == game::PlayerId::Fireboy
                    ? kColorFireboy
                    : kColorWatergirl;
            draw_world_rect(player.x, player.y, player.width, player.height, color);
        }

        if (player.id == status.active_player) {
            const float center_x = player.x + player.width * 0.5F;
            draw_world_triangle(
                center_x - 8.0F,
                player.y - 13.0F,
                center_x + 8.0F,
                player.y - 13.0F,
                center_x,
                player.y - 4.0F,
                kColorPanel);
            draw_world_triangle(
                center_x - 5.0F,
                player.y - 11.0F,
                center_x + 5.0F,
                player.y - 11.0F,
                center_x,
                player.y - 5.0F,
                kColorActive);
        }
    }
    if (status.level_failed && status.death_frame > 0U) {
        draw_death_timeline(players, status);
    }
    if (status.completion_frame > 0U) {
        draw_completion_timeline(world, status);
    }
    draw_tutorial();
    // Flash's MaskLayer clips the complete level display list. Apply the dark
    // pass after actors and the death timeline, while leaving HUD/UI above it.
    if (world.level().mode == level::LevelMode::Dark) {
        draw_darkness(world, players, status.logic_tick);
    }

    if (status.host || status.peer_connected) {
        draw_screen_rect(
            8.0F,
            8.0F,
            12.0F,
            12.0F,
            status.peer_connected ? kColorConnected : kColorOffline);
    }
    draw_hud(status);

    if (status.screen == UiScreen::AdhocConnecting ||
        status.screen == UiScreen::AdhocSynchronizing ||
        status.screen == UiScreen::NetworkError) {
        draw_network_overlay(status);
    }

    if (status.takeover_notice) {
        draw_screen_rect(118.0F, 8.0F, 244.0F, 19.0F, kColorPanel);
        draw_text(132.0F, 13.0F, "PEER LOST - SOLO MODE", 1.0F, kColorText);
    }

#ifdef FFI_FOREST_TEMPLE
    draw_forest_panels(world, status);
#else
    if (pause_position_ < kPauseHiddenPosition - 0.2F &&
        result_overlay_ == ResultOverlay::None) {
        const float tapper_alpha = std::clamp(
            std::fabs(
                1.0F -
                (pause_position_ - kPauseShownPosition) /
                    (kPauseHiddenPosition - kPauseShownPosition)),
            0.0F,
            1.0F);
        draw_world_rect(
            0.0F,
            0.0F,
            game::GameWorld::kStageWidth,
            game::GameWorld::kStageHeight,
            black_alpha(tapper_alpha, 0xB0U));
        const float pause_anchor_x =
            kWorldOffsetX + kPauseSourceX * kWorldScale;
        const float pause_anchor_y = pause_position_ * kWorldScale;
        if (ui_textures_.select(UiTexture::Map)) {
            bind_texture(
                ui_textures_.data(),
                UiTextures::kTextureWidth,
                UiTextures::kTextureHeight,
                false,
                TextureFilter::Linear);
            draw_pause_gameover_frame_bound(
                kPauseStaticFrame,
                pause_anchor_x,
                pause_anchor_y);
            unbind_texture();
            if (ui_textures_.select(UiTexture::Start)) {
                bind_texture(
                    ui_textures_.data(),
                    UiTextures::kTextureWidth,
                    UiTextures::kTextureHeight,
                    false,
                    TextureFilter::Linear);
                const auto format_pause_count = [](
                                                    const std::uint16_t value,
                                                    char (&text)[3]) noexcept {
                    const std::uint16_t clamped =
                        std::min<std::uint16_t>(value, 99U);
                    if (clamped >= 10U) {
                        text[0] = static_cast<char>('0' + clamped / 10U);
                        text[1] = static_cast<char>('0' + clamped % 10U);
                        text[2] = '\0';
                    } else {
                        text[0] = static_cast<char>('0' + clamped);
                        text[1] = '\0';
                    }
                };
                char blue_text[3]{};
                char red_text[3]{};
                format_pause_count(
                    world.collected_gems(level::TileType::WatergirlGem),
                    blue_text);
                format_pause_count(
                    world.collected_gems(level::TileType::FireboyGem),
                    red_text);
                draw_result_text_bound(
                    blue_text,
                    ResultTextOrigin{
                        kPauseCountOrigins[0].x,
                        kPauseCountOrigins[0].baseline_y},
                    pause_anchor_x,
                    pause_anchor_y,
                    false);
                draw_result_text_bound(
                    red_text,
                    ResultTextOrigin{
                        kPauseCountOrigins[1].x,
                        kPauseCountOrigins[1].baseline_y},
                    pause_anchor_x,
                    pause_anchor_y,
                    false);
                unbind_texture();
            }
        } else {
            const float panel_y =
                kPanelShownY +
                (pause_position_ - kPauseShownPosition) * kWorldScale;
            draw_source_panel(147.5F, panel_y, 0xFF40D060U);
        }
    }

    // StartGame moves both source controls above the pause menu. Result and
    // GameOver boards are added later in Game.as, so draw the controls before
    // those two late overlays but after the pause panel.
    draw_global_controls(status);

    if (result_overlay_ == ResultOverlay::Complete) {
        const float tapper_alpha = std::clamp(
            std::fabs((result_position_ - kResultInitialPosition) / 390.0F),
            0.0F,
            1.0F);
        draw_screen_rect(
            0.0F,
            0.0F,
            480.0F,
            272.0F,
            black_alpha(tapper_alpha, 0xB0U));
        const float board_anchor_x =
            kWorldOffsetX + kResultBoardSourceX * kWorldScale;
        const float board_anchor_y = result_position_ * kWorldScale;
        if (ui_textures_.select(UiTexture::Start)) {
            bind_texture(
                ui_textures_.data(),
                UiTextures::kTextureWidth,
                UiTextures::kTextureHeight,
                false,
                TextureFilter::Linear);
            draw_result_frame_bound(
                kResultStaticBoard,
                board_anchor_x,
                board_anchor_y);

            const std::uint16_t red_gems = world.collected_gems(
                level::TileType::FireboyGem);
            const std::uint16_t blue_gems = world.collected_gems(
                level::TileType::WatergirlGem);
            const std::uint16_t green_gems = world.collected_gems(
                level::TileType::SharedGem);
            const bool puzzle =
                world.level().mode == level::LevelMode::Puzzle;
            if (puzzle) {
                draw_result_frame_bound(
                    kResultCounters[2],
                    board_anchor_x,
                    board_anchor_y);
            } else {
                draw_result_frame_bound(
                    kResultCounters[0],
                    board_anchor_x,
                    board_anchor_y);
                draw_result_frame_bound(
                    kResultCounters[1],
                    board_anchor_x,
                    board_anchor_y);
            }

            const auto format_count = [](
                                          const std::uint16_t value,
                                          char (&text)[3]) noexcept {
                const std::uint16_t clamped =
                    std::min<std::uint16_t>(value, 99U);
                if (clamped >= 10U) {
                    text[0] = static_cast<char>('0' + clamped / 10U);
                    text[1] = static_cast<char>('0' + clamped % 10U);
                    text[2] = '\0';
                } else {
                    text[0] = static_cast<char>('0' + clamped);
                    text[1] = '\0';
                }
            };
            char red_text[3]{};
            char blue_text[3]{};
            char green_text[3]{};
            format_count(red_gems, red_text);
            format_count(blue_gems, blue_text);
            format_count(green_gems, green_text);
            if (puzzle) {
                draw_result_text_bound(
                    green_text,
                    kResultCounterOrigins[2],
                    board_anchor_x,
                    board_anchor_y,
                    false);
            } else {
                draw_result_text_bound(
                    red_text,
                    kResultCounterOrigins[0],
                    board_anchor_x,
                    board_anchor_y,
                    false);
                draw_result_text_bound(
                    blue_text,
                    kResultCounterOrigins[1],
                    board_anchor_x,
                    board_anchor_y,
                    false);
            }

            const std::uint32_t elapsed_seconds =
                status.completion_elapsed_seconds;
            const std::uint32_t minutes =
                std::min<std::uint32_t>(elapsed_seconds / 60U, 99U);
            const std::uint32_t seconds = elapsed_seconds % 60U;
            const char time_text[8]{
                static_cast<char>('0' + minutes / 10U),
                static_cast<char>('0' + minutes % 10U),
                ' ',
                ':',
                ' ',
                static_cast<char>('0' + seconds / 10U),
                static_cast<char>('0' + seconds % 10U),
                '\0',
            };
            draw_result_text_bound(
                time_text,
                kResultTimeOrigin,
                board_anchor_x,
                board_anchor_y,
                true);

            std::uint8_t grade = 0U;
            const std::size_t map_node = status.selected_map_node;
            const bool met_time =
                map_node < game::kOriginalMapTargetSeconds.size() &&
                elapsed_seconds <= game::kOriginalMapTargetSeconds[map_node];
            if (puzzle) {
                if (green_gems == 1U) {
                    grade = met_time ? 3U : 2U;
                }
            } else {
                const bool collected_required_gems =
                    red_gems == world.total_gems(
                                    level::TileType::FireboyGem) &&
                    blue_gems == world.total_gems(
                                     level::TileType::WatergirlGem);
                grade = static_cast<std::uint8_t>(
                    1U + (met_time ? 1U : 0U) +
                    (collected_required_gems ? 1U : 0U));
            }
            draw_result_frame_bound(
                kResultGrades[grade],
                board_anchor_x,
                board_anchor_y);
            unbind_texture();
        } else {
            const float panel_y =
                kPanelShownY +
                (result_position_ - kResultShownPosition) * kWorldScale;
            draw_source_panel(147.5F, panel_y, 0xFFD040E0U);
            draw_text(184.0F, panel_y + 95.0F, "X OR O MAP", 0.9F, kColorText);
        }
    }

    if (result_overlay_ == ResultOverlay::Failed) {
        const float tapper_alpha = std::clamp(
            std::fabs((result_position_ - kResultInitialPosition) / 390.0F),
            0.0F,
            1.0F);
        draw_screen_rect(
            0.0F,
            0.0F,
            480.0F,
            272.0F,
            black_alpha(tapper_alpha, 0xB0U));
        const float board_anchor_x =
            kWorldOffsetX + kGameOverSourceX * kWorldScale;
        const float board_anchor_y = result_position_ * kWorldScale;
        if (ui_textures_.select(UiTexture::Map)) {
            bind_texture(
                ui_textures_.data(),
                UiTextures::kTextureWidth,
                UiTextures::kTextureHeight,
                false,
                TextureFilter::Linear);
            draw_pause_gameover_frame_bound(
                kGameOverFrame,
                board_anchor_x,
                board_anchor_y);
            unbind_texture();
        } else {
            const float panel_y =
                kPanelShownY +
                (result_position_ - kResultShownPosition) * kWorldScale;
            draw_source_panel(147.5F, panel_y, 0xFFD0D0D0U);
        }
    }

#endif
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();
    ++render_frame_;
}

void PspRenderer::update_overlay_timeline(const RenderStatus& status) noexcept {
    if (status.screen != UiScreen::Gameplay) {
        overlay_timeline_valid_ = false;
        pause_position_ = kPauseHiddenPosition;
        pause_velocity_ = 0.0F;
        pause_transition_ = 0;
        pause_requested_ = false;
        result_overlay_ = ResultOverlay::None;
        return;
    }

    if (!overlay_timeline_valid_) {
        overlay_timeline_valid_ = true;
        overlay_ui_tick_ = status.ui_tick;
        pause_requested_ = status.paused;
        pause_position_ = kPauseHiddenPosition;
        pause_velocity_ = 0.0F;
        pause_transition_ = status.paused ? 1 : 0;
    }
    if (status.paused != pause_requested_) {
        pause_requested_ = status.paused;
        pause_transition_ = status.paused ? 1 : -1;
    }

    ResultOverlay requested_result = ResultOverlay::None;
    if (status.level_completed) {
        requested_result = ResultOverlay::Complete;
    } else if (status.level_failed && status.death_frame >= 32U) {
        requested_result = ResultOverlay::Failed;
    }
    if (requested_result != result_overlay_) {
        result_overlay_ = requested_result;
        result_position_ = kResultInitialPosition;
        result_velocity_ = 0.0F;
    }

    const std::uint32_t elapsed = status.ui_tick - overlay_ui_tick_;
    const std::uint32_t steps =
        std::min<std::uint32_t>(elapsed, 8U);
    overlay_ui_tick_ = status.ui_tick;
    for (std::uint32_t step = 0; step < steps; ++step) {
        if (pause_transition_ != 0) {
            const float target =
                pause_transition_ > 0
                    ? kPauseShownPosition
                    : kPauseHiddenPosition;
            advance_source_spring(
                pause_position_,
                pause_velocity_,
                target);
            if (pause_position_ == target) {
                pause_transition_ = 0;
            }
        }
        if (result_overlay_ != ResultOverlay::None &&
            result_position_ != kResultShownPosition) {
            advance_source_spring(
                result_position_,
                result_velocity_,
                kResultShownPosition);
        }
    }
}

std::array<game::PlayerState, game::GameWorld::kPlayerCount>
PspRenderer::interpolated_players(
    const game::GameWorld& world,
    const RenderStatus& status) noexcept {
    const auto& observed = world.players();
    if (status.screen != UiScreen::Gameplay) {
        motion_valid_ = false;
        return observed;
    }

    const bool reset_history =
        !motion_valid_ ||
        motion_level_index_ != world.level_index() ||
        status.logic_tick < motion_logic_tick_;
    if (reset_history) {
        previous_players_ = observed;
        current_players_ = observed;
        motion_level_index_ = world.level_index();
        motion_logic_tick_ = status.logic_tick;
        motion_alpha_ = status.interpolation_alpha;
        motion_valid_ = true;
    } else if (status.logic_tick != motion_logic_tick_) {
        previous_players_ = current_players_;
        current_players_ = observed;
        motion_logic_tick_ = status.logic_tick;
        motion_alpha_ = status.interpolation_alpha;
    } else {
        current_players_ = observed;
        motion_alpha_ = status.interpolation_alpha;
    }

    const float alpha =
        status.paused || status.level_completed ? 1.0F : motion_alpha_;
    auto result = current_players_;
    for (std::size_t index = 0; index < result.size(); ++index) {
        const game::PlayerState& previous = previous_players_[index];
        const game::PlayerState& current = current_players_[index];
        const float delta_x = current.x - previous.x;
        const float delta_y = current.y - previous.y;
        if (previous.dead != current.dead ||
            std::fabs(delta_x) > 96.0F ||
            std::fabs(delta_y) > 96.0F) {
            continue;
        }
        result[index].x = previous.x + delta_x * alpha;
        result[index].y = previous.y + delta_y * alpha;
    }
    return result;
}

void PspRenderer::draw_screen_rect(
    const float x,
    const float y,
    const float width,
    const float height,
    const std::uint32_t color) noexcept {
    auto* vertices = static_cast<ColoredVertex*>(sceGuGetMemory(2 * sizeof(ColoredVertex)));
    vertices[0] = ColoredVertex{color, x, y, 0.0F};
    vertices[1] = ColoredVertex{color, x + width, y + height, 0.0F};

    sceGuDrawArray(
        GU_SPRITES,
        GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
        2,
        nullptr,
        vertices);
}

void PspRenderer::draw_world_rect(
    const float x,
    const float y,
    const float width,
    const float height,
    const std::uint32_t color) noexcept {
    draw_screen_rect(
        kWorldOffsetX + x * kWorldScale,
        y * kWorldScale,
        width * kWorldScale,
        height * kWorldScale,
        color);
}

void PspRenderer::draw_screen_triangle(
    const float x0,
    const float y0,
    const float x1,
    const float y1,
    const float x2,
    const float y2,
    const std::uint32_t color) noexcept {
    auto* const vertices = static_cast<ColoredVertex*>(
        sceGuGetMemory(3 * sizeof(ColoredVertex)));
    vertices[0] = ColoredVertex{color, x0, y0, 0.0F};
    vertices[1] = ColoredVertex{color, x1, y1, 0.0F};
    vertices[2] = ColoredVertex{color, x2, y2, 0.0F};
    sceGuDrawArray(
        GU_TRIANGLES,
        GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
        3,
        nullptr,
        vertices);
}

void PspRenderer::draw_world_triangle(
    const float x0,
    const float y0,
    const float x1,
    const float y1,
    const float x2,
    const float y2,
    const std::uint32_t color) noexcept {
    draw_screen_triangle(
        kWorldOffsetX + x0 * kWorldScale,
        y0 * kWorldScale,
        kWorldOffsetX + x1 * kWorldScale,
        y1 * kWorldScale,
        kWorldOffsetX + x2 * kWorldScale,
        y2 * kWorldScale,
        color);
}

void PspRenderer::draw_screen_line(
    const float x0,
    const float y0,
    const float x1,
    const float y1,
    const float thickness,
    const std::uint32_t color) noexcept {
    const float delta_x = x1 - x0;
    const float delta_y = y1 - y0;
    const float length = std::sqrt(delta_x * delta_x + delta_y * delta_y);
    if (length <= 0.001F) {
        return;
    }
    const float normal_x = -delta_y / length * thickness * 0.5F;
    const float normal_y = delta_x / length * thickness * 0.5F;
    draw_screen_triangle(
        x0 + normal_x, y0 + normal_y,
        x1 + normal_x, y1 + normal_y,
        x1 - normal_x, y1 - normal_y,
        color);
    draw_screen_triangle(
        x0 + normal_x, y0 + normal_y,
        x1 - normal_x, y1 - normal_y,
        x0 - normal_x, y0 - normal_y,
        color);
}

void PspRenderer::draw_world_line(
    const float x0,
    const float y0,
    const float x1,
    const float y1,
    const float thickness,
    const std::uint32_t color) noexcept {
    const float delta_x = x1 - x0;
    const float delta_y = y1 - y0;
    const float length =
        std::sqrt(delta_x * delta_x + delta_y * delta_y);
    if (length <= 0.001F) {
        return;
    }
    const float normal_x =
        -delta_y / length * thickness * 0.5F;
    const float normal_y =
        delta_x / length * thickness * 0.5F;
    draw_world_triangle(
        x0 + normal_x,
        y0 + normal_y,
        x1 + normal_x,
        y1 + normal_y,
        x1 - normal_x,
        y1 - normal_y,
        color);
    draw_world_triangle(
        x0 + normal_x,
        y0 + normal_y,
        x1 - normal_x,
        y1 - normal_y,
        x0 - normal_x,
        y0 - normal_y,
        color);
}

void PspRenderer::draw_world_gradient_beam(
    const game::LightBeamSegment& beam) noexcept {
    float delta_x = beam.x1 - beam.x0;
    float delta_y = beam.y1 - beam.y0;
    float length = std::sqrt(delta_x * delta_x + delta_y * delta_y);
    if (length <= 0.001F) {
        return;
    }
    const float tangent_x = delta_x / length;
    const float tangent_y = delta_y / length;
    constexpr float kSourceTrimPixels = 11.0F * kFlashToPspScale;
    float start_trim = length > kSourceTrimPixels
        ? kSourceTrimPixels
        : 0.0F;
    float end_trim =
        beam.reflected_end && length > 2.0F * kSourceTrimPixels
            ? kSourceTrimPixels
            : 0.0F;
    if (start_trim + end_trim >= length) {
        start_trim = 0.0F;
        end_trim = 0.0F;
    }
    const float start_x = beam.x0 + tangent_x * start_trim;
    const float start_y = beam.y0 + tangent_y * start_trim;
    const float end_x = beam.x1 - tangent_x * end_trim;
    const float end_y = beam.y1 - tangent_y * end_trim;
    delta_x = end_x - start_x;
    delta_y = end_y - start_y;
    length = std::sqrt(delta_x * delta_x + delta_y * delta_y);
    if (length <= 0.001F) {
        return;
    }

    constexpr float kBeamWidth = 20.0F * kFlashToPspScale;
    constexpr std::array<std::uint8_t, 5> kGradientRatios = {
        0U,
        63U,
        127U,
        190U,
        255U,
    };
    constexpr std::array<std::uint8_t, 5> kGradientAlpha = {
        0U,
        77U,
        128U,
        77U,
        0U,
    };
    const float normal_x = -delta_y / length;
    const float normal_y = delta_x / length;
    auto* const vertices = static_cast<ColoredVertex*>(
        sceGuGetMemory(kGradientRatios.size() * 2U * sizeof(ColoredVertex)));
    for (std::size_t index = 0; index < kGradientRatios.size(); ++index) {
        const float ratio =
            static_cast<float>(kGradientRatios[index]) / 255.0F;
        const float offset = (ratio - 0.5F) * kBeamWidth;
        const std::uint32_t color = source_rgb_to_abgr(
            beam.source_rgb,
            kGradientAlpha[index]);
        vertices[index * 2U] = ColoredVertex{
            color,
            kWorldOffsetX + (start_x + normal_x * offset) * kWorldScale,
            (start_y + normal_y * offset) * kWorldScale,
            0.0F,
        };
        vertices[index * 2U + 1U] = ColoredVertex{
            color,
            kWorldOffsetX + (end_x + normal_x * offset) * kWorldScale,
            (end_y + normal_y * offset) * kWorldScale,
            0.0F,
        };
    }
    sceGuDrawArray(
        GU_TRIANGLE_STRIP,
        GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
        static_cast<int>(kGradientRatios.size() * 2U),
        nullptr,
        vertices);
}

void PspRenderer::draw_world_outline(
    const float x,
    const float y,
    const float width,
    const float height,
    const float thickness,
    const std::uint32_t color) noexcept {
    draw_world_rect(x, y, width, thickness, color);
    draw_world_rect(x, y + height - thickness, width, thickness, color);
    draw_world_rect(x, y, thickness, height, color);
    draw_world_rect(x + width - thickness, y, thickness, height, color);
}

void PspRenderer::bind_texture(
    const std::uint16_t* const texture,
    const std::uint16_t width,
    const std::uint16_t height,
    const bool repeat,
    const TextureFilter filter) noexcept {
    if (texture == nullptr || width == 0U || height == 0U) {
        unbind_texture();
        return;
    }

    const TextureFilter effective_filter =
        render_quality_ == RenderQuality::High
            ? TextureFilter::Linear
            : (render_quality_ == RenderQuality::Low
                   ? TextureFilter::Nearest
                   : filter);
    const bool repeat_mode = texture_state_.active && texture_state_.texture == texture &&
        texture_state_.width == width &&
        texture_state_.height == height &&
        texture_state_.repeat == repeat &&
        texture_state_.filter == effective_filter;
    if (repeat_mode) {
        return;
    }

    const bool same_texture = texture_state_.active &&
        texture_state_.texture == texture &&
        texture_state_.width == width &&
        texture_state_.height == height;
    const unsigned int min_filter =
        effective_filter == TextureFilter::Linear ? GU_LINEAR : GU_NEAREST;
    sceGuEnable(GU_TEXTURE_2D);
    if (!same_texture) {
        sceGuTexMode(GU_PSM_4444, 0, 0, 1);
        sceGuTexImage(0, width, height, width, texture);
        sceGuTexFunc(GU_TFX_REPLACE, GU_TCC_RGBA);
    }
    if (!same_texture || texture_state_.filter != effective_filter) {
        sceGuTexFilter(min_filter, min_filter);
    }
    if (!same_texture || texture_state_.repeat != repeat) {
        sceGuTexWrap(
            repeat ? GU_REPEAT : GU_CLAMP,
            repeat ? GU_REPEAT : GU_CLAMP);
    }
    texture_state_.texture = texture;
    texture_state_.width = width;
    texture_state_.height = height;
    texture_state_.repeat = repeat;
    texture_state_.filter = effective_filter;
    texture_state_.active = true;
}

void PspRenderer::unbind_texture() noexcept {
    if (!texture_state_.active) {
        return;
    }
    sceGuDisable(GU_TEXTURE_2D);
    texture_state_.active = false;
}

void PspRenderer::draw_textured_screen_rect(
    const float x,
    const float y,
    const float width,
    const float height,
    const float left_u,
    const float top_v,
    const float right_u,
    const float bottom_v) noexcept {
    auto* vertices =
        static_cast<TexturedVertex*>(
            sceGuGetMemory(2 * sizeof(TexturedVertex)));
    vertices[0] = TexturedVertex{left_u, top_v, x, y, 0.0F};
    vertices[1] = TexturedVertex{
        right_u,
        bottom_v,
        x + width,
        y + height,
        0.0F,
    };
    sceGuDrawArray(
        GU_SPRITES,
        GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
        2,
        nullptr,
        vertices);
}

void PspRenderer::draw_textured_world_rect(
    const float x,
    const float y,
    const float width,
    const float height,
    const float texture_width,
    const float texture_height) noexcept {
    draw_textured_screen_rect(
        kWorldOffsetX + x * kWorldScale,
        y * kWorldScale,
        width * kWorldScale,
        height * kWorldScale,
        x / game::GameWorld::kStageWidth * texture_width,
        y / game::GameWorld::kStageHeight * texture_height,
        (x + width) / game::GameWorld::kStageWidth * texture_width,
        (y + height) / game::GameWorld::kStageHeight * texture_height);
}

void PspRenderer::draw_textured_world_triangle(
    const float x0,
    const float y0,
    const float x1,
    const float y1,
    const float x2,
    const float y2,
    const float texture_width,
    const float texture_height) noexcept {
    auto* vertices =
        static_cast<TexturedVertex*>(
            sceGuGetMemory(3 * sizeof(TexturedVertex)));
    vertices[0] = TexturedVertex{
        x0 / game::GameWorld::kStageWidth * texture_width,
        y0 / game::GameWorld::kStageHeight * texture_height,
        kWorldOffsetX + x0 * kWorldScale,
        y0 * kWorldScale,
        0.0F,
    };
    vertices[1] = TexturedVertex{
        x1 / game::GameWorld::kStageWidth * texture_width,
        y1 / game::GameWorld::kStageHeight * texture_height,
        kWorldOffsetX + x1 * kWorldScale,
        y1 * kWorldScale,
        0.0F,
    };
    vertices[2] = TexturedVertex{
        x2 / game::GameWorld::kStageWidth * texture_width,
        y2 / game::GameWorld::kStageHeight * texture_height,
        kWorldOffsetX + x2 * kWorldScale,
        y2 * kWorldScale,
        0.0F,
    };
    sceGuDrawArray(
        GU_TRIANGLES,
        GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
        3,
        nullptr,
        vertices);
}

void PspRenderer::draw_background() noexcept {
    const std::uint16_t width = world_textures_.texture_width();
    const std::uint16_t height = world_textures_.texture_height();
    if (!world_textures_.loaded() || width == 0U || height == 0U) {
        draw_screen_rect(0.0F, 0.0F, 240.0F, 272.0F, 0xFF302018U);
        draw_screen_rect(
            240.0F,
            0.0F,
            240.0F,
            272.0F,
            0xFF182830U);
        return;
    }
    bind_texture(
        world_textures_.background_data(),
        width,
        height,
        false,
        TextureFilter::Linear);
    draw_textured_screen_rect(
        kWorldOffsetX,
        0.0F,
        kWorldViewportWidth,
        static_cast<float>(kScreenHeight),
        0.0F,
        0.0F,
        static_cast<float>(width),
        static_cast<float>(height));
    unbind_texture();
}

bool PspRenderer::draw_world_sprite_bound(
    const WorldSprite sprite,
    const float center_x,
    const float center_y,
    const float width,
    const float height,
    const float angle,
    const bool flip_x,
    const bool flip_y,
    const std::uint8_t variant,
    const float source_height) noexcept {
    const WorldFrame* const frame =
        world_textures_.frame(sprite, render_frame_, variant);
    if (frame == nullptr) {
        return false;
    }
    return draw_world_frame_bound(
        *frame, center_x, center_y, width, height, angle, flip_x, flip_y, source_height);
}

bool PspRenderer::draw_world_frame_bound(
    const WorldFrame& frame,
    const float center_x,
    const float center_y,
    const float width,
    const float height,
    const float angle,
    const bool flip_x,
    const bool flip_y,
    const float source_height,
    const float source_top) noexcept {
    const float draw_width =
        width > 0.0F ? width : static_cast<float>(frame.width);
    const float draw_height =
        height > 0.0F ? height : static_cast<float>(frame.height);
    const float half_width = draw_width * 0.5F;
    const float half_height = draw_height * 0.5F;
    if (draw_width <= 0.0F || draw_height <= 0.0F) {
        return false;
    }

    const float left_world = center_x - half_width;
    const float right_world = center_x + half_width;
    const float top_world = center_y - half_height;
    const float bottom_world = center_y + half_height;
    if (right_world < 0.0F || left_world > game::GameWorld::kStageWidth ||
        bottom_world < 0.0F || top_world > game::GameWorld::kStageHeight) {
        return true;
    }

    constexpr float kAxisAlignedEpsilon = 0.0001F;
    const float inset_u = frame.width > 1U ? 0.5F : 0.0F;
    const float frame_height = static_cast<float>(frame.height) - source_top;
    const float sampled_height = source_height > 0.0F
        ? std::min(source_height, frame_height) : frame_height;
    const float inset_v = sampled_height > 1.0F ? 0.5F : 0.0F;
    float left_u = static_cast<float>(frame.x) + inset_u;
    float right_u = static_cast<float>(frame.x + frame.width) - inset_u;
    float top_v = static_cast<float>(frame.y) + source_top + inset_v;
    float bottom_v = static_cast<float>(frame.y) + source_top + sampled_height - inset_v;
    if (flip_x) {
        std::swap(left_u, right_u);
    }
    if (flip_y) {
        std::swap(top_v, bottom_v);
    }

    if (std::fabs(angle) <= kAxisAlignedEpsilon) {
        auto* vertices =
            static_cast<TexturedVertex*>(
                sceGuGetMemory(4 * sizeof(TexturedVertex)));
        vertices[0] = TexturedVertex{
            left_u,
            top_v,
            kWorldOffsetX + left_world * kWorldScale,
            top_world * kWorldScale,
            0.0F,
        };
        vertices[1] = TexturedVertex{
            right_u,
            top_v,
            kWorldOffsetX + right_world * kWorldScale,
            top_world * kWorldScale,
            0.0F,
        };
        vertices[2] = TexturedVertex{
            right_u,
            bottom_v,
            kWorldOffsetX + right_world * kWorldScale,
            bottom_world * kWorldScale,
            0.0F,
        };
        vertices[3] = TexturedVertex{
            left_u,
            bottom_v,
            kWorldOffsetX + left_world * kWorldScale,
            bottom_world * kWorldScale,
            0.0F,
        };
        sceGuDrawArray(
            GU_TRIANGLE_FAN,
            GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
            4,
            nullptr,
            vertices);
        return true;
    }

    const float cosine = std::cos(angle);
    const float sine = std::sin(angle);

    const std::array<float, 4> u = {
        left_u,
        right_u,
        right_u,
        left_u,
    };
    const std::array<float, 4> v = {
        top_v,
        top_v,
        bottom_v,
        bottom_v,
    };

    const float min_x = std::min({
        center_x - half_width * std::fabs(cosine) + half_height * std::fabs(sine),
        center_x + half_width * std::fabs(cosine) + half_height * std::fabs(sine),
        center_x + half_width * std::fabs(cosine) - half_height * std::fabs(sine),
        center_x - half_width * std::fabs(cosine) - half_height * std::fabs(sine),
    });
    const float max_x = std::max({
        center_x - half_width * std::fabs(cosine) + half_height * std::fabs(sine),
        center_x + half_width * std::fabs(cosine) + half_height * std::fabs(sine),
        center_x + half_width * std::fabs(cosine) - half_height * std::fabs(sine),
        center_x - half_width * std::fabs(cosine) - half_height * std::fabs(sine),
    });
    const float min_y = std::min({
        center_y - half_width * std::fabs(sine) - half_height * std::fabs(cosine),
        center_y - half_width * std::fabs(sine) + half_height * std::fabs(cosine),
        center_y + half_width * std::fabs(sine) + half_height * std::fabs(cosine),
        center_y + half_width * std::fabs(sine) - half_height * std::fabs(cosine),
    });
    const float max_y = std::max({
        center_y - half_width * std::fabs(sine) - half_height * std::fabs(cosine),
        center_y - half_width * std::fabs(sine) + half_height * std::fabs(cosine),
        center_y + half_width * std::fabs(sine) + half_height * std::fabs(cosine),
        center_y + half_width * std::fabs(sine) - half_height * std::fabs(cosine),
    });
    if (min_x > game::GameWorld::kStageWidth || max_x < 0.0F ||
        min_y > game::GameWorld::kStageHeight || max_y < 0.0F) {
        return true;
    }

    const std::array<float, 4> local_x = {
        -half_width,
        half_width,
        half_width,
        -half_width,
    };
    const std::array<float, 4> local_y = {
        -half_height,
        -half_height,
        half_height,
        half_height,
    };

    auto* vertices =
        static_cast<TexturedVertex*>(
            sceGuGetMemory(4 * sizeof(TexturedVertex)));
    for (std::size_t index = 0; index < 4; ++index) {
        const float world_x =
            center_x + local_x[index] * cosine - local_y[index] * sine;
        const float world_y =
            center_y + local_x[index] * sine + local_y[index] * cosine;
        vertices[index] = TexturedVertex{
            u[index],
            v[index],
            kWorldOffsetX + world_x * kWorldScale,
            world_y * kWorldScale,
            0.0F,
        };
    }
    sceGuDrawArray(
        GU_TRIANGLE_FAN,
        GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
        4,
        nullptr,
        vertices);
    return true;
}

bool PspRenderer::draw_world_sprite_clipped(
    const WorldSprite sprite,
    const float center_x,
    const float center_y,
    const float clip_left,
    const float clip_top,
    const float clip_right,
    const float clip_bottom,
    const float width,
    const float height,
    const bool flip_x,
    const bool flip_y,
    const std::uint8_t variant) noexcept {
    const WorldFrame* const frame =
        world_textures_.frame(sprite, render_frame_, variant);
    if (frame == nullptr) {
        return false;
    }
    const float draw_width =
        width > 0.0F ? width : static_cast<float>(frame->width);
    const float draw_height =
        height > 0.0F ? height : static_cast<float>(frame->height);
    if (draw_width <= 0.0F || draw_height <= 0.0F) {
        return false;
    }

    const float left = center_x - draw_width * 0.5F;
    const float top = center_y - draw_height * 0.5F;
    const float right = left + draw_width;
    const float bottom = top + draw_height;
    const float visible_left = std::max(left, clip_left);
    const float visible_top = std::max(top, clip_top);
    const float visible_right = std::min(right, clip_right);
    const float visible_bottom = std::min(bottom, clip_bottom);
    if (visible_right <= visible_left || visible_bottom <= visible_top) {
        return true;
    }
    if (visible_right < 0.0F ||
        visible_left > game::GameWorld::kStageWidth ||
        visible_bottom < 0.0F ||
        visible_top > game::GameWorld::kStageHeight) {
        return true;
    }

    const float left_fraction = (visible_left - left) / draw_width;
    const float right_fraction = (visible_right - left) / draw_width;
    const float top_fraction = (visible_top - top) / draw_height;
    const float bottom_fraction = (visible_bottom - top) / draw_height;
    const float inset_u = frame->width > 1U ? 0.5F : 0.0F;
    const float inset_v = frame->height > 1U ? 0.5F : 0.0F;
    float source_left = static_cast<float>(frame->x) + inset_u;
    float source_right =
        static_cast<float>(frame->x + frame->width) - inset_u;
    float source_top = static_cast<float>(frame->y) + inset_v;
    float source_bottom =
        static_cast<float>(frame->y + frame->height) - inset_v;
    if (flip_x) {
        std::swap(source_left, source_right);
    }
    if (flip_y) {
        std::swap(source_top, source_bottom);
    }
    const float left_u =
        source_left + (source_right - source_left) * left_fraction;
    const float right_u =
        source_left + (source_right - source_left) * right_fraction;
    const float top_v =
        source_top + (source_bottom - source_top) * top_fraction;
    const float bottom_v =
        source_top + (source_bottom - source_top) * bottom_fraction;

    auto* vertices = static_cast<TexturedVertex*>(
        sceGuGetMemory(4 * sizeof(TexturedVertex)));
    vertices[0] = TexturedVertex{
        left_u,
        top_v,
        kWorldOffsetX + visible_left * kWorldScale,
        visible_top * kWorldScale,
        0.0F,
    };
    vertices[1] = TexturedVertex{
        right_u,
        top_v,
        kWorldOffsetX + visible_right * kWorldScale,
        visible_top * kWorldScale,
        0.0F,
    };
    vertices[2] = TexturedVertex{
        right_u,
        bottom_v,
        kWorldOffsetX + visible_right * kWorldScale,
        visible_bottom * kWorldScale,
        0.0F,
    };
    vertices[3] = TexturedVertex{
        left_u,
        bottom_v,
        kWorldOffsetX + visible_left * kWorldScale,
        visible_bottom * kWorldScale,
        0.0F,
    };
    sceGuDrawArray(
        GU_TRIANGLE_FAN,
        GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
        4,
        nullptr,
        vertices);
    return true;
}

void PspRenderer::draw_level(const game::GameWorld& world) noexcept {
    const level::LevelDefinition& definition = world.level();
    constexpr float half_tile = game::GameWorld::kTileSize * 0.5F;
    const auto tile_geometry = [](
                                   const std::size_t column,
                                   const std::size_t row,
                                   float& center_x,
                                   float& center_y,
                                   float& left,
                                   float& top,
                                   float& right,
                                   float& bottom) noexcept {
        center_x =
            game::GameWorld::kLevelOffset +
            static_cast<float>(column) * game::GameWorld::kTileSize;
        center_y =
            game::GameWorld::kLevelOffset +
            static_cast<float>(row) * game::GameWorld::kTileSize;
        left = center_x - half_tile;
        top = center_y - half_tile;
        right = center_x + half_tile;
        bottom = center_y + half_tile;
    };

    if (!world_textures_.loaded()) {
        for (std::size_t row = 0; row < definition.height; ++row) {
            for (std::size_t column = 0; column < definition.width; ++column) {
                if (!world.tile_visible(column, row)) {
                    continue;
                }
                const level::TileType tile = world.tile_at(column, row);
                if (tile == level::TileType::Empty) {
                    continue;
                }
                float center_x = 0.0F;
                float center_y = 0.0F;
                float left = 0.0F;
                float top = 0.0F;
                float right = 0.0F;
                float bottom = 0.0F;
                tile_geometry(
                    column,
                    row,
                    center_x,
                    center_y,
                    left,
                    top,
                    right,
                    bottom);
                const bool frozen = world.tile_frozen(column, row);
                const std::uint32_t color =
                    frozen ? kColorIce : tile_color(tile);

                if (tile == level::TileType::WatergirlGem ||
                    tile == level::TileType::FireboyGem ||
                    tile == level::TileType::SharedGem) {
                    const float gem_y =
                        tile == level::TileType::SharedGem
                            ? center_y
                            : center_y + half_tile;
                    draw_world_triangle(
                        center_x,
                        gem_y - 6.0F,
                        right - 2.0F,
                        gem_y,
                        center_x,
                        gem_y + 6.0F,
                        color);
                    draw_world_triangle(
                        center_x,
                        gem_y - 6.0F,
                        center_x,
                        gem_y + 6.0F,
                        left + 2.0F,
                        gem_y,
                        color);
                    continue;
                }
                if (frozen) {
                    draw_world_rect(
                        left,
                        top,
                        game::GameWorld::kTileSize,
                        game::GameWorld::kTileSize,
                        kColorIce);
                    continue;
                }
                const bool half_flat =
                    tile == level::TileType::WaterMiddle ||
                    tile == level::TileType::Fire ||
                    tile == level::TileType::Acid;
                const bool half_left =
                    tile == level::TileType::WaterStart ||
                    tile == level::TileType::FrozenStart ||
                    tile == level::TileType::FireSlopeLeft ||
                    tile == level::TileType::AcidSlopeLeft;
                const bool half_right =
                    tile == level::TileType::WaterEnd ||
                    tile == level::TileType::FireSlopeRight ||
                    tile == level::TileType::AcidSlopeRight;
                if (half_flat || half_left || half_right) {
                    draw_world_rect(
                        left,
                        center_y,
                        game::GameWorld::kTileSize,
                        half_tile,
                        kColorPlatform);
                    if (half_left) {
                        draw_world_triangle(
                            left,
                            top,
                            left,
                            center_y,
                            right,
                            center_y,
                            kColorPlatform);
                    } else if (half_right) {
                        draw_world_triangle(
                            right,
                            top,
                            left,
                            center_y,
                            right,
                            center_y,
                            kColorPlatform);
                    }
                    draw_world_rect(
                        left,
                        top,
                        game::GameWorld::kTileSize,
                        half_tile,
                        color);
                    continue;
                }
                if (!is_slope(tile)) {
                    draw_world_rect(
                        left,
                        top,
                        game::GameWorld::kTileSize,
                        game::GameWorld::kTileSize,
                        color);
                } else if (
                    tile == level::TileType::SolidSlopeUpRight ||
                    tile == level::TileType::IceSlopeUpRight) {
                    draw_world_triangle(
                        left,
                        top,
                        left,
                        bottom,
                        right,
                        bottom,
                        color);
                } else if (
                    tile == level::TileType::SolidSlopeUpLeft ||
                    tile == level::TileType::IceSlopeUpLeft) {
                    draw_world_triangle(
                        right,
                        top,
                        left,
                        bottom,
                        right,
                        bottom,
                        color);
                } else if (
                    tile == level::TileType::SolidSlopeDownLeft ||
                    tile == level::TileType::IceSlopeDownLeft) {
                    draw_world_triangle(
                        left,
                        top,
                        right,
                        top,
                        right,
                        bottom,
                        color);
                } else {
                    draw_world_triangle(
                        left,
                        top,
                        right,
                        top,
                        left,
                        bottom,
                        color);
                }
            }
        }

        const auto draw_fallback_door = [](const level::Vector2 position,
                                            const std::uint32_t color) noexcept {
            const float center_x =
                game::GameWorld::kLevelOffset +
                position.x * game::GameWorld::kTileSize;
            const float center_y =
                game::GameWorld::kLevelOffset +
                (position.y + 0.66F) * game::GameWorld::kTileSize;
            draw_world_outline(
                center_x - 11.0F,
                center_y - 20.0F,
                22.0F,
                40.0F,
                2.0F,
                color);
        };
        draw_fallback_door(definition.fireboy_finish, kColorFireboy);
        draw_fallback_door(definition.watergirl_finish, kColorWatergirl);
        return;
    }

#ifdef FFI_FOREST_TEMPLE
    // The original SlidersAndRots layer sits under the cached terrain.
    bind_texture(
        world_textures_.atlas_data(), world_textures_.texture_width(),
        world_textures_.texture_height(), false, TextureFilter::Nearest);
    for (std::size_t index = 0; index < world.runtime_platform_count(); ++index) {
        const auto& platform = world.runtime_platforms()[index];
        if (!platform.movable && !platform.motorized_hinge) {
            continue;
        }
        const std::uint8_t variant = mechanism_variant(platform.light_index, platform.active);
        const WorldFrame* art =
            world_textures_.frame(WorldSprite::SlidePlatform, render_frame_, variant);
        if (art == nullptr) {
            continue;
        }
        const float center_x = platform.x + platform.width * 0.5F;
        const float center_y = platform.y + platform.height * 0.5F;
        const float visual_height = platform.movable ? platform.height / 0.8F : platform.height;
        const bool horizontal = platform.width > visual_height;
        const float bar_width = horizontal ? visual_height : platform.width;
        const float bar_height = horizontal ? platform.width : visual_height;
        const float angle = platform.motorized_hinge ? platform.translation : 0.0F;
        // Platform1.bar keeps its authored local translation.
        constexpr float offset_y = 0.35F * kFlashToPspScale;
        static_cast<void>(draw_world_sprite_bound(
            WorldSprite::SlidePlatform,
            center_x - std::sin(angle) * offset_y,
            center_y + std::cos(angle) * offset_y,
            art->width * bar_width / (20.0F * kFlashToPspScale),
            art->height * bar_height / (80.0F * kFlashToPspScale),
            angle + (horizontal ? kPi * 0.5F : 0.0F),
            false, false, variant));
    }
    unbind_texture();
    const std::uint16_t* const terrain = world_textures_.select_terrain(
        world.level_index(), world.source_hash_prefix());
    if (terrain != nullptr) {
        bind_texture(terrain, 512, 512, false, TextureFilter::Nearest);
        draw_textured_screen_rect(
            kWorldOffsetX, 0.0F, kWorldViewportWidth, 272.0F,
            0.0F, 0.0F, 363.0F, 272.0F);
        unbind_texture();
    } else {
#endif
    const float texture_width =
        static_cast<float>(world_textures_.texture_width());
    const float texture_height =
        static_cast<float>(world_textures_.texture_height());
    bind_texture(
        world_textures_.ground_data(),
        world_textures_.texture_width(),
        world_textures_.texture_height(),
        false,
        TextureFilter::Nearest);
    for (std::size_t row = 0; row < definition.height; ++row) {
        for (std::size_t column = 0; column < definition.width; ++column) {
            const level::TileType tile = world.tile_at(column, row);
            if (tile == level::TileType::Empty ||
                tile == level::TileType::WatergirlGem ||
                tile == level::TileType::FireboyGem ||
                tile == level::TileType::SharedGem ||
                world.tile_frozen(column, row) ||
                tile == level::TileType::Ice ||
                tile == level::TileType::IceSlopeUpRight ||
                tile == level::TileType::IceSlopeUpLeft ||
                tile == level::TileType::IceSlopeDownLeft ||
                tile == level::TileType::IceSlopeDownRight) {
                continue;
            }
            float center_x = 0.0F;
            float center_y = 0.0F;
            float left = 0.0F;
            float top = 0.0F;
            float right = 0.0F;
            float bottom = 0.0F;
            tile_geometry(
                column,
                row,
                center_x,
                center_y,
                left,
                top,
                right,
                bottom);

            const bool half_flat =
                tile == level::TileType::WaterMiddle ||
                tile == level::TileType::Fire ||
                tile == level::TileType::Acid;
            const bool half_left =
                tile == level::TileType::WaterStart ||
                tile == level::TileType::FrozenStart ||
                tile == level::TileType::FireSlopeLeft ||
                tile == level::TileType::AcidSlopeLeft;
            const bool half_right =
                tile == level::TileType::WaterEnd ||
                tile == level::TileType::FireSlopeRight ||
                tile == level::TileType::AcidSlopeRight;
            if (half_flat || half_left || half_right) {
                draw_textured_world_rect(
                    left,
                    center_y,
                    game::GameWorld::kTileSize,
                    half_tile,
                    texture_width,
                    texture_height);
                if (half_left) {
                    draw_textured_world_triangle(
                        left,
                        top,
                        left,
                        center_y,
                        right,
                        center_y,
                        texture_width,
                        texture_height);
                } else if (half_right) {
                    draw_textured_world_triangle(
                        right,
                        top,
                        left,
                        center_y,
                        right,
                        center_y,
                        texture_width,
                        texture_height);
                }
            } else if (tile == level::TileType::Solid) {
                std::size_t run_end = column + 1U;
                while (run_end < definition.width &&
                       world.tile_at(run_end, row) == level::TileType::Solid) {
                    ++run_end;
                }
                draw_textured_world_rect(
                    left,
                    top,
                    static_cast<float>(run_end - column) *
                        game::GameWorld::kTileSize,
                    game::GameWorld::kTileSize,
                    texture_width,
                    texture_height);
                column = run_end - 1U;
            } else if (tile == level::TileType::SolidSlopeUpRight) {
                draw_textured_world_triangle(
                    left,
                    top,
                    left,
                    bottom,
                    right,
                    bottom,
                    texture_width,
                    texture_height);
            } else if (tile == level::TileType::SolidSlopeUpLeft) {
                draw_textured_world_triangle(
                    right,
                    top,
                    left,
                    bottom,
                    right,
                    bottom,
                    texture_width,
                    texture_height);
            } else if (tile == level::TileType::SolidSlopeDownLeft) {
                draw_textured_world_triangle(
                    left,
                    top,
                    right,
                    top,
                    right,
                    bottom,
                    texture_width,
                    texture_height);
            } else if (tile == level::TileType::SolidSlopeDownRight) {
                draw_textured_world_triangle(
                    left,
                    top,
                    right,
                    top,
                    left,
                    bottom,
                    texture_width,
                    texture_height);
            }
        }
    }
    unbind_texture();
#ifdef FFI_FOREST_TEMPLE
    }
#endif

    bind_texture(
        world_textures_.atlas_data(),
        world_textures_.texture_width(),
        world_textures_.texture_height(),
        false,
        TextureFilter::Nearest);
    for (std::size_t row = 0; row < definition.height; ++row) {
        for (std::size_t column = 0; column < definition.width; ++column) {
            if (!world.tile_visible(column, row)) {
                continue;
            }
            const level::TileType tile = world.tile_at(column, row);
            if (tile == level::TileType::Empty ||
                tile == level::TileType::Solid ||
                tile == level::TileType::SolidSlopeUpRight ||
                tile == level::TileType::SolidSlopeUpLeft ||
                tile == level::TileType::SolidSlopeDownLeft ||
                tile == level::TileType::SolidSlopeDownRight) {
                continue;
            }
            float center_x = 0.0F;
            float center_y = 0.0F;
            float left = 0.0F;
            float top = 0.0F;
            float right = 0.0F;
            float bottom = 0.0F;
            tile_geometry(
                column,
                row,
                center_x,
                center_y,
                left,
                top,
                right,
                bottom);
            static_cast<void>(left);
            static_cast<void>(right);
            static_cast<void>(bottom);

            if (world.tile_frozen(column, row) ||
                tile == level::TileType::Ice) {
                static_cast<void>(draw_world_sprite_bound(
                    WorldSprite::Ice,
                    center_x,
                    center_y,
                    game::GameWorld::kTileSize,
                    game::GameWorld::kTileSize));
            } else if (
                tile == level::TileType::IceSlopeUpRight ||
                tile == level::TileType::IceSlopeUpLeft ||
                tile == level::TileType::IceSlopeDownLeft ||
                tile == level::TileType::IceSlopeDownRight) {
                const bool down =
                    tile == level::TileType::IceSlopeDownLeft ||
                    tile == level::TileType::IceSlopeDownRight;
                const bool flip =
                    tile == level::TileType::IceSlopeUpLeft ||
                    tile == level::TileType::IceSlopeDownLeft;
                static_cast<void>(draw_world_sprite_bound(
                    WorldSprite::IceSlope,
                    center_x,
                    center_y,
                    game::GameWorld::kTileSize,
                    game::GameWorld::kTileSize,
                    down ? kPi : 0.0F,
                    flip));
            } else if (
                tile == level::TileType::Fire ||
                tile == level::TileType::FireSlopeLeft ||
                tile == level::TileType::FireSlopeRight ||
                tile == level::TileType::WaterMiddle ||
                tile == level::TileType::WaterStart ||
                tile == level::TileType::WaterEnd ||
                tile == level::TileType::FrozenStart ||
                tile == level::TileType::Acid ||
                tile == level::TileType::AcidSlopeLeft ||
                tile == level::TileType::AcidSlopeRight) {
                const bool slope =
                    tile == level::TileType::FireSlopeLeft ||
                    tile == level::TileType::FireSlopeRight ||
                    tile == level::TileType::WaterStart ||
                    tile == level::TileType::WaterEnd ||
                    tile == level::TileType::FrozenStart ||
                    tile == level::TileType::AcidSlopeLeft ||
                    tile == level::TileType::AcidSlopeRight;
                WorldSprite sprite = WorldSprite::Water;
                if (tile == level::TileType::Fire) {
                    sprite = WorldSprite::Fire;
                } else if (
                    tile == level::TileType::FireSlopeLeft ||
                    tile == level::TileType::FireSlopeRight) {
                    sprite = WorldSprite::FireSlope;
                } else if (
                    tile == level::TileType::WaterStart ||
                    tile == level::TileType::WaterEnd ||
                    tile == level::TileType::FrozenStart) {
                    sprite = WorldSprite::WaterSlope;
                } else if (tile == level::TileType::Acid) {
                    sprite = WorldSprite::Acid;
                } else if (
                    tile == level::TileType::AcidSlopeLeft ||
                    tile == level::TileType::AcidSlopeRight) {
                    sprite = WorldSprite::AcidSlope;
                }
                const bool flip =
                    tile == level::TileType::FireSlopeRight ||
                    tile == level::TileType::WaterEnd ||
                    tile == level::TileType::AcidSlopeRight;
                static_cast<void>(draw_world_sprite_bound(
                    sprite,
                    center_x,
                    top + half_tile * 0.5F,
                    game::GameWorld::kTileSize,
                    slope ? half_tile + 2.0F : half_tile + 3.0F,
                    0.0F,
                    flip));
            } else if (
                tile == level::TileType::FireboyGem ||
                tile == level::TileType::WatergirlGem ||
                tile == level::TileType::SharedGem) {
                WorldSprite sprite = WorldSprite::SharedGem;
                if (tile == level::TileType::FireboyGem) {
                    sprite = WorldSprite::FireGem;
                } else if (tile == level::TileType::WatergirlGem) {
                    sprite = WorldSprite::WaterGem;
                }
                static_cast<void>(draw_world_sprite_bound(
                    sprite,
                    center_x,
                    tile == level::TileType::SharedGem
                        ? center_y
                        : center_y + half_tile));
            }
        }
    }

    const auto draw_door = [this](
                               const level::Vector2 position,
                               const FinishTimeline timeline,
                               const std::uint8_t source_frame) noexcept {
        const float origin_x =
            game::GameWorld::kLevelOffset +
            position.x * game::GameWorld::kTileSize;
        const float origin_y =
            game::GameWorld::kLevelOffset +
            (position.y + 0.66F) * game::GameWorld::kTileSize;
        draw_finish_frame(timeline, source_frame, origin_x, origin_y);
    };
    draw_door(
        definition.fireboy_finish,
        FinishTimeline::FireDoor,
        world.players()[0].finish_frame);
    draw_door(
        definition.watergirl_finish,
        FinishTimeline::WaterDoor,
        world.players()[1].finish_frame);
    unbind_texture();
}

#ifdef FFI_FOREST_TEMPLE
void PspRenderer::draw_forest_pulley_chains(const game::GameWorld& world) noexcept {
    // Match RopePulley's negative scale and the horizontal Connector's
    // moving mask. A segment can straddle the two atlas strips.
    const auto chain = [](float x, float y, float length, float angle,
                          float source_start, bool reverse) noexcept {
        float strip_start = 0.0F;
        const float sine = std::sin(angle);
        const float cosine = std::cos(angle);
        for (const auto& strip : forest_effects::kPulleyChain) {
            const float strip_end = strip_start + strip.height;
            const float first = std::max(source_start, strip_start);
            const float last = std::min(source_start + length, strip_end);
            if (last > first) {
                const float span = last - first;
                const float midpoint = (reverse ? source_start + length - last
                                                : first - source_start) + span * 0.5F;
                draw_world_frame_bound(strip, x - sine * midpoint, y + cosine * midpoint,
                                       static_cast<float>(strip.width), span, angle,
                                       reverse, reverse, span, first - strip_start);
            }
            strip_start = strip_end;
        }
    };
    bool bound = false;
    const auto& platforms = world.runtime_platforms();
    const std::size_t count = world.runtime_platform_count();
    for (std::size_t index = 0; index < count; ++index) {
        const auto& platform = platforms[index];
        if (!platform.pulley_primary && !platform.pulley_secondary) {
            continue;
        }
        if (!bound) {
            bind_texture(world_textures_.pulley_chain_data(),
                         forest_effects::kPulleyAtlasWidth, forest_effects::kPulleyAtlasHeight,
                         false, TextureFilter::Nearest);
            bound = true;
        }
        const auto cable = pulley_cable(platform);
        const float length = std::hypot(cable.x, cable.y);
        const float angle = std::atan2(cable.y, cable.x) - kPi * 0.5F;
        chain(platform.anchor_x, platform.anchor_y, length, angle, 0.0F, true);
        if (platform.pulley_primary && platform.linked_index < count) {
            const auto& right = platforms[platform.linked_index];
            const float connector_y = platform.anchor_y - 10.1F * kFlashToPspScale;
            chain(platform.anchor_x, connector_y, right.anchor_x - platform.anchor_x,
                  -kPi * 0.5F, length, false);
        }
    }
    if (bound) {
        unbind_texture();
    }
}

void PspRenderer::draw_forest_pulley_hardware(
    const game::RuntimePlatform& platform, const game::RuntimePlatform& left) noexcept {
    const float x = platform.x + platform.width * 0.5F;
    const float y = platform.y + platform.height * 0.5F;
    static_cast<void>(draw_world_sprite_bound(
        WorldSprite::PulleyPlatform, x, y, 0.0F, 0.0F, 0.0F, false, false, 1U));
    const auto* deck = world_textures_.frame(WorldSprite::PulleyPlatform, render_frame_, 2U);
    // PlatformPulleyBox scales its board child, keeping its SWF registration.
    const float deck_width = platform.width * deck->width / (111.0F * kFlashToPspScale);
    const float deck_height = platform.height * deck->height / (26.85F * kFlashToPspScale);
    draw_world_frame_bound(*deck, x + 1.65F * kFlashToPspScale, y - 0.2F * kFlashToPspScale,
                           deck_width, deck_height, 0.0F);
    const auto cable = pulley_cable(left);
    const float angle = -std::hypot(cable.x, cable.y) *
        (200.0F * kPi / (180.0F * game::GameWorld::kTileSize));
    const float wheel_x = platform.anchor_x + (platform.pulley_primary ? 4.0F : -4.0F);
    static_cast<void>(draw_world_sprite_bound(
        WorldSprite::PulleyPlatform, wheel_x, platform.anchor_y - 4.0F,
        0.0F, 0.0F, angle, false, false, platform.pulley_primary ? 3U : 4U));
}

void PspRenderer::reset_forest_effects(
    const game::GameWorld& world, const RenderStatus& status) noexcept {
    auto& timeline = forest_effects_timeline_;
    timeline = {};
    timeline.level = world.level_index();
    timeline.start_ui_tick = status.ui_tick;
    timeline.ui_tick = status.ui_tick;

    const auto& definition = world.level();
    const std::size_t width = definition.width;
    const std::size_t height = definition.height;
    std::array<std::uint16_t, level::kMaximumTileCount> open_cells;
    std::size_t open_count = 0U;
    const auto empty = [&world](std::size_t column, std::size_t row) noexcept {
        return world.tile_at(column, row) == level::TileType::Empty;
    };
    // level.as only spawns bugs on a zero tile with four zero neighbors.
    for (std::size_t row = 1; row + 1 < height; ++row) {
        for (std::size_t column = 1; column + 1 < width; ++column) {
            if (empty(column, row) && empty(column - 1, row) && empty(column + 1, row) &&
                empty(column, row - 1) && empty(column, row + 1)) {
                open_cells[open_count++] = static_cast<std::uint16_t>(row * width + column);
            }
        }
    }
    if (open_count == 0U) {
        return;
    }

    const std::uint32_t seed = status.ui_tick * 0x9E3779B9U +
        static_cast<std::uint32_t>(world.level_index()) + 1U;
    std::minstd_rand random(seed);
    std::uniform_real_distribution<float> unit(0.0F, 1.0F);
    std::uniform_int_distribution<std::size_t> pick(0U, open_count - 1U);
    timeline.firefly_count = 3U + static_cast<std::size_t>(std::lround(unit(random) * 2.0F));
    for (std::size_t index = 0; index < timeline.firefly_count; ++index) {
        const auto cell = open_cells[pick(random)];
        auto& firefly = timeline.fireflies[index];
        firefly.x = game::GameWorld::kLevelOffset +
            static_cast<float>(cell % width) * game::GameWorld::kTileSize;
        firefly.y = game::GameWorld::kLevelOffset +
            static_cast<float>(cell / width) * game::GameWorld::kTileSize;
        firefly.angle = unit(random) * 2.0F * kPi;
        firefly.cosine = std::cos(firefly.angle);
        firefly.sine = std::sin(firefly.angle);
    }
}

void PspRenderer::draw_forest_effects(
    const game::GameWorld& world, const RenderStatus& status) noexcept {
    auto& timeline = forest_effects_timeline_;
    if (timeline.level != world.level_index() || status.logic_tick < timeline.logic_tick) {
        reset_forest_effects(world, status);
    }
    const bool advance_blades = (status.ui_tick - timeline.ui_tick) % 2U != 0U;
    timeline.ui_tick = status.ui_tick;
    timeline.logic_tick = status.logic_tick;

    bind_texture(world_textures_.forest_effects_data(),
                 forest_effects::kAtlasSize, forest_effects::kAtlasSize, false);
    for (std::size_t index = 0; index < world.wind_zone_count(); ++index) {
        const auto& wind = world.wind_zones()[index];
        float x = wind.x + wind.width * 0.5F;
        float y = wind.y + wind.height * 0.5F;
        const float angle = static_cast<float>(wind.direction - 1U) * kPi * 0.5F;
        switch (wind.direction) {
            case 1: y = wind.y + wind.height; break;
            case 2: x = wind.x; break;
            case 3: y = wind.y; break;
            case 4: x = wind.x + wind.width; break;
        }
        if (wind.active && advance_blades) {
            timeline.blades[index] = !timeline.blades[index];
        }
        const auto& blades = forest_effects::kBlades[timeline.blades[index]];
        draw_world_frame_bound(blades.texture, x, y, blades.width, blades.height, angle);
        const std::size_t color = std::clamp<unsigned>(wind.light_index, 1U, 6U) - 1U;
        if (wind.controlled || wind.active) {
            const auto& off = forest_effects::kOffLights[color];
            draw_world_frame_bound(off.texture, x, y, off.width, off.height, angle);
        }
        if (wind.controlled && wind.active) {
            const auto& on = forest_effects::kOnLights[color];
            draw_world_frame_bound(on.texture, x, y, on.width, on.height, angle);
        }
    }

    const auto elapsed = status.ui_tick - timeline.start_ui_tick;
    const auto& flow = forest_effects::kFlow[elapsed % forest_effects::kFlow.size()];
    // Wind places insideWind at (0, 9). Its shapes are 394.1 by 400 with
    // center y=-28 before rotation. CreateWind scales the parent, rotates
    // the child, then widens the cross section by 30 Flash pixels.
    constexpr float source_width = 394.1F;
    constexpr float source_height = 400.0F;
    constexpr float spread = 30.0F * kFlashToPspScale;
    for (std::size_t index = 0; index < world.wind_zone_count(); ++index) {
        const auto& wind = world.wind_zones()[index];
        if (!wind.active) {
            continue;
        }
        float x = wind.x + wind.width * 0.5F;
        float y = wind.y + wind.height * 0.5F;
        const float angle = static_cast<float>(wind.direction - 1U) * kPi * 0.5F;
        float width = wind.width + spread;
        float height = wind.height;
        if (wind.direction == 1U || wind.direction == 3U) {
            y += height * (wind.direction == 1U ? -19.0F : 37.0F) / source_height;
        } else {
            width = wind.height * source_width / source_height + spread;
            height = wind.width * source_height / source_width;
            x += height * (wind.direction == 2U ? 28.0F : -28.0F) / source_height;
            y += width * 9.0F / source_width;
        }
        draw_world_frame_bound(flow.texture, x, y, width, height, angle);
    }

    const auto& wings = forest_effects::kFireflies[elapsed % forest_effects::kFireflies.size()];
    const auto& offset = forest_effects::kFlight[elapsed % forest_effects::kFlight.size()];
    const float dx = static_cast<float>(offset.x) * kFlashToPspScale / 20.0F;
    const float dy = static_cast<float>(offset.y) * kFlashToPspScale / 20.0F;
    for (std::size_t index = 0; index < timeline.firefly_count; ++index) {
        const auto& firefly = timeline.fireflies[index];
        const float x = firefly.x + dx * firefly.cosine - dy * firefly.sine;
        const float y = firefly.y + dx * firefly.sine + dy * firefly.cosine;
        draw_world_frame_bound(wings.texture, x, y, wings.width, wings.height, firefly.angle);
    }
    unbind_texture();
}
#endif

void PspRenderer::draw_objects(const game::GameWorld& world) noexcept {
    if (world_textures_.loaded()) {
#ifdef FFI_FOREST_TEMPLE
        const bool legacy_wind = world_textures_.forest_effects_data() == nullptr;
        const bool pulley_art = world_textures_.pulley_chain_data() != nullptr &&
            world_textures_.frame(WorldSprite::PulleyPlatform, render_frame_, 4U) != nullptr;
#else
        constexpr bool legacy_wind = true;
        constexpr bool pulley_art = false;
#endif
        const WorldFrame* const rope =
            world_textures_.frame(WorldSprite::HangingPlatform, render_frame_, 2U);
        for (std::size_t index = 0;
             index < world.light_beam_count();
             ++index) {
            const game::LightBeamSegment& beam =
                world.light_beams()[index];
            draw_world_gradient_beam(beam);
        }
        for (std::size_t index = 0;
             index < world.runtime_platform_count();
             ++index) {
            const game::RuntimePlatform& platform =
                world.runtime_platforms()[index];
            if ((platform.hanging && rope == nullptr) ||
                (!pulley_art && (platform.pulley_primary || platform.pulley_secondary))) {
                draw_world_line(
                    platform.anchor_x,
                    platform.anchor_y,
                    platform.x + platform.width * 0.5F,
                    platform.y + platform.height * 0.5F,
                    2.0F,
                    kColorDoor);
            }
        }
        for (std::size_t index = 0;
             legacy_wind && index < world.wind_zone_count();
             ++index) {
            const game::WindZone& wind = world.wind_zones()[index];
            if (wind.active) {
                draw_world_rect(
                    wind.x,
                    wind.y,
                    wind.width,
                    wind.height,
                    kColorWind);
            }
        }

#ifdef FFI_FOREST_TEMPLE
        if (pulley_art) {
            draw_forest_pulley_chains(world);
        }
#endif
        bind_texture(
            world_textures_.atlas_data(),
            world_textures_.texture_width(),
            world_textures_.texture_height(),
            false,
            TextureFilter::Nearest);

        if (rope != nullptr) {
            constexpr float cable_offset_y = 6.0F;
            for (std::size_t index = 0; index < world.runtime_platform_count(); ++index) {
                const auto& platform = world.runtime_platforms()[index];
                if (!platform.hanging) {
                    continue;
                }
                const float dx = platform.x + platform.width * 0.5F - platform.anchor_x;
                const float dy = platform.y + platform.height * 0.5F - platform.anchor_y;
                const float angle = std::atan2(dy, dx) - kPi * 0.5F;
                const float cable_height = std::clamp(
                    platform.rope_length - cable_offset_y, 0.0F, static_cast<float>(rope->height));
                if (cable_height > 0.0F) {
                    const float midpoint = cable_offset_y + cable_height * 0.5F;
                    static_cast<void>(draw_world_sprite_bound(
                        WorldSprite::HangingPlatform,
                        platform.anchor_x - std::sin(angle) * midpoint,
                        platform.anchor_y + std::cos(angle) * midpoint,
                        0.0F, cable_height, angle, false, false, 2U, cable_height));
                }
                static_cast<void>(draw_world_sprite_bound(
                    WorldSprite::HangingPlatform, platform.anchor_x, platform.anchor_y,
                    0.0F, 0.0F, angle, false, false, 1U));
            }
        }

        constexpr float kSliderEndpointOffsetX = 108.15F * 0.8F;
        constexpr float kSliderRightEndpointOffsetY = 1.6F * 0.8F;
        constexpr float kSliderLeftEndpointOffsetY = -1.4F * 0.8F;
        constexpr float kSliderLeverLightOffsetY = 11.15F * 0.8F;
        for (std::size_t index = 0;
             index < world.runtime_mirror_count();
             ++index) {
            const game::RuntimeMirror& mirror =
                world.runtime_mirrors()[index];
            if (!mirror.slider_controlled) {
                continue;
            }
            static_cast<void>(draw_world_sprite_bound(
                WorldSprite::SliderHole,
                mirror.slider_origin_x,
                mirror.slider_y));
            const WorldSprite endpoint_light =
                slider_endpoint_light_sprite(
                    mirror.slider_light_index);
            static_cast<void>(draw_world_sprite_bound(
                endpoint_light,
                mirror.slider_origin_x + kSliderEndpointOffsetX,
                mirror.slider_y + kSliderRightEndpointOffsetY,
                0.0F,
                0.0F,
                kPi * 0.5F));
            static_cast<void>(draw_world_sprite_bound(
                endpoint_light,
                mirror.slider_origin_x - kSliderEndpointOffsetX,
                mirror.slider_y + kSliderLeftEndpointOffsetY,
                0.0F,
                0.0F,
                -kPi * 0.5F));
            const float handle_x =
                mirror.slider_origin_x + mirror.slider_offset;
            static_cast<void>(draw_world_sprite_bound(
                WorldSprite::SliderLever,
                handle_x,
                mirror.slider_y));
            static_cast<void>(draw_world_sprite_bound(
                slider_lever_light_sprite(
                    mirror.slider_light_index),
                handle_x,
                mirror.slider_y + kSliderLeverLightOffsetY));
        }

        std::size_t mirror_object_cursor = 0;
        const level::LevelDefinition& definition = world.level();
        for (std::size_t index = 0;
             index < world.runtime_mirror_count();
             ++index) {
            const game::RuntimeMirror& mirror =
                world.runtime_mirrors()[index];
            WorldSprite sprite =
                mirror.slider_controlled
                    ? WorldSprite::InfiniteMirror
                    : WorldSprite::RotMirror;
            while (mirror_object_cursor < definition.object_count) {
                const level::ObjectType type =
                    definition.objects[mirror_object_cursor++].type;
                if (type == level::ObjectType::InfiniteMirror) {
                    sprite = WorldSprite::InfiniteMirror;
                    break;
                }
                if (type == level::ObjectType::RotMirror) {
                    sprite = WorldSprite::RotMirror;
                    break;
                }
                if (type == level::ObjectType::MovingMirror) {
                    sprite = WorldSprite::MovingMirror;
                    break;
                }
            }
            if (mirror.linked_to_body) {
                continue;
            }
            const float diameter =
                std::max(28.0F, mirror.half_length * 2.35F);
            static_cast<void>(draw_world_sprite_bound(
                sprite,
                mirror.x,
                mirror.y,
                diameter,
                diameter,
                mirror.angle - kPi * 0.25F));
        }

        for (std::size_t index = 0;
             index < world.light_emitter_count();
             ++index) {
            const game::LightEmitter& emitter =
                world.light_emitters()[index];
            static_cast<void>(draw_world_sprite_bound(
                WorldSprite::LightEmitter,
                emitter.x,
                emitter.y,
                25.0F,
                36.0F,
                emitter.angle));
        }
        for (std::size_t index = 0;
             index < world.light_receiver_count();
             ++index) {
            const game::LightReceiver& receiver =
                world.light_receivers()[index];
            static_cast<void>(draw_world_sprite_bound(
                WorldSprite::LightReceiver,
                receiver.x,
                receiver.y,
                34.0F,
                17.0F,
                receiver.angle));
        }

        for (std::size_t index = 0;
             index < world.runtime_platform_count();
             ++index) {
            const game::RuntimePlatform& platform =
                world.runtime_platforms()[index];
            const float center_x =
                platform.x + platform.width * 0.5F;
            const float center_y =
                platform.y + platform.height * 0.5F;
#ifdef FFI_FOREST_TEMPLE
            if ((platform.movable || platform.motorized_hinge) &&
                world_textures_.frame(WorldSprite::SlidePlatform, render_frame_,
                    mechanism_variant(platform.light_index, platform.active))) {
                continue;
            }
#endif
            if (platform.seesaw) {
                const float base_center_y =
                    (center_y + platform.lower_translation) * 0.5F;
#ifdef FFI_FOREST_TEMPLE
                static_cast<void>(draw_world_sprite_bound(
                    WorldSprite::RomanBase, center_x, base_center_y,
                    0.0F, 0.0F));
                static_cast<void>(draw_world_sprite_bound(
                    WorldSprite::RomanBeam, center_x, center_y,
                    0.0F, 0.0F, platform.translation));
#else
                static_cast<void>(draw_world_sprite_bound(
                    WorldSprite::RomanBeam,
                    center_x,
                    center_y,
                    platform.width,
                    std::max(8.0F, platform.height),
                    platform.translation));
                static_cast<void>(draw_world_sprite_bound(
                    WorldSprite::RomanBase,
                    center_x,
                    base_center_y,
                    game::GameWorld::kTileSize * 2.0F,
                    platform.lower_translation - center_y));
#endif
            } else if (platform.motorized_hinge) {
                static_cast<void>(draw_world_sprite_bound(
                    WorldSprite::SlidePlatform, center_x, center_y,
                    platform.width, platform.height, platform.translation));
            } else if (platform.movable) {
                const bool horizontal =
                    platform.width >= platform.height;
                static_cast<void>(draw_world_sprite_bound(
                    WorldSprite::SlidePlatform,
                    center_x,
                    center_y,
                    horizontal ? platform.height : platform.width,
                    horizontal ? platform.width : platform.height,
                    horizontal ? kPi * 0.5F : 0.0F));
            } else if (platform.hanging) {
                static_cast<void>(draw_world_sprite_bound(
                    WorldSprite::HangingPlatform,
                    center_x,
                    center_y,
                    platform.width,
                    rope != nullptr ? platform.height : std::max(12.0F, platform.height + 6.0F),
                    platform.translation));
            } else if (
                platform.pulley_primary ||
                platform.pulley_secondary) {
#ifdef FFI_FOREST_TEMPLE
                if (pulley_art && platform.linked_index < world.runtime_platform_count()) {
                    const auto& left = platform.pulley_primary
                        ? platform : world.runtime_platforms()[platform.linked_index];
                    draw_forest_pulley_hardware(platform, left);
                    continue;
                }
#endif
                static_cast<void>(draw_world_sprite_bound(
                    WorldSprite::PulleyPlatform,
                    center_x,
                    center_y,
                    platform.width,
                    std::max(15.0F, platform.height + 8.0F)));
            }
        }

        for (std::size_t index = 0;
             index < world.runtime_trigger_count();
             ++index) {
            const game::RuntimeTrigger& trigger =
                world.runtime_triggers()[index];
            const float center_x = trigger.x + trigger.width * 0.5F;
            const float center_y = trigger.y + trigger.height * 0.5F;
            if (trigger.kind == game::TriggerKind::Lever) {
                if (trigger.lever_on_side == 0 ||
                    !draw_world_sprite_bound(
                        WorldSprite::LeverBase, center_x, center_y,
                        0.0F, 0.0F, 0.0F, false, false, trigger.light_index)) {
                    static_cast<void>(draw_world_sprite_bound(
                        WorldSprite::LeverBase, center_x, center_y + 10.0F));
                }
                if (trigger.lever_on_side != 0) {
                    const float pivot = game::flash_physics::kLeverPivotUnits *
                        game::GameWorld::kTileSize;
                    const float handle_x = center_x + std::sin(trigger.lever_angle) * pivot;
                    const float handle_y = center_y + (1.0F - std::cos(trigger.lever_angle)) * pivot;
                    if (!draw_world_sprite_bound(
                        WorldSprite::LeverHandle,
                        handle_x, handle_y, 0.0F, 0.0F, trigger.lever_angle,
                        false, false, mechanism_variant(trigger.light_index, trigger.active))) {
                        static_cast<void>(draw_world_sprite_bound(
                            WorldSprite::LeverHandle, handle_x, handle_y,
                            0.0F, 0.0F, trigger.lever_angle));
                    }
                    continue;
                }
                static_cast<void>(draw_world_sprite_bound(
                    WorldSprite::LeverHandle,
                    center_x +
                        (trigger.active ? 5.0F : -5.0F),
                    center_y - 4.0F,
                    10.0F,
                    27.0F,
                    trigger.active ? 0.42F : -0.42F));
            } else if (trigger.kind != game::TriggerKind::LightPusher) {
                // ButtonBox is a moving child at the source body origin;
                // ButtonMask and ButtonPlants remain at the creation origin.
                // The mask is not visible in Flash: it clips the button and
                // its colored light to x[-17.6,18.7], y[-10.95,6.85].
                constexpr float kButtonOriginOffsetUnits = 0.2F;
                constexpr float kButtonBodyCenterX = 0.4F;
                constexpr float kButtonBodyCenterY = 7.55F;
                constexpr float kButtonMaskLeft = -17.6F;
                constexpr float kButtonMaskTop = -10.95F;
                constexpr float kButtonMaskRight = 18.7F;
                constexpr float kButtonMaskBottom = 6.85F;
                constexpr float kButtonPlantsCenterX = 1.45F;
                constexpr float kButtonPlantsCenterY = 7.825F;
                constexpr std::array<float, 6> kButtonLightCenterX = {
                    -0.925F,
                    -1.2F,
                    -1.3F,
                    -1.2F,
                    -1.3F,
                    -1.5F,
                };
                constexpr std::array<float, 6> kButtonLightCenterY = {
                    1.95F,
                    1.75F,
                    1.8F,
                    1.4F,
                    1.4F,
                    1.4F,
                };
                const float source_origin_x = center_x;
                const float source_origin_y =
                    trigger.origin_y -
                    kButtonOriginOffsetUnits * game::GameWorld::kTileSize;
                const float mask_left =
                    source_origin_x +
                    kButtonMaskLeft * kFlashToPspScale;
                const float mask_top =
                    source_origin_y +
                    kButtonMaskTop * kFlashToPspScale;
                const float mask_right =
                    source_origin_x +
                    kButtonMaskRight * kFlashToPspScale;
                const float mask_bottom =
                    source_origin_y +
                    kButtonMaskBottom * kFlashToPspScale;

                if (trigger.kind == game::TriggerKind::TimedPusher) {
                    constexpr float kTimedBaseCenterX = 0.6F;
                    constexpr float kTimedBaseCenterY = 13.725F;
                    constexpr float kTimedBarCenterY = 13.5F;
                    constexpr float kTimedBarWidth = 35.0F;
                    constexpr float kTimedBarHeight = 4.2F;
                    constexpr float kTimedMaskLeft = -18.4F;
                    constexpr float kTimedMaskTop = 10.55F;
                    constexpr float kTimedMaskWidth = 36.1F;
                    constexpr float kTimedMaskBottom = 16.85F;
                    static_cast<void>(draw_world_sprite_bound(
                        WorldSprite::TimedBase,
                        source_origin_x +
                            kTimedBaseCenterX * kFlashToPspScale,
                        source_origin_y +
                            kTimedBaseCenterY * kFlashToPspScale));
                    static_cast<void>(draw_world_sprite_bound(
                        timed_bar_sprite(trigger.light_index),
                        source_origin_x,
                        source_origin_y +
                            kTimedBarCenterY * kFlashToPspScale,
                        kTimedBarWidth * kFlashToPspScale,
                        kTimedBarHeight * kFlashToPspScale,
                        0.0F,
                        true,
                        true));
                    const float timer_fraction =
                        trigger.delay_seconds > 0.0F
                            ? std::clamp(
                                  trigger.timer_seconds /
                                      trigger.delay_seconds,
                                  0.0F,
                                  1.0F)
                            : 0.0F;
                    const float timed_mask_left =
                        source_origin_x +
                        kTimedMaskLeft * kFlashToPspScale;
                    static_cast<void>(draw_world_sprite_clipped(
                        timed_bar_light_sprite(trigger.light_index),
                        source_origin_x,
                        source_origin_y +
                            kTimedBarCenterY * kFlashToPspScale,
                        timed_mask_left,
                        source_origin_y +
                            kTimedMaskTop * kFlashToPspScale,
                        timed_mask_left +
                            kTimedMaskWidth * kFlashToPspScale *
                                timer_fraction,
                        source_origin_y +
                            kTimedMaskBottom * kFlashToPspScale,
                        kTimedBarWidth * kFlashToPspScale,
                        kTimedBarHeight * kFlashToPspScale,
                        true,
                        true));
                }

                const bool button_visible =
                    trigger.kind == game::TriggerKind::TimedPusher ||
                    !trigger.active;
                if (button_visible) {
                    const float moving_origin_y =
                        source_origin_y + trigger.press_offset;
                    const bool colored = trigger.kind == game::TriggerKind::Pusher &&
                        draw_world_sprite_clipped(
                            WorldSprite::NormalButton, source_origin_x, moving_origin_y,
                            mask_left, mask_top, mask_right, mask_bottom,
                            0.0F, 0.0F, false, false, trigger.light_index);
                    if (!colored) {
                        static_cast<void>(draw_world_sprite_clipped(
                            trigger.kind == game::TriggerKind::TimedPusher
                                ? WorldSprite::TimedButton
                                : WorldSprite::NormalButton,
                            source_origin_x +
                                kButtonBodyCenterX * kFlashToPspScale,
                            moving_origin_y +
                                kButtonBodyCenterY * kFlashToPspScale,
                            mask_left,
                            mask_top,
                            mask_right,
                            mask_bottom));
                        const std::size_t light_index =
                            static_cast<std::size_t>(
                                std::clamp<std::uint8_t>(trigger.light_index, 1U, 6U) - 1U);
                        static_cast<void>(draw_world_sprite_clipped(
                            slider_endpoint_light_sprite(trigger.light_index),
                            source_origin_x +
                                kButtonLightCenterX[light_index] * kFlashToPspScale,
                            moving_origin_y +
                                kButtonLightCenterY[light_index] * kFlashToPspScale,
                            mask_left,
                            mask_top,
                            mask_right,
                            mask_bottom));
                    }
                }
                static_cast<void>(draw_world_sprite_bound(
                    WorldSprite::ButtonPlants,
                    source_origin_x +
                        kButtonPlantsCenterX * kFlashToPspScale,
                    source_origin_y +
                        kButtonPlantsCenterY * kFlashToPspScale));
            }
        }

        for (std::size_t index = 0;
             index < world.movable_body_count();
             ++index) {
            const game::MovableBody& body =
                world.movable_bodies()[index];
            WorldSprite sprite = WorldSprite::MovingBox;
            if (body.mirror) {
                sprite = WorldSprite::MovingMirror;
            } else if (body.round) {
                sprite = WorldSprite::Ball;
            } else if (body.heavy) {
                sprite = WorldSprite::HeavyBox;
            }
            static_cast<void>(draw_world_sprite_bound(
                sprite,
                body.x + body.width * 0.5F,
                body.y + body.height * 0.5F,
                body.width,
                body.height,
                body.angle));
        }

        for (std::size_t index = 0;
             legacy_wind && index < world.wind_zone_count();
             ++index) {
            const game::WindZone& wind = world.wind_zones()[index];
            float center_x = wind.x;
            float center_y = wind.y + wind.height * 0.5F;
            float angle = 0.0F;
            if (wind.direction == 2U) {
                center_x = wind.x + wind.width * 0.5F;
                center_y = wind.y;
                angle = kPi * 0.5F;
            } else if (wind.direction == 3U) {
                center_x = wind.x + wind.width;
                angle = kPi;
            } else if (wind.direction == 4U) {
                center_x = wind.x + wind.width * 0.5F;
                center_y = wind.y + wind.height;
                angle = -kPi * 0.5F;
            }
            static_cast<void>(draw_world_sprite_bound(
                WorldSprite::WindMaker,
                center_x,
                center_y,
                54.0F,
                21.0F,
                angle));
        }
        unbind_texture();

#ifndef FFI_FOREST_TEMPLE
        for (std::size_t index = 0;
             index < world.runtime_trigger_count();
             ++index) {
            const game::RuntimeTrigger& trigger =
                world.runtime_triggers()[index];
            if (trigger.active) {
                draw_world_rect(
                    trigger.x + trigger.width - 4.0F,
                    trigger.y,
                    4.0F,
                    4.0F,
                    kColorConnected);
            }
        }
#endif
        return;
    }

    for (std::size_t index = 0;
         index < world.light_beam_count();
         ++index) {
        const game::LightBeamSegment& beam =
            world.light_beams()[index];
        draw_world_gradient_beam(beam);
    }
    for (std::size_t index = 0;
         index < world.runtime_mirror_count();
         ++index) {
        const game::RuntimeMirror& mirror =
            world.runtime_mirrors()[index];
        const float tangent_x = std::cos(mirror.angle);
        const float tangent_y = std::sin(mirror.angle);
        draw_world_line(
            mirror.x - tangent_x * mirror.half_length,
            mirror.y - tangent_y * mirror.half_length,
            mirror.x + tangent_x * mirror.half_length,
            mirror.y + tangent_y * mirror.half_length,
            4.0F,
            kColorDoor);
        if (mirror.slider_controlled) {
            draw_world_line(
                mirror.slider_origin_x -
                    mirror.slider_length * 0.5F,
                mirror.slider_y,
                mirror.slider_origin_x +
                    mirror.slider_length * 0.5F,
                mirror.slider_y,
                3.0F,
                kColorMechanism);
            draw_world_rect(
                mirror.slider_origin_x +
                    mirror.slider_offset - 5.0F,
                mirror.slider_y - 7.0F,
                10.0F,
                14.0F,
                kColorDoor);
        }
    }
    for (std::size_t index = 0;
         index < world.light_emitter_count();
         ++index) {
        const game::LightEmitter& emitter =
            world.light_emitters()[index];
        draw_world_rect(
            emitter.x - 7.0F,
            emitter.y - 7.0F,
            14.0F,
            14.0F,
            source_rgb_to_abgr(emitter.source_rgb, 0xFFU));
    }
    for (std::size_t index = 0;
         index < world.runtime_platform_count();
         ++index) {
        const game::RuntimePlatform& platform =
            world.runtime_platforms()[index];
        const float center_x =
            platform.x + platform.width * 0.5F;
        const float center_y =
            platform.y + platform.height * 0.5F;
        if (platform.roman_base) {
            continue;
        }
        if (platform.hanging ||
            platform.pulley_primary ||
            platform.pulley_secondary) {
            draw_world_line(
                platform.anchor_x,
                platform.anchor_y,
                center_x,
                center_y,
                2.0F,
                kColorDoor);
        }
        if (platform.seesaw) {
            const float tangent_x =
                std::cos(platform.translation);
            const float tangent_y =
                std::sin(platform.translation);
            draw_world_line(
                center_x -
                    tangent_x * platform.width * 0.5F,
                center_y -
                    tangent_y * platform.width * 0.5F,
                center_x +
                    tangent_x * platform.width * 0.5F,
                center_y +
                    tangent_y * platform.width * 0.5F,
                platform.height,
                kColorMechanism);
            draw_world_triangle(
                center_x,
                center_y,
                center_x - game::GameWorld::kTileSize,
                platform.lower_translation,
                center_x + game::GameWorld::kTileSize,
                platform.lower_translation,
                kColorDoor);
            continue;
        }
        if (platform.hanging) {
            const float tangent_x = std::cos(platform.translation);
            const float tangent_y = std::sin(platform.translation);
            draw_world_line(
                center_x - tangent_x * platform.width * 0.5F,
                center_y - tangent_y * platform.width * 0.5F,
                center_x + tangent_x * platform.width * 0.5F,
                center_y + tangent_y * platform.width * 0.5F,
                platform.height,
                kColorMechanism);
            continue;
        }
        draw_world_rect(
            platform.x,
            platform.y,
            platform.width,
            platform.height,
            platform.active ? kColorConnected : kColorMechanism);
    }
    for (std::size_t index = 0;
         index < world.runtime_trigger_count();
         ++index) {
        const game::RuntimeTrigger& trigger =
            world.runtime_triggers()[index];
        const std::uint32_t color =
            trigger.active ? kColorConnected : kColorMechanism;
        if (trigger.kind == game::TriggerKind::Lever) {
            if (trigger.lever_on_side != 0) {
                const float pivot_x = trigger.x + trigger.width * 0.5F;
                const float pivot_y = trigger.y + trigger.height * 0.5F +
                    game::flash_physics::kLeverPivotUnits * game::GameWorld::kTileSize;
                const float length = (game::flash_physics::kLeverPivotUnits +
                    game::flash_physics::kLeverHalfHeightUnits) * game::GameWorld::kTileSize;
                draw_world_line(
                    pivot_x, pivot_y,
                    pivot_x + std::sin(trigger.lever_angle) * length,
                    pivot_y - std::cos(trigger.lever_angle) * length,
                    game::flash_physics::kLeverHalfWidthUnits * 2.0F * game::GameWorld::kTileSize,
                    color);
                continue;
            }
            draw_world_outline(
                trigger.x,
                trigger.y,
                trigger.width,
                trigger.height,
                2.0F,
                color);
            const float handle_x =
                trigger.active
                    ? trigger.x + trigger.width - 4.0F
                    : trigger.x + 4.0F;
            draw_world_rect(
                handle_x,
                trigger.y + 5.0F,
                4.0F,
                trigger.height - 10.0F,
                color);
        } else {
            draw_world_rect(
                trigger.x,
                trigger.y,
                trigger.width,
                trigger.height,
                color);
        }
    }
    for (std::size_t index = 0; index < world.wind_zone_count(); ++index) {
        const game::WindZone& wind = world.wind_zones()[index];
        if (wind.active) {
            draw_world_rect(
                wind.x,
                wind.y,
                wind.width,
                wind.height,
                kColorWind);
        }
    }
    for (std::size_t index = 0; index < world.movable_body_count(); ++index) {
        const game::MovableBody& body = world.movable_bodies()[index];
        if (body.round) {
            const float center_x = body.x + body.width * 0.5F;
            const float center_y = body.y + body.height * 0.5F;
            draw_world_triangle(
                center_x,
                body.y,
                body.x + body.width,
                center_y,
                center_x,
                body.y + body.height,
                kColorMechanism);
            draw_world_triangle(
                center_x,
                body.y,
                center_x,
                body.y + body.height,
                body.x,
                center_y,
                kColorMechanism);
        } else {
            draw_world_outline(
                body.x,
                body.y,
                body.width,
                body.height,
                2.0F,
                body.heavy ? kColorDoor : kColorMechanism);
        }
    }

    const level::LevelDefinition& definition = world.level();
    for (std::uint16_t index = 0; index < definition.object_count; ++index) {
        const level::LevelObject& object = definition.objects[index];
        if (object.type == level::ObjectType::SlidePlatform ||
            object.type == level::ObjectType::Pusher ||
            object.type == level::ObjectType::TimedPusher ||
            object.type == level::ObjectType::Lever ||
            object.type == level::ObjectType::LightPusher ||
            object.type == level::ObjectType::LightBeamer ||
            object.type == level::ObjectType::Wind ||
            object.type == level::ObjectType::MirrorSlider ||
            object.type == level::ObjectType::InfiniteMirror ||
            object.type == level::ObjectType::RotMirror ||
            object.type == level::ObjectType::MovingBox ||
            object.type == level::ObjectType::MovingBox2 ||
            object.type == level::ObjectType::MovingMirror ||
            object.type == level::ObjectType::Ball ||
            object.type == level::ObjectType::HangingPlatform ||
            object.type == level::ObjectType::Pulley ||
            object.type == level::ObjectType::Roman) {
            continue;
        }
        if (object.argument_count == 0U ||
            object.arguments[0].type != level::ArgumentType::Vector) {
            continue;
        }
        const float center_x =
            game::GameWorld::kLevelOffset +
            object.arguments[0].x * game::GameWorld::kTileSize;
        const float center_y =
            game::GameWorld::kLevelOffset +
            object.arguments[0].y * game::GameWorld::kTileSize;

        if (object.type == level::ObjectType::SlidePlatform &&
            object.argument_count >= 3U) {
            const float width =
                object.arguments[1].x * 2.0F * game::GameWorld::kTileSize;
            const float height =
                object.arguments[2].x * 2.0F * game::GameWorld::kTileSize;
            draw_world_rect(
                center_x - width * 0.5F,
                center_y - height * 0.5F,
                width,
                height,
                kColorMechanism);
        } else if (object.type == level::ObjectType::Wind &&
                   object.argument_count >= 2U &&
                   object.arguments[1].type == level::ArgumentType::Vector) {
            const float other_x =
                game::GameWorld::kLevelOffset +
                object.arguments[1].x * game::GameWorld::kTileSize;
            const float other_y =
                game::GameWorld::kLevelOffset +
                object.arguments[1].y * game::GameWorld::kTileSize;
            draw_world_rect(
                std::min(center_x, other_x),
                std::min(center_y, other_y),
                std::max(2.0F, std::fabs(other_x - center_x)),
                std::max(2.0F, std::fabs(other_y - center_y)),
                kColorWind);
        } else if (object.type == level::ObjectType::MovingBox ||
                   object.type == level::ObjectType::MovingBox2 ||
                   object.type == level::ObjectType::MovingMirror) {
            draw_world_outline(
                center_x - 15.0F,
                center_y - 15.0F,
                30.0F,
                30.0F,
                2.0F,
                kColorMechanism);
        } else {
            draw_world_rect(
                center_x - 5.0F,
                center_y - 5.0F,
                10.0F,
                10.0F,
                object.type == level::ObjectType::LightBeamer
                    ? kColorDoor
                    : kColorMechanism);
        }
    }
}

void PspRenderer::draw_darkness(
    const game::GameWorld& world,
    const std::array<game::PlayerState, game::GameWorld::kPlayerCount>&
        players,
    const std::uint32_t logic_tick) noexcept {
    constexpr std::uint32_t kDarknessSeedA = 1'664'525U;
    constexpr std::uint32_t kDarknessSeedB = 1'013'904'223U;
    constexpr float radius = 120.0F;
    std::array<game::MapPoint, kDarknessMaxSources> sources{};
    std::size_t source_count = 0U;
    for (const game::PlayerState& player : players) {
        // Flash adds pers1 and pers2 unconditionally before its death flow.
        sources[source_count++] = {
            player.x + player.width * 0.5F,
            player.y + player.height * 0.5F,
        };
    }
    for (std::size_t index = 0;
         index < world.runtime_platform_count() &&
         source_count < sources.size();
         ++index) {
        const game::RuntimePlatform& platform =
            world.runtime_platforms()[index];
        // The original mask only visits prismatic/revolute actuators whose
        // named light child is visible. The shipped dark levels use only
        // actuated SlidePlatform instances here.
        if (platform.movable && platform.active) {
            sources[source_count++] = {
                platform.x + platform.width * 0.5F,
                platform.y + platform.height * 0.5F,
            };
        }
    }
    for (std::size_t index = 0;
         index < world.wind_zone_count() && source_count < sources.size();
         ++index) {
        const game::WindZone& wind = world.wind_zones()[index];
        if (wind.active) {
            sources[source_count++] = {
                wind.darkness_x,
                wind.darkness_y,
            };
        }
    }

    if (source_count == 0U) {
        draw_world_rect(
            0.0F,
            0.0F,
            game::GameWorld::kStageWidth,
            game::GameWorld::kStageHeight,
            0xFF000000U);
        darkness_cache_valid_ = false;
        darkness_cached_vertex_count_ = 0U;
        return;
    }

    const std::uint32_t signature =
        darkness_sources_signature(sources, source_count);
    const bool cache_stale =
        !darkness_cache_valid_ ||
        darkness_source_signature_ != signature ||
        darkness_cache_logic_tick_ != logic_tick;

    if (cache_stale) {
        struct GradientStops {
            float first = 70.0F;
            float second = 120.0F;
            float final = 255.0F;
        };
        std::array<GradientStops, kDarknessMaxSources> stops{};
        for (std::size_t source = 0U; source < source_count; ++source) {
            std::uint32_t random_state =
                logic_tick * kDarknessSeedA +
                static_cast<std::uint32_t>(source + 1U) * kDarknessSeedB;
            const auto random_unit = [&random_state]() noexcept {
                random_state =
                    random_state * kDarknessSeedA + kDarknessSeedB;
                return static_cast<float>((random_state >> 8U) & 0x00FFFFFFU) /
                       16777216.0F;
            };
            // Flash performs three independent Math.random() calls for every
            // source, once per 25 FPS level Update (not once per mask cell).
            stops[source].first = 70.0F + random_unit() * 5.0F;
            stops[source].second = 120.0F + random_unit() * 5.0F;
            stops[source].final = 255.0F - random_unit() * 5.0F;
        }

        std::size_t vertex_count = 0U;
        const std::size_t columns = kDarknessCellCountX;
        const std::size_t rows = kDarknessCellCountY;
        auto* const vertices = darkness_vertex_cache_.data();
        if (rows == 0U || columns == 0U) {
            return;
        }
        const std::size_t maximum_vertices = kDarknessCacheMaxVertexCount;
        const auto& lut = darkness_distance_ratio_lut();

        const auto darkness_color_at = [&](const float x, const float y) noexcept {
            // Multiple beginGradientFill/drawCircle calls on Flash's one
            // Graphics object composite source-over. Therefore the mask is a
            // union, not the maximum alpha from the nearest light.
            float remaining_visibility = 1.0F;
            for (std::size_t source = 0U; source < source_count; ++source) {
                const float delta_x = x - sources[source].x;
                const float delta_y = y - sources[source].y;
                const float distance_squared =
                    delta_x * delta_x + delta_y * delta_y;
                if (distance_squared >= kDarknessRadiusSquared) {
                    continue;
                }
                const std::size_t distance_sq_low =
                    static_cast<std::size_t>(distance_squared);
                const float distance_sq_fraction =
                    distance_squared - static_cast<float>(distance_sq_low);
                const float distance =
                    lut[distance_sq_low] +
                    (lut[std::min(distance_sq_low + 1U, lut.size() - 1U)] -
                     lut[distance_sq_low]) *
                        distance_sq_fraction;
                const float ratio = distance / radius * 255.0F;
                const GradientStops& source_stops = stops[source];
                float source_alpha = 0.0F;
                if (ratio <= source_stops.first) {
                    source_alpha = 0.8F;
                } else if (ratio <= source_stops.second) {
                    const float blend =
                        (ratio - source_stops.first) /
                        (source_stops.second - source_stops.first);
                    source_alpha = 0.8F - blend * 0.4F;
                } else if (ratio < source_stops.final) {
                    const float blend =
                        (ratio - source_stops.second) /
                        (source_stops.final - source_stops.second);
                    source_alpha = 0.4F * (1.0F - blend);
                }
                remaining_visibility *= (1.0F - source_alpha);
            }
            const float visible_alpha = 1.0F - remaining_visibility;
            const auto darkness_alpha = static_cast<std::uint8_t>(std::clamp(
                (1.0F - visible_alpha) * 255.0F,
                0.0F,
                255.0F));
            return static_cast<std::uint32_t>(darkness_alpha) << 24U;
        };
        const auto append_vertex = [&, vertices](
                                       const float x,
                                       const float y) noexcept {
            if (vertex_count >= maximum_vertices) {
                return;
            }
            vertices[vertex_count++] = ColoredVertex{
                darkness_color_at(x, y),
                kWorldOffsetX + x * kWorldScale,
                y * kWorldScale,
                0.0F,
            };
        };

        // One indexed-looking strip with degenerate joins gives the gradient
        // per-vertex interpolation without 4,800 sprite cells or 60 draw calls.
        for (std::size_t row = 0U; row < rows; ++row) {
            const float top = static_cast<float>(row) * kDarknessCellSize;
            const float bottom = std::min(
                top + kDarknessCellSize,
                game::GameWorld::kStageHeight);
            if (row > 0U) {
                const float previous_bottom = top;
                append_vertex(game::GameWorld::kStageWidth, previous_bottom);
                append_vertex(0.0F, top);
            }
            for (std::size_t column = 0U; column <= columns; ++column) {
                const float x = std::min(
                    static_cast<float>(column) * kDarknessCellSize,
                    game::GameWorld::kStageWidth);
                append_vertex(x, top);
                append_vertex(x, bottom);
            }
        }

        darkness_cached_vertex_count_ = vertex_count;
        darkness_source_signature_ = signature;
        darkness_cache_logic_tick_ = logic_tick;
        darkness_cache_valid_ = true;
    }

    if (darkness_cached_vertex_count_ == 0U) {
        return;
    }

    sceGuDrawArray(
        GU_TRIANGLE_STRIP,
        GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
        static_cast<int>(darkness_cached_vertex_count_),
        nullptr,
        darkness_vertex_cache_.data());
}

void PspRenderer::draw_death_timeline(
    const std::array<game::PlayerState, game::GameWorld::kPlayerCount>&
        players,
    const RenderStatus& status) noexcept {
    if (!death_texture_.loaded() || status.death_frame == 0U) {
        return;
    }
    const std::uint8_t frame = static_cast<std::uint8_t>(
        std::min<std::uint32_t>(
            status.death_frame,
            DeathTexture::kFrameCount) -
        1U);
    const std::uint8_t column =
        static_cast<std::uint8_t>(frame % DeathTexture::kColumns);
    const std::uint8_t row =
        static_cast<std::uint8_t>(frame / DeathTexture::kColumns);
    const float left_u = 1.0F +
        static_cast<float>(column) * DeathTexture::kFrameStrideX;
    const float top_v = 1.0F +
        static_cast<float>(row) * DeathTexture::kFrameStrideY;

    bind_texture(
        death_texture_.data(),
        DeathTexture::kTextureWidth,
        DeathTexture::kTextureHeight,
        false,
        TextureFilter::Nearest);
    for (const game::PlayerState& player : players) {
        if (!player.dead) {
            continue;
        }
        const float center_x =
            kWorldOffsetX +
            (player.x + player.width * 0.5F) * kWorldScale;
        const float center_y =
            (player.y + player.height * 0.5F) * kWorldScale;
        // The JPEXS canvas is stable across all 32 source frames.  Frame 1's
        // visible cloud is centred at (28.5, 85) in that canvas.
        constexpr float kInitialVisibleCenterX = 13.0F;
        constexpr float kInitialVisibleCenterY = 38.5F;
        draw_textured_screen_rect(
            center_x - kInitialVisibleCenterX,
            center_y - kInitialVisibleCenterY,
            DeathTexture::kFrameWidth,
            DeathTexture::kFrameHeight,
            left_u + 0.5F,
            top_v + 0.5F,
            left_u + DeathTexture::kFrameWidth - 0.5F,
            top_v + DeathTexture::kFrameHeight - 0.5F);
    }
    unbind_texture();
}

void PspRenderer::draw_finish_frame(
    const FinishTimeline timeline,
    const std::uint8_t source_frame,
    const float origin_x,
    const float origin_y) noexcept {
    if (!finish_texture_.loaded()) {
        return;
    }
    const std::size_t timeline_index = static_cast<std::size_t>(timeline);
    if (timeline_index >= kFinishContracts.size()) {
        return;
    }
    const FinishContract& contract = kFinishContracts[timeline_index];
    const std::uint8_t frame_number = static_cast<std::uint8_t>(
        std::clamp<std::uint32_t>(source_frame, 1U, contract.frame_count));
    const FinishFrame& frame =
        kFinishFrames[contract.frame_start + frame_number - 1U];
    bind_texture(
        finish_texture_.data(),
        FinishTexture::kTextureWidth,
        FinishTexture::kTextureHeight,
        false,
        TextureFilter::Nearest);
    draw_textured_screen_rect(
        kWorldOffsetX + (origin_x + contract.local_x) * kWorldScale,
        (origin_y + contract.local_y) * kWorldScale,
        static_cast<float>(frame.width) * kWorldScale,
        static_cast<float>(frame.height) * kWorldScale,
        static_cast<float>(frame.u) + 0.5F,
        static_cast<float>(frame.v) + 0.5F,
        static_cast<float>(frame.u + frame.width) - 0.5F,
        static_cast<float>(frame.v + frame.height) - 0.5F);
}

void PspRenderer::draw_completion_timeline(
    const game::GameWorld& world,
    const RenderStatus& status) noexcept {
    const auto draw_stairs = [this, &world, &status](
                                  const level::Vector2 position,
                                  const FinishTimeline timeline,
                                  const std::uint8_t maximum_frame) noexcept {
        const float origin_x =
            game::GameWorld::kLevelOffset +
            position.x * game::GameWorld::kTileSize;
        const float origin_y =
            game::GameWorld::kLevelOffset +
            (position.y + 0.66F) * game::GameWorld::kTileSize;
        draw_finish_frame(
            timeline,
            static_cast<std::uint8_t>(std::min<std::uint32_t>(
                status.completion_frame,
                maximum_frame)),
            origin_x,
            origin_y);
    };
    draw_stairs(
        world.level().fireboy_finish,
        FinishTimeline::FireStairs,
        25U);
    draw_stairs(
        world.level().watergirl_finish,
        FinishTimeline::WaterStairs,
        35U);
    unbind_texture();
}

void PspRenderer::update_tutorial_timeline(
    const game::GameWorld& world,
    const std::array<game::PlayerState, game::GameWorld::kPlayerCount>&
        players,
    const RenderStatus& status) noexcept {
#ifdef FFI_FOREST_TEMPLE
    if (world.level_index() != 0U || status.logic_tick == 0U) {
        tutorial_visible_ = false;
        tutorial_timeline_valid_ = false;
        return;
    }
    if (!tutorial_timeline_valid_) {
        tutorial_frame_ = 0U;
        tutorial_ui_tick_ = status.ui_tick - 1U;
        tutorial_timeline_valid_ = true;
    }
    if (status.ui_tick == tutorial_ui_tick_) {
        return;
    }
    tutorial_ui_tick_ = status.ui_tick;
    const auto frame = kForestHitFrames[tutorial_frame_];
    tutorial_visible_ = std::all_of(players.begin(), players.end(), [&](const auto& player) {
        // level.Update queries scaled sprite positions before the stage offset.
        const float x = player.x + player.width * 0.5F - game::GameWorld::kLevelOffset;
        const float y = player.y + player.height * 0.5F - game::GameWorld::kLevelOffset;
        const auto first = kForestHitRects.begin() + static_cast<std::ptrdiff_t>(frame.offset);
        return std::any_of(first, first + static_cast<std::ptrdiff_t>(frame.count),
            [x, y](const auto& region) {
                return x >= region.left && x <= region.right &&
                    y >= region.top && y <= region.bottom;
            });
    });
    if (!tutorial_visible_) {
        tutorial_frame_ = static_cast<std::uint8_t>(
            (tutorial_frame_ + 1U) % kForestTutorial.size());
    }
#else
    const TutorialContract* requested = nullptr;
    if (world.level().mode == level::LevelMode::Adventure) {
        for (const TutorialContract& candidate : kTutorialContracts) {
            if (candidate.level_number == world.level().number) {
                requested = &candidate;
                break;
            }
        }
    }
    if (requested == nullptr) {
        tutorial_contract_ = nullptr;
        tutorial_visible_ = false;
        tutorial_timeline_valid_ = false;
        return;
    }
    if (!tutorial_timeline_valid_ ||
        tutorial_contract_ != requested ||
        tutorial_level_index_ != world.level_index()) {
        tutorial_contract_ = requested;
        tutorial_level_index_ = world.level_index();
        tutorial_ui_tick_ = status.ui_tick;
        tutorial_frame_ = 0U;
        tutorial_visible_ = false;
        tutorial_timeline_valid_ = true;
    }
    if (status.ui_tick == tutorial_ui_tick_) {
        return;
    }

    const std::uint32_t elapsed = status.ui_tick - tutorial_ui_tick_;
    tutorial_ui_tick_ = status.ui_tick;
    for (std::uint32_t tick = 0U; tick < elapsed; ++tick) {
        const TutorialHitFrame& frame = kTutorialHitFrames[
            tutorial_contract_->frame_offset + tutorial_frame_];
        bool both_inside = true;
        for (const game::PlayerState& player : players) {
            const float point_x = player.x + player.width * 0.5F;
            const float point_y = player.y + player.height * 0.5F;
            bool inside = false;
            for (std::uint8_t index = 0U;
                 index < frame.rect_count;
                 ++index) {
                const TutorialHitRect& rectangle =
                    kTutorialHitRects[frame.rect_offset + index];
                if (point_x >= rectangle.left &&
                    point_x <= rectangle.right &&
                    point_y >= rectangle.top &&
                    point_y <= rectangle.bottom) {
                    inside = true;
                    break;
                }
            }
            both_inside = both_inside && inside;
        }
        tutorial_visible_ = both_inside;
        if (!both_inside) {
            tutorial_frame_ = static_cast<std::uint8_t>(
                (tutorial_frame_ + 1U) %
                tutorial_contract_->frame_count);
        }
    }
#endif
}

void PspRenderer::draw_tutorial() noexcept {
#ifdef FFI_FOREST_TEMPLE
    if (tutorial_visible_) {
        draw_forest_art(kForestTutorial[tutorial_frame_]);
        unbind_texture();
    }
#else
    if (!tutorial_visible_ ||
        tutorial_contract_ == nullptr ||
        ui_textures_.current() != UiTexture::Overlay) {
        return;
    }
    bind_texture(
        ui_textures_.data(),
        UiTextures::kTextureWidth,
        UiTextures::kTextureHeight,
        false,
        TextureFilter::Nearest);
    draw_textured_screen_rect(
        kWorldOffsetX + tutorial_contract_->world_x * kWorldScale,
        tutorial_contract_->world_y * kWorldScale,
        tutorial_contract_->width * kWorldScale,
        tutorial_contract_->height * kWorldScale,
        tutorial_contract_->atlas_u + 0.5F,
        tutorial_contract_->atlas_v + 0.5F,
        tutorial_contract_->atlas_u + tutorial_contract_->atlas_width - 0.5F,
        tutorial_contract_->atlas_v + tutorial_contract_->atlas_height - 0.5F);
    unbind_texture();
#endif
}

#ifdef FFI_FOREST_TEMPLE
void PspRenderer::draw_forest_art(
    const ForestArt art, const float dx, const float dy) noexcept {
    const auto& frame = kForestArtFrames[static_cast<std::size_t>(art)];
    if (!ui_textures_.select(frame.texture)) {
        return;
    }
    bind_texture(ui_textures_.data(), UiTextures::kTextureWidth, UiTextures::kTextureHeight,
        false, TextureFilter::Linear);
    draw_textured_screen_rect(
        kWorldOffsetX + frame.stage_x + dx, frame.stage_y + dy,
        frame.width, frame.height,
        frame.u + 0.5F, frame.v + 0.5F,
        frame.u + frame.width - 0.5F, frame.v + frame.height - 0.5F);
}

void PspRenderer::draw_forest_map(const RenderStatus& status) noexcept {
    const std::size_t selected = std::min<std::size_t>(
        status.selected_map_node, game::kOriginalMapNodeCount - 1U);
    const auto mode_for = [](const std::size_t node) -> std::size_t {
        const auto index = game::kOriginalMapLevelIndices[node];
        return index < 17U ? 0U : (game::is_map_puzzle_level(index) ? 1U : 2U);
    };
    for (std::size_t node = 0; node < game::kOriginalMapNodeCount; ++node) {
        if (status.map_grades[node] >= 0) {
            draw_forest_art(kForestRoads[node]);
        }
    }
    for (std::size_t node = 0; node < game::kOriginalMapNodeCount; ++node) {
        const std::size_t mode = mode_for(node);
        const auto point = game::kOriginalMapPoints[node];
        const float dx = (point.x - 320.0F) * kWorldScale;
        const float dy = (point.y - 240.0F) * kWorldScale;
        if (node == selected && status.map_grades[node] >= 0) {
            draw_forest_art(kForestNodeGlows[mode], dx, dy);
        }
        if (status.map_new_nodes[node]) {
            draw_forest_art(kForestNodeNews[mode], dx, dy);
        }
        const auto grade = static_cast<std::size_t>(std::clamp<int>(status.map_grades[node], 0, 3));
        draw_forest_art(kForestNodeGrades[mode * 4U + grade], dx, dy);
    }
    if (status.map_back_button_down) {
        draw_forest_art(ForestArt::MapBackDown);
    }

    const auto target = game::kOriginalMapPoints[selected];
    if (status.map_grades[selected] > 0) {
        const std::uint32_t seconds = status.selected_best_time_seconds;
        char time[6]{};
        std::snprintf(time, sizeof(time), "%02u:%02u",
            static_cast<unsigned>(seconds / 60U % 100U),
            static_cast<unsigned>(seconds % 60U));
        const auto anchor = kForestMapTimeAnchors[mode_for(selected)];
        const float width = 4.0F * kForestMapTimeDigitAdvance + kForestMapTimeColonAdvance;
        float x = target.x + anchor.x - 320.0F - width * 0.5F;
        const float dy = (target.y + anchor.y - 240.0F) * kWorldScale;
        constexpr int viewport_left = static_cast<int>(kWorldOffsetX + 0.5F);
        constexpr int viewport_right = static_cast<int>(kWorldOffsetX + kWorldViewportWidth + 0.5F);
        sceGuScissor(viewport_left, 0, viewport_right - viewport_left, kScreenHeight);
        for (std::size_t index = 0; index < sizeof(time) - 1U; ++index) {
            const bool colon = time[index] == ':';
            const auto glyph = colon ? 10U : static_cast<unsigned>(time[index] - '0');
            const float advance = colon ? kForestMapTimeColonAdvance : kForestMapTimeDigitAdvance;
            draw_forest_art(kForestMapTimeGlyphs[glyph], (x + advance * 0.5F) * kWorldScale, dy);
            x += advance;
        }
        sceGuScissor(0, 0, kScreenWidth, kScreenHeight);
    }

    if (!map_cursor_timeline_valid_) {
        map_cursor_x_ = 313.8F;
        map_cursor_y_ = 449.2F;
        map_cursor_vx_ = 0.0F;
        map_cursor_vy_ = 0.0F;
        map_cursor_ui_tick_ = status.ui_tick;
        map_cursor_timeline_valid_ = true;
    }
    const auto ticks = std::min<std::uint32_t>(status.ui_tick - map_cursor_ui_tick_, 8U);
    map_cursor_ui_tick_ = status.ui_tick;
    for (std::uint32_t tick = 0U; tick < ticks; ++tick) {
        map_cursor_vx_ = (map_cursor_vx_ + (target.x - map_cursor_x_) / 5.0F) * 0.7F;
        map_cursor_vy_ = (map_cursor_vy_ + (target.y - map_cursor_y_) / 5.0F) * 0.7F;
        map_cursor_x_ += map_cursor_vx_;
        map_cursor_y_ += map_cursor_vy_;
    }
    draw_forest_art(kForestFlies[status.ui_tick % kForestFlies.size()],
        (map_cursor_x_ - 320.0F) * kWorldScale, (map_cursor_y_ - 240.0F) * kWorldScale);
    unbind_texture();

    if (status.map_info_overlay != MapInfoOverlay::None) {
        for (std::size_t node = 0; node < game::kOriginalMapNodeCount; ++node) {
            const auto point = game::kOriginalMapPoints[node];
            char label[6]{};
            if (status.map_info_overlay == MapInfoOverlay::LevelNumbers) {
                std::snprintf(label, sizeof(label), "%u", static_cast<unsigned>(node + 1U));
            } else {
                const auto seconds = game::kOriginalMapTargetSeconds[node];
                std::snprintf(label, sizeof(label), "%02u:%02u", seconds / 60U % 100U, seconds % 60U);
            }
            draw_text(kWorldOffsetX + point.x * kWorldScale - 6.0F,
                point.y * kWorldScale - 4.0F, label, 1.0F, kColorText);
        }
    }
    draw_text(3.0F, 224.0F, "D PAD", 1.0F, kColorText);
    draw_text(3.0F, 236.0F, "X PLAY", 1.0F, kColorText);
    draw_text(432.0F, 236.0F, "O BACK", 1.0F, kColorText);
}

void PspRenderer::draw_forest_panels(
    const game::GameWorld& world, const RenderStatus& status) noexcept {
    const auto draw_panel_text = [this](
        const char* text, const ForestPanelTextOrigin origin, const float dy) {
        float x = (origin.x - 320.0F) * kWorldScale;
        const float y = (origin.y - 240.0F) * kWorldScale + dy;
        for (const char* character = text; *character != '\0'; ++character) {
            if (*character == ' ') {
                x += kForestPanelSpaceAdvance * kWorldScale;
                continue;
            }
            const bool colon = *character == ':';
            const auto glyph = colon ? 10U : static_cast<unsigned>(*character - '0');
            draw_forest_art(kForestPanelGlyphs[glyph], x, y);
            x += (colon ? kForestPanelColonAdvance : kForestPanelDigitAdvance) * kWorldScale;
        }
    };
    const auto draw_count = [&draw_panel_text](
        const ForestPanelTextOrigin origin, const float dy, const unsigned value) {
        char count[4]{};
        std::snprintf(count, sizeof(count), "%u", std::min(value, 999U));
        draw_panel_text(count, origin, dy);
    };
    const auto draw_tapper = [this](const float alpha) {
        unbind_texture();
        draw_world_rect(0.0F, 0.0F, 640.0F, 480.0F,
            black_alpha(std::clamp(alpha, 0.0F, 1.0F), 0xB0U));
    };
    const unsigned blue = world.collected_gems(level::TileType::WatergirlGem);
    const unsigned red = world.collected_gems(level::TileType::FireboyGem);
    if (result_overlay_ == ResultOverlay::None) {
        const bool pause_visible = pause_position_ < kPauseHiddenPosition - 0.2F;
        if (pause_visible) {
            draw_tapper(1.0F - (pause_position_ - kPauseShownPosition) / 390.0F);
        }
        const float pause_dy = (pause_position_ - kPauseShownPosition) * kWorldScale;
        draw_forest_art(ForestArt::PauseBoard, 0.0F, pause_dy);
        if (pause_visible) {
            draw_count(kForestPanelPauseBlue, pause_dy, blue);
            draw_count(kForestPanelPauseRed, pause_dy, red);
            unbind_texture();
            draw_text(3.0F, 220.0F, "X RESUME", 1.0F, kColorText);
            draw_text(3.0F, 232.0F, "SEL RETRY", 1.0F, kColorText);
            draw_text(432.0F, 232.0F, "O MAP", 1.0F, kColorText);
        }
    }
    draw_global_controls(status);
    if (result_overlay_ == ResultOverlay::None) {
        return;
    }
    draw_tapper(std::fabs((result_position_ + 164.0F) / 390.0F));
    const float dy = (result_position_ - kResultShownPosition) * kWorldScale;
    if (result_overlay_ == ResultOverlay::Failed) {
        draw_forest_art(ForestArt::FailBoard, 0.0F, dy);
        unbind_texture();
        draw_text(3.0F, 232.0F, "X RETRY", 1.0F, kColorText);
        draw_text(432.0F, 232.0F, "O MAP", 1.0F, kColorText);
        return;
    }
    const bool puzzle = world.level().mode == level::LevelMode::Puzzle;
    const std::uint32_t seconds = status.completion_elapsed_seconds;
    const unsigned green = world.collected_gems(level::TileType::SharedGem);
    std::size_t grade = 0U;
    if (puzzle) {
        grade = green == 1U ? 3U : 0U;
    } else {
        const auto node = std::min<std::size_t>(status.selected_map_node, game::kOriginalMapNodeCount - 1U);
        const bool fast = seconds <= game::kOriginalMapTargetSeconds[node];
        const bool all_gems = world.collected_gems() == world.total_gems();
        grade = 1U + (fast ? 1U : 0U) + (all_gems ? 1U : 0U);
    }
    draw_forest_art(puzzle ? ForestArt::ResultPuzzle : ForestArt::ResultNormal, 0.0F, dy);
    draw_forest_art(kForestResultGrades[grade], 0.0F, dy);
    char elapsed[8]{};
    std::snprintf(elapsed, sizeof(elapsed), "%02u : %02u",
        static_cast<unsigned>(seconds / 60U % 100U),
        static_cast<unsigned>(seconds % 60U));
    constexpr float time_width = 4.0F * kForestPanelDigitAdvance +
        kForestPanelColonAdvance + 2.0F * kForestPanelSpaceAdvance;
    draw_panel_text(elapsed, {kForestPanelResultTime.x - time_width * 0.5F,
        kForestPanelResultTime.y}, dy);
    if (puzzle) {
        draw_count(kForestPanelResultGreen, dy, green);
    } else {
        draw_count(kForestPanelResultBlue, dy, blue);
        draw_count(kForestPanelResultRed, dy, red);
    }
    unbind_texture();
    draw_text(3.0F, 232.0F, "X MAP", 1.0F, kColorText);
}
#endif

void PspRenderer::draw_hud(const RenderStatus& status) noexcept {
#ifdef FFI_FOREST_TEMPLE
    draw_forest_art(ForestArt::Watch);
    const std::uint32_t elapsed_seconds = status.logic_tick / 25U;
    const std::uint32_t watch_minutes = (elapsed_seconds / 60U) % 100U;
    const std::uint32_t watch_seconds = elapsed_seconds % 60U;
    constexpr float advance = kForestWatchDigitAdvance * kWorldScale;
    constexpr float second_x = kForestWatchSecondX * kWorldScale;
    constexpr float second_y = kForestWatchSecondY * kWorldScale;
    draw_forest_art(kForestWatchDigits[watch_minutes / 10U]);
    draw_forest_art(kForestWatchDigits[watch_minutes % 10U], advance);
    draw_forest_art(kForestWatchDigits[watch_seconds / 10U], second_x, second_y);
    draw_forest_art(kForestWatchDigits[watch_seconds % 10U], second_x + advance, second_y);
    unbind_texture();
#else
    if (!ui_textures_.select(UiTexture::Map)) {
        return;
    }
    bind_texture(
        ui_textures_.data(),
        UiTextures::kTextureWidth,
        UiTextures::kTextureHeight,
        false,
        TextureFilter::Linear);

    const float watch_anchor_x =
        kWorldOffsetX + kGameplayWatchSourceX * kWorldScale;
    const float watch_anchor_y = kGameplayWatchSourceY * kWorldScale;
    draw_gameplay_hud_frame_bound(
        kGameplayWatchStaticFrame,
        watch_anchor_x,
        watch_anchor_y);

    const std::uint32_t elapsed_seconds = status.logic_tick / 25U;
    const std::uint32_t minutes = (elapsed_seconds / 60U) % 100U;
    const std::uint32_t seconds = elapsed_seconds % 60U;
    const char minute_text[3]{
        static_cast<char>('0' + minutes / 10U),
        static_cast<char>('0' + minutes % 10U),
        '\0',
    };
    const char second_text[3]{
        static_cast<char>('0' + seconds / 10U),
        static_cast<char>('0' + seconds % 10U),
        '\0',
    };
    draw_gameplay_hud_text_bound(
        minute_text,
        kGameplayMinuteOrigin,
        watch_anchor_x,
        watch_anchor_y);
    draw_gameplay_hud_text_bound(
        second_text,
        kGameplaySecondOrigin,
        watch_anchor_x,
        watch_anchor_y);

    // MiniClipLogo is positioned at (-43, 6) in Game.as. Its source
    // translation is already folded into the generated frame pivot.
    draw_gameplay_hud_frame_bound(
        kGameplayMiniClipLogoFrame,
        kWorldOffsetX,
        0.0F);
    unbind_texture();
#endif
}

void PspRenderer::draw_global_controls(
    const RenderStatus& status) noexcept {
#ifdef FFI_FOREST_TEMPLE
    if (status.screen == UiScreen::Gameplay) {
        draw_forest_art(status.muted ? ForestArt::SoundOff : ForestArt::SoundOn);
        unbind_texture();
    }
    draw_text(3.0F, 12.0F, status.muted ? "R SOUND" : "R MUTE", 1.0F, kColorText);
    return;
#endif
    if (!ui_textures_.select(UiTexture::Start)) {
        return;
    }
    bind_texture(
        ui_textures_.data(),
        UiTextures::kTextureWidth,
        UiTextures::kTextureHeight,
        false,
        TextureFilter::Linear);

    const auto draw_frame = [](const GlobalUiFrame& frame,
                               const float anchor_x,
                               const float anchor_y) noexcept {
        draw_textured_screen_rect(
            anchor_x - frame.pivot_x,
            anchor_y - frame.pivot_y,
            frame.width,
            frame.height,
            frame.atlas_u + 0.5F,
            frame.atlas_v + 0.5F,
            frame.atlas_u + frame.width - 0.5F,
            frame.atlas_v + frame.height - 0.5F);
    };

    const float mute_anchor_x =
        kWorldOffsetX + kGlobalMuteSourceX * kWorldScale;
    const float mute_anchor_y = kGlobalMuteSourceY * kWorldScale;
    draw_frame(
        kGlobalMuteFrames[status.muted ? 1U : 0U],
        mute_anchor_x,
        mute_anchor_y);

    const float quality_source_x =
        status.screen == UiScreen::Gameplay
            ? kGlobalGameplayQualitySourceX
            : kGlobalMenuQualitySourceX;
    const float quality_anchor_x =
        kWorldOffsetX + quality_source_x * kWorldScale;
    const float quality_anchor_y = kGlobalQualitySourceY * kWorldScale;
    draw_frame(
        kGlobalQualityFrames[static_cast<std::size_t>(status.quality)],
        quality_anchor_x,
        quality_anchor_y);
    unbind_texture();
    draw_text(3.0F, 12.0F, "R MUTE", 0.45F, kColorText);
    draw_text(425.0F, 27.0F, "R+L Q", 0.45F, kColorText);
}

void PspRenderer::draw_source_panel(
    const float x,
    const float y,
    const std::uint32_t jewel_color) noexcept {
    if (ui_textures_.current() != UiTexture::Overlay) {
        draw_screen_rect(x, y, UiTextures::kPanelWidth, UiTextures::kPanelHeight, kColorPanel);
        return;
    }
    bind_texture(
        ui_textures_.data(),
        UiTextures::kTextureWidth,
        UiTextures::kTextureHeight,
        false,
        TextureFilter::Nearest);
    draw_textured_screen_rect(
        x,
        y,
        UiTextures::kPanelWidth,
        UiTextures::kPanelHeight,
        UiTextures::kPanelU + 0.5F,
        UiTextures::kPanelV + 0.5F,
        UiTextures::kPanelU + UiTextures::kPanelWidth - 0.5F,
        UiTextures::kPanelV + UiTextures::kPanelHeight - 0.5F);
    unbind_texture();
    draw_screen_triangle(
        x + 92.5F,
        y + 8.0F,
        x + 99.0F,
        y + 14.5F,
        x + 92.5F,
        y + 21.0F,
        jewel_color);
    draw_screen_triangle(
        x + 92.5F,
        y + 8.0F,
        x + 92.5F,
        y + 21.0F,
        x + 86.0F,
        y + 14.5F,
        jewel_color);
}

void PspRenderer::draw_result_frame_bound(
    const ResultAtlasFrame& frame,
    const float anchor_x,
    const float anchor_y) noexcept {
    draw_textured_screen_rect(
        anchor_x - frame.pivot_x,
        anchor_y - frame.pivot_y,
        frame.width,
        frame.height,
        frame.atlas_u + 0.5F,
        frame.atlas_v + 0.5F,
        frame.atlas_u + frame.width - 0.5F,
        frame.atlas_v + frame.height - 0.5F);
}

void PspRenderer::draw_pause_gameover_frame_bound(
    const PauseGameOverFrame& frame,
    const float anchor_x,
    const float anchor_y) noexcept {
    draw_textured_screen_rect(
        anchor_x - frame.pivot_x,
        anchor_y - frame.pivot_y,
        frame.width,
        frame.height,
        frame.atlas_u + 0.5F,
        frame.atlas_v + 0.5F,
        frame.atlas_u + frame.width - 0.5F,
        frame.atlas_v + frame.height - 0.5F);
}

void PspRenderer::draw_gameplay_hud_frame_bound(
    const GameplayHudFrame& frame,
    const float anchor_x,
    const float anchor_y) noexcept {
    draw_textured_screen_rect(
        anchor_x - frame.pivot_x,
        anchor_y - frame.pivot_y,
        frame.width,
        frame.height,
        frame.atlas_u + 0.5F,
        frame.atlas_v + 0.5F,
        frame.atlas_u + frame.width - 0.5F,
        frame.atlas_v + frame.height - 0.5F);
}

void PspRenderer::draw_gameplay_hud_text_bound(
    const char* const text,
    const GameplayHudTextOrigin& origin,
    const float anchor_x,
    const float anchor_y) noexcept {
    if (text == nullptr) {
        return;
    }
    static constexpr auto glyph_lookup = [] {
        std::array<const GameplayHudGlyph*, 256> lookup{};
        for (const GameplayHudGlyph& glyph : kGameplayHudGlyphs) {
            const auto index = static_cast<unsigned char>(glyph.character);
            // Preserve the linear search's first match if characters repeat.
            if (lookup[index] == nullptr) {
                lookup[index] = &glyph;
            }
        }
        return lookup;
    }();
    float cursor_x = origin.x;
    for (const char* cursor = text; *cursor != '\0'; ++cursor) {
        const GameplayHudGlyph* const match =
            glyph_lookup[static_cast<unsigned char>(*cursor)];
        if (match != nullptr) {
            const GameplayHudGlyph& glyph = *match;
            draw_gameplay_hud_frame_bound(
                glyph.frame,
                anchor_x + cursor_x,
                anchor_y + origin.baseline_y);
            cursor_x += glyph.advance;
        }
    }
}

void PspRenderer::draw_result_text_bound(
    const char* const text,
    const ResultTextOrigin& origin,
    const float anchor_x,
    const float anchor_y,
    const bool centered) noexcept {
    if (text == nullptr) {
        return;
    }
    float width = 0.0F;
    if (centered) {
        for (const char* cursor = text; *cursor != '\0'; ++cursor) {
            for (const ResultGlyph& glyph : kResultGlyphs) {
                if (glyph.character == *cursor) {
                    width += glyph.advance;
                    break;
                }
            }
        }
    }
    float cursor_x = origin.x - (centered ? width * 0.5F : 0.0F);
    for (const char* cursor = text; *cursor != '\0'; ++cursor) {
        for (const ResultGlyph& glyph : kResultGlyphs) {
            if (glyph.character != *cursor) {
                continue;
            }
            if (*cursor != ' ') {
                draw_result_frame_bound(
                    glyph.frame,
                    anchor_x + cursor_x,
                    anchor_y + origin.baseline_y);
            }
            cursor_x += glyph.advance;
            break;
        }
    }
}

void PspRenderer::draw_text(
    const float x,
    const float y,
    const char* text,
    const float pixel_size,
    const std::uint32_t color) noexcept {
    if (text == nullptr || pixel_size <= 0.0F) {
        return;
    }

    std::size_t pixel_count = 0;
    for (const char* current = text; *current != '\0'; ++current) {
        if (*current == '\n' || *current == ' ') {
            continue;
        }
        const std::array<std::uint8_t, 7> rows = glyph_rows(*current);
        for (std::uint8_t row = 0; row < 7U; ++row) {
            for (std::uint8_t column = 0; column < 5U; ++column) {
                const std::uint8_t bit =
                    static_cast<std::uint8_t>(1U << (4U - column));
                if ((rows[row] & bit) != 0U) {
                    ++pixel_count;
                }
            }
        }
    }
    if (pixel_count == 0U) {
        return;
    }

    auto* const vertices = static_cast<ColoredVertex*>(
        sceGuGetMemory(pixel_count * 2U * sizeof(ColoredVertex)));
    std::size_t vertex_count = 0;
    float cursor_x = x;
    float cursor_y = y;
    for (const char* current = text; *current != '\0'; ++current) {
        if (*current == '\n') {
            cursor_x = x;
            cursor_y += 8.0F * pixel_size;
            continue;
        }

        const std::array<std::uint8_t, 7> rows = glyph_rows(*current);
        for (std::uint8_t row = 0; row < 7U; ++row) {
            for (std::uint8_t column = 0; column < 5U; ++column) {
                const std::uint8_t bit =
                    static_cast<std::uint8_t>(1U << (4U - column));
                if ((rows[row] & bit) == 0U) {
                    continue;
                }
                const float left =
                    cursor_x + static_cast<float>(column) * pixel_size;
                const float top =
                    cursor_y + static_cast<float>(row) * pixel_size;
                vertices[vertex_count++] =
                    ColoredVertex{color, left, top, 0.0F};
                vertices[vertex_count++] = ColoredVertex{
                    color,
                    left + pixel_size,
                    top + pixel_size,
                    0.0F,
                };
            }
        }
        cursor_x += 6.0F * pixel_size;
    }

    sceGuDrawArray(
        GU_SPRITES,
        GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
        static_cast<int>(vertex_count),
        nullptr,
        vertices);
}

void PspRenderer::draw_start_menu(const RenderStatus& status) noexcept {
#ifdef FFI_FOREST_TEMPLE
    if (ui_textures_.current() == UiTexture::Start) {
        if (status.intro_info_overlay != IntroInfoOverlay::None) {
            draw_forest_art(status.intro_info_overlay == IntroInfoOverlay::Instructions
                ? ForestArt::Instructions : ForestArt::Credits);
            unbind_texture();
            draw_text(432.0F, 248.0F, "X OK", 1.0F, kColorText);
        } else {
            const auto item = 2U * static_cast<std::size_t>(status.intro_menu_selection);
            if (item < kForestIntroFocus.size()) {
                const bool down = status.intro_menu_button_down || status.start_button_down;
                draw_forest_art(kForestIntroFocus[item + (down ? 1U : 0U)]);
            }
            unbind_texture();
            draw_text(3.0F, 248.0F, "D PAD", 1.0F, kColorText);
            draw_text(425.0F, 248.0F, "X SELECT", 1.0F, kColorText);
        }
        return;
    }
#endif
    if (ui_textures_.current() == UiTexture::Start) {
        const auto draw_bound_frame = [](const MapAtlasFrame& frame) noexcept {
            draw_textured_screen_rect(
                kWorldOffsetX - frame.pivot_x,
                -frame.pivot_y,
                frame.width,
                frame.height,
                frame.atlas_u + 0.5F,
                frame.atlas_v + 0.5F,
                frame.atlas_u + frame.width - 0.5F,
                frame.atlas_v + frame.height - 0.5F);
        };

        if (status.start_button_down ||
            status.intro_menu_selection == IntroMenuSelection::Start) {
            const MapAtlasFrame& frame = kIntroStartButtonFrames[
                status.start_button_down || status.intro_menu_button_down
                    ? 2U
                    : 1U];
            bind_texture(
                ui_textures_.data(),
                UiTextures::kTextureWidth,
                UiTextures::kTextureHeight,
                false,
                TextureFilter::Linear);
            draw_bound_frame(frame);
            unbind_texture();
        }

        const std::array<MapAtlasFrame, 3>* selected_button_frames = nullptr;
        switch (status.intro_menu_selection) {
            case IntroMenuSelection::Start:
                break;
            case IntroMenuSelection::Instructions:
                selected_button_frames = &kIntroInstructionButtonFrames;
                break;
            case IntroMenuSelection::Submit:
                selected_button_frames = &kIntroSubmitButtonFrames;
                break;
            case IntroMenuSelection::More:
                selected_button_frames = &kIntroMoreButtonFrames;
                break;
            case IntroMenuSelection::Credits:
                selected_button_frames = &kIntroCreditsButtonFrames;
                break;
            case IntroMenuSelection::Forest:
                selected_button_frames = &kIntroForestButtonFrames;
                break;
            case IntroMenuSelection::Light:
                selected_button_frames = &kIntroLightButtonFrames;
                break;
        }
        if (status.intro_info_overlay == IntroInfoOverlay::None &&
            selected_button_frames != nullptr &&
            ui_textures_.select(UiTexture::Overlay)) {
            bind_texture(
                ui_textures_.data(),
                UiTextures::kTextureWidth,
                UiTextures::kTextureHeight,
                false,
                TextureFilter::Linear);
            const MapAtlasFrame& frame = (*selected_button_frames)[
                status.intro_menu_button_down ? 2U : 1U];
            draw_bound_frame(frame);
            unbind_texture();
        }

        if (status.intro_info_overlay != IntroInfoOverlay::None &&
            ui_textures_.select(UiTexture::Info)) {
            bind_texture(
                ui_textures_.data(),
                UiTextures::kTextureWidth,
                UiTextures::kTextureHeight,
                false,
                TextureFilter::Linear);
            const std::size_t panel_index =
                status.intro_info_overlay == IntroInfoOverlay::Instructions
                    ? 0U
                    : 1U;
            draw_bound_frame(kIntroInfoPanelFrames[panel_index]);
            // OKO 431 has a transparent Up state. PSP focus corresponds to
            // its source Over state, followed by one Down timeline tick.
            draw_bound_frame(kIntroInfoOkButtonFrames[
                status.intro_info_ok_button_down ? 1U : 0U]);
            unbind_texture();
        }

        if (status.transition_alpha <= 0.0F) {
            // PSP controls live only in the 58 px pillarbox. The original
            // IntroMenu 697 stage remains pixel-clean.
            if (status.intro_info_overlay == IntroInfoOverlay::None) {
                draw_text(3.0F, 247.0F, "D PAD", 0.55F, kColorText);
                draw_text(425.0F, 247.0F, "X SELECT", 0.50F, kColorText);
            } else {
                draw_text(3.0F, 247.0F, "X OK", 0.55F, kColorText);
                draw_text(425.0F, 247.0F, "O BACK", 0.50F, kColorText);
            }
            if (!status.data_loaded) {
                draw_text(3.0F, 236.0F, "DATA ERR", 0.55F, kColorError);
            }
        }
        return;
    }
    draw_screen_rect(0.0F, 0.0F, 240.0F, 272.0F, 0x70302018U);
    draw_screen_rect(240.0F, 0.0F, 240.0F, 272.0F, 0x70182830U);
    draw_screen_rect(35.0F, 17.0F, 410.0F, 76.0F, kColorPanel);
    draw_screen_rect(35.0F, 17.0F, 205.0F, 4.0F, kColorFireboy);
    draw_screen_rect(240.0F, 17.0F, 205.0F, 4.0F, kColorWatergirl);

    draw_text(96.0F, 34.0F, "FOREST", 3.0F, kColorConnected);
    draw_text(226.0F, 34.0F, "FIRE", 3.0F, kColorFireboy);
    draw_text(318.0F, 34.0F, "ICE", 3.0F, kColorWatergirl);
    draw_text(150.0F, 73.0F, "COOPERATIVE TEMPLE QUEST", 1.0F, kColorText);

    draw_screen_rect(74.0F, 183.0F, 126.0F, 7.0F, 0xFF493727U);
    draw_screen_rect(280.0F, 183.0F, 126.0F, 7.0F, 0xFF293C4CU);

    game::PlayerState fireboy{};
    fireboy.id = game::PlayerId::Fireboy;
    fireboy.x = 180.0F;
    fireboy.y = 290.0F;
    fireboy.width = 14.0F;
    fireboy.height = 27.0F;
    fireboy.grounded = true;
    fireboy.facing_right = true;
    if (!draw_player_sprite(fireboy)) {
        draw_screen_rect(116.0F, 125.0F, 34.0F, 58.0F, kColorFireboy);
    }

    game::PlayerState watergirl{};
    watergirl.id = game::PlayerId::Watergirl;
    watergirl.x = 446.0F;
    watergirl.y = 290.0F;
    watergirl.width = 14.0F;
    watergirl.height = 27.0F;
    watergirl.grounded = true;
    watergirl.facing_right = false;
    if (!draw_player_sprite(watergirl)) {
        draw_screen_rect(330.0F, 125.0F, 34.0F, 58.0F, kColorWatergirl);
    }

    draw_screen_rect(139.0F, 200.0F, 202.0F, 42.0F, kColorPanel);
    draw_screen_rect(139.0F, 200.0F, 202.0F, 3.0F, kColorActive);
    draw_text(174.0F, 213.0F, "X ENTER LEVEL MAP", 1.25F, kColorText);
    draw_text(153.0F, 252.0F, "FIRE AND WATER MOVE AS ONE", 0.8F, kColorMutedText);

    if (!status.data_loaded) {
        draw_text(174.0F, 188.0F, "LEVEL DATA ERROR", 0.9F, kColorError);
    }
}

void PspRenderer::draw_level_map(
    const game::GameWorld& world,
    const RenderStatus& status) noexcept {
    const bool source_background =
        ui_textures_.current() == UiTexture::Map;
#ifdef FFI_FOREST_TEMPLE
    if (source_background) {
        draw_forest_map(status);
        return;
    }
#endif
    if (!source_background) {
        draw_screen_rect(0.0F, 0.0F, 480.0F, 272.0F, 0xB0181510U);
        draw_screen_rect(12.0F, 9.0F, 456.0F, 252.0F, kColorPanel);
        draw_text(18.0F, 17.0F, "GOLDEN ROAD", 1.35F, kColorText);
#ifdef FFI_FOREST_TEMPLE
        draw_text(359.0F, 19.0F, "32 NODES", 0.9F, kColorMutedText);
#else
        draw_text(359.0F, 19.0F, "41 NODES", 0.9F, kColorMutedText);
#endif
        draw_screen_rect(24.0F, 37.0F, 432.0F, 181.0F, 0xD01C1814U);
    }

    const auto node_center = [](const std::size_t node) noexcept {
        return std::array<float, 2>{
            kWorldOffsetX + game::kOriginalMapPoints[node].x * kWorldScale,
            game::kOriginalMapPoints[node].y * kWorldScale,
        };
    };

    for (const auto& edge : game::kOriginalMapEdges) {
        const std::array<float, 2> first = node_center(edge[0]);
        const std::array<float, 2> second = node_center(edge[1]);
        // Game.as CreateMainMenu draws camins2 first visually: an 11 px,
        // 36%-alpha #333333 underlay beneath the 8 px #535666 road.
        draw_screen_line(
            first[0],
            first[1],
            second[0],
            second[1],
            11.0F * kWorldScale,
            0x5C333333U);
        draw_screen_line(
            first[0],
            first[1],
            second[0],
            second[1],
            8.0F * kWorldScale,
            0xFF665653U);
        if (status.map_grades[edge[0]] > 0) {
            draw_screen_line(
                first[0],
                first[1],
                second[0],
                second[1],
                6.0F * kWorldScale,
                0xFF00CCFFU);
        }
    }

    const std::size_t selected_node = std::min<std::size_t>(
        status.selected_map_node,
        game::kOriginalMapNodeCount - 1U);
    const game::MapPoint cursor_target =
        game::kOriginalMapPoints[selected_node];
    if (!map_cursor_timeline_valid_) {
        // MainMenu 954 places flies at (62.2, 41.3) and CreateMainMenu starts
        // its spring with zero velocity.
        map_cursor_x_ = 62.2F;
        map_cursor_y_ = 41.3F;
        map_cursor_vx_ = 0.0F;
        map_cursor_vy_ = 0.0F;
        map_cursor_ui_tick_ = status.ui_tick;
        map_cursor_timeline_valid_ = true;
    }
    const std::uint32_t cursor_steps = std::min<std::uint32_t>(
        status.ui_tick - map_cursor_ui_tick_,
        8U);
    for (std::uint32_t step = 0; step < cursor_steps; ++step) {
        // Exact FliesMove spring constants from Game.as.
        map_cursor_vx_ += (cursor_target.x - map_cursor_x_) / 5.0F;
        map_cursor_vy_ += (cursor_target.y - map_cursor_y_) / 5.0F;
        map_cursor_vx_ *= 0.7F;
        map_cursor_vy_ *= 0.7F;
        map_cursor_x_ += map_cursor_vx_;
        map_cursor_y_ += map_cursor_vy_;
    }
    map_cursor_ui_tick_ = status.ui_tick;

    const bool source_nodes = ui_textures_.select(UiTexture::Overlay);
    if (source_nodes) {
        bind_texture(
            ui_textures_.data(),
            UiTextures::kTextureWidth,
            UiTextures::kTextureHeight,
            false,
            TextureFilter::Linear);
        for (std::size_t node = 0;
             node < game::kOriginalMapNodeCount;
             ++node) {
            const std::int8_t grade = status.map_grades[node];
            if (grade < 0) {
                continue;
            }
            const std::uint8_t visual_mode =
                kMapNodeVisualModeByNode[node];
            const MapNodeVisualContract& visual =
                kMapNodeVisuals[visual_mode];
            const std::array<float, 2> center = node_center(node);
            if (node == selected_node) {
                const MapAtlasFrame& glow =
                    kMapGlowerFrames[visual.glower_frame];
                draw_textured_screen_rect(
                    center[0] - glow.pivot_x,
                    center[1] - glow.pivot_y,
                    glow.width,
                    glow.height,
                    glow.atlas_u + 0.5F,
                    glow.atlas_v + 0.5F,
                    glow.atlas_u + glow.width - 0.5F,
                    glow.atlas_v + glow.height - 0.5F);
                if (status.selected_best_time_seconds > 0U) {
                    const std::uint32_t best =
                        status.selected_best_time_seconds;
                    const char hover_time[6]{
                        static_cast<char>('0' + (best / 600U) % 10U),
                        static_cast<char>('0' + (best / 60U) % 10U),
                        ':',
                        static_cast<char>('0' + (best / 10U) % 6U),
                        static_cast<char>('0' + best % 10U),
                        '\0',
                    };
                    const MapTimeOrigin& origin =
                        kMapTimeOrigins[visual_mode];
                    float glyph_x =
                        center[0] + origin.x * kWorldScale;
                    const float baseline_y =
                        center[1] + origin.baseline_y * kWorldScale;
                    for (const char character : hover_time) {
                        if (character == '\0') {
                            break;
                        }
                        const std::size_t glyph_index =
                            character == ':'
                                ? 10U
                                : static_cast<std::size_t>(character - '0');
                        const MapTimeGlyph& glyph =
                            kMapTimeGlyphs[glyph_index];
                        const MapAtlasFrame& glyph_frame = glyph.frame;
                        draw_textured_screen_rect(
                            glyph_x - glyph_frame.pivot_x,
                            baseline_y - glyph_frame.pivot_y,
                            glyph_frame.width,
                            glyph_frame.height,
                            glyph_frame.atlas_u + 0.5F,
                            glyph_frame.atlas_v + 0.5F,
                            glyph_frame.atlas_u + glyph_frame.width - 0.5F,
                            glyph_frame.atlas_v + glyph_frame.height - 0.5F);
                        glyph_x += glyph.advance;
                    }
                }
            }
            if (status.map_new_nodes[node]) {
                const MapAtlasFrame& now = kMapNowFrame;
                draw_textured_screen_rect(
                    center[0] - now.pivot_x,
                    center[1] - now.pivot_y,
                    now.width,
                    now.height,
                    now.atlas_u + 0.5F,
                    now.atlas_v + 0.5F,
                    now.atlas_u + now.width - 0.5F,
                    now.atlas_v + now.height - 0.5F);
            }
            const std::uint8_t source_grade =
                static_cast<std::uint8_t>(
                    std::clamp<int>(grade, 0, visual.frame_count - 1U));
            const MapAtlasFrame& frame =
                kMapNodeFrames[visual.frame_offset + source_grade];
            draw_textured_screen_rect(
                center[0] - frame.pivot_x,
                center[1] - frame.pivot_y,
                frame.width,
                frame.height,
                frame.atlas_u + 0.5F,
                frame.atlas_v + 0.5F,
                frame.atlas_u + frame.width - 0.5F,
                frame.atlas_v + frame.height - 0.5F);
        }
        const MapAtlasFrame& flies = kMapFliesFrames[
            status.ui_tick % kMapFliesSourceFrameCount];
        const float flies_anchor_x =
            kWorldOffsetX + map_cursor_x_ * kWorldScale;
        const float flies_anchor_y = map_cursor_y_ * kWorldScale;
        draw_textured_screen_rect(
            flies_anchor_x - flies.pivot_x,
            flies_anchor_y - flies.pivot_y,
            flies.width,
            flies.height,
            flies.atlas_u + 0.5F,
            flies.atlas_v + 0.5F,
            flies.atlas_u + flies.width - 0.5F,
            flies.atlas_v + flies.height - 0.5F);
        unbind_texture();
    }

    if (source_background && ui_textures_.select(UiTexture::Start)) {
        bind_texture(
            ui_textures_.data(),
            UiTextures::kTextureWidth,
            UiTextures::kTextureHeight,
            false,
            TextureFilter::Linear);
        const auto draw_shell_frame = [](const MapAtlasFrame& frame) noexcept {
            draw_textured_screen_rect(
                kWorldOffsetX - frame.pivot_x,
                -frame.pivot_y,
                frame.width,
                frame.height,
                frame.atlas_u + 0.5F,
                frame.atlas_v + 0.5F,
                frame.atlas_u + frame.width - 0.5F,
                frame.atlas_v + frame.height - 0.5F);
        };
        draw_shell_frame(kMapBackButtonFrames[
            status.map_back_button_down ? 2U : 0U]);
        const std::size_t number_button_state =
            status.map_number_button_down
                ? 2U
                : (status.map_info_overlay == MapInfoOverlay::LevelNumbers
                       ? 1U
                       : 0U);
        const std::size_t time_button_state =
            status.map_time_button_down
                ? 2U
                : (status.map_info_overlay == MapInfoOverlay::TargetTimes
                       ? 1U
                       : 0U);
        draw_shell_frame(kMapLevelNumberButtonFrames[number_button_state]);
        draw_shell_frame(kMapLevelTimeButtonFrames[time_button_state]);
        unbind_texture();
    }

    if (source_nodes &&
        status.map_info_overlay == MapInfoOverlay::LevelNumbers &&
        ui_textures_.select(UiTexture::Overlay)) {
        bind_texture(
            ui_textures_.data(),
            UiTextures::kTextureWidth,
            UiTextures::kTextureHeight,
            false,
            TextureFilter::Linear);
        // Nums 951 is depth 703. These 37 frames are sliced from the exact
        // filtered source sprite, retaining its non-sequential 0..36 layout.
        for (const MapNumberLabel& label : kMapNumberLabels) {
            const MapAtlasFrame& frame = label.frame;
            draw_textured_screen_rect(
                kWorldOffsetX - frame.pivot_x,
                -frame.pivot_y,
                frame.width,
                frame.height,
                frame.atlas_u + 0.5F,
                frame.atlas_v + 0.5F,
                frame.atlas_u + frame.width - 0.5F,
                frame.atlas_v + frame.height - 0.5F);
        }
        unbind_texture();
    }

    if (source_background && ui_textures_.select(UiTexture::Start)) {
        bind_texture(
            ui_textures_.data(),
            UiTextures::kTextureWidth,
            UiTextures::kTextureHeight,
            false,
            TextureFilter::Linear);
        // ArmorLogo is depth 741, after Nums 951 and before Times 953.
        const MapAtlasFrame& frame = kMapArmorLogoFrames[0];
        draw_textured_screen_rect(
            kWorldOffsetX - frame.pivot_x,
            -frame.pivot_y,
            frame.width,
            frame.height,
            frame.atlas_u + 0.5F,
            frame.atlas_v + 0.5F,
            frame.atlas_u + frame.width - 0.5F,
            frame.atlas_v + frame.height - 0.5F);
        unbind_texture();
    }

    if (source_nodes &&
        status.map_info_overlay == MapInfoOverlay::TargetTimes &&
        ui_textures_.select(UiTexture::Overlay)) {
        bind_texture(
            ui_textures_.data(),
            UiTextures::kTextureWidth,
            UiTextures::kTextureHeight,
            false,
            TextureFilter::Linear);
        for (std::size_t node = 0;
             node < game::kOriginalMapNodeCount;
             ++node) {
            const std::uint16_t target =
                game::kOriginalMapTargetSeconds[node];
            const char target_time[6]{
                static_cast<char>('0' + (target / 600U) % 10U),
                static_cast<char>('0' + (target / 60U) % 10U),
                ':',
                static_cast<char>('0' + (target / 10U) % 6U),
                static_cast<char>('0' + target % 10U),
                '\0',
            };
            float total_advance = 0.0F;
            for (std::size_t index = 0; index < 5U; ++index) {
                const char character = target_time[index];
                const std::size_t glyph_index =
                    character == ':'
                        ? 10U
                        : static_cast<std::size_t>(character - '0');
                total_advance += kMapTargetTimeGlyphs[glyph_index].advance;
            }
            const std::array<float, 2> center = node_center(node);
            float glyph_x = center[0] - total_advance * 0.5F;
            const float baseline_y = center[1];
            for (std::size_t index = 0; index < 5U; ++index) {
                const char character = target_time[index];
                const std::size_t glyph_index =
                    character == ':'
                        ? 10U
                        : static_cast<std::size_t>(character - '0');
                const MapTimeGlyph& glyph =
                    kMapTargetTimeGlyphs[glyph_index];
                const MapAtlasFrame& frame = glyph.frame;
                draw_textured_screen_rect(
                    glyph_x - frame.pivot_x,
                    baseline_y - frame.pivot_y,
                    frame.width,
                    frame.height,
                    frame.atlas_u + 0.5F,
                    frame.atlas_v + 0.5F,
                    frame.atlas_u + frame.width - 0.5F,
                    frame.atlas_v + frame.height - 0.5F);
                glyph_x += glyph.advance;
            }
        }
        unbind_texture();
    }

    if (!source_background) {
        char selected_node_text[3]{};
        format_two_digits(
            static_cast<std::uint8_t>(selected_node + 1U),
            selected_node_text);
        char selected_level[3]{};
        format_two_digits(world.level().number, selected_level);
        draw_text(29.0F, 224.0F, "NODE", 0.75F, kColorMutedText);
        draw_text(63.0F, 224.0F, selected_node_text, 0.75F, kColorText);
        draw_text(96.0F, 224.0F, mode_name(world.level().mode), 0.75F, mode_color(world.level().mode));
        draw_text(177.0F, 224.0F, selected_level, 0.75F, kColorText);
        draw_text(212.0F, 224.0F, "TARGET", 0.75F, kColorMutedText);
        const std::uint16_t target =
            game::kOriginalMapTargetSeconds[status.selected_map_node];
        char target_time[6]{
            static_cast<char>('0' + (target / 600U) % 10U),
            static_cast<char>('0' + (target / 60U) % 10U),
            ':',
            static_cast<char>('0' + (target / 10U) % 6U),
            static_cast<char>('0' + target % 10U),
            '\0',
        };
        draw_text(265.0F, 224.0F, target_time, 0.75F, kColorText);
        if (status.selected_best_time_seconds > 0U) {
            const std::uint32_t best = status.selected_best_time_seconds;
            char best_time[6]{
                static_cast<char>('0' + (best / 600U) % 10U),
                static_cast<char>('0' + (best / 60U) % 10U),
                ':',
                static_cast<char>('0' + (best / 10U) % 6U),
                static_cast<char>('0' + best % 10U),
                '\0',
            };
            draw_text(318.0F, 224.0F, "BEST", 0.75F, kColorMutedText);
            draw_text(357.0F, 224.0F, best_time, 0.75F, kColorText);
        }
        draw_text(
            109.0F,
            244.0F,
            "D PAD NODE  X SOLO  SQUARE HOST  TRIANGLE JOIN  O BACK",
            0.75F,
            kColorText);
        if (!status.data_loaded) {
            draw_text(174.0F, 231.0F, "LEVEL DATA ERROR", 0.9F, kColorError);
        }
    } else if (status.transition_alpha <= 0.0F) {
        // Multiplayer is a PSP extension. Keep its entry points outside the
        // 640x480 source stage so the map itself can be compared pixel-wise.
        draw_text(3.0F, 192.0F, "ST NUM", 0.50F, kColorText);
        draw_text(425.0F, 192.0F, "SEL TIME", 0.50F, kColorText);
        draw_text(3.0F, 216.0F, "X SOLO", 0.55F, kColorText);
        draw_text(3.0F, 228.0F, "SQ HOST", 0.55F, kColorText);
        draw_text(425.0F, 216.0F, "TR JOIN", 0.55F, kColorText);
        draw_text(425.0F, 228.0F, "O BACK", 0.55F, kColorText);
        if (!status.data_loaded) {
            draw_text(3.0F, 204.0F, "DATA ERR", 0.55F, kColorError);
        }
    }
}

void PspRenderer::draw_network_overlay(const RenderStatus& status) noexcept {
    draw_screen_rect(0.0F, 0.0F, 480.0F, 272.0F, kColorPaused);
    draw_screen_rect(92.0F, 70.0F, 296.0F, 132.0F, kColorPanel);

    if (status.screen == UiScreen::NetworkError) {
        char error_text[11]{};
        format_error_code(status.error_code, error_text);
        draw_text(139.0F, 91.0F, "NETWORK ERROR", 2.0F, kColorError);
        draw_text(174.0F, 126.0F, error_text, 1.5F, kColorText);
        draw_text(174.0F, 169.0F, "O OR X BACK", 1.0F, kColorMutedText);
        return;
    }

    draw_text(
        status.host ? 174.0F : 162.0F,
        88.0F,
        status.host ? "AD HOC HOST" : "AD HOC CLIENT",
        1.5F,
        kColorText);

    if (status.screen == UiScreen::AdhocSynchronizing) {
        draw_text(168.0F, 124.0F, "SYNCHRONIZING", 1.0F, kColorConnected);
        draw_text(160.0F, 150.0F, "L SWAP ROLE", 1.0F, kColorMutedText);
    } else {
        draw_text(186.0F, 124.0F, "CONNECTING", 1.0F, kColorConnected);
    }
    draw_text(198.0F, 177.0F, "O CANCEL", 1.0F, kColorMutedText);
}

bool PspRenderer::draw_player_sprite(
    const game::PlayerState& player,
    const float contact_normal_x,
    const float contact_normal_y) noexcept {
    CharacterAnimation animation = CharacterAnimation::Idle;
    if (!player.grounded) {
        if (std::fabs(player.vx) > 2.0F * game::GameWorld::kTileSize) {
            animation = CharacterAnimation::Air;
        } else if (player.vy < -3.0F * game::GameWorld::kTileSize) {
            animation = CharacterAnimation::Jump;
        } else if (player.vy > 3.0F * game::GameWorld::kTileSize) {
            animation = CharacterAnimation::Fall;
        }
    } else if (std::fabs(player.vx) > 4.0F) {
        animation =
            player.on_ice ? CharacterAnimation::Ice : CharacterAnimation::Run;
    }

    const CharacterFrame* const frame =
        character_textures_.frame(player.id, animation, render_frame_);
    if (frame == nullptr) {
        return false;
    }
    const std::uint16_t* const texture =
        character_textures_.atlas_data(frame->atlas);
    const std::uint16_t texture_width =
        character_textures_.atlas_width(frame->atlas);
    const std::uint16_t texture_height =
        character_textures_.atlas_height(frame->atlas);
    if (texture == nullptr || texture_width == 0U || texture_height == 0U) {
        return false;
    }

    const float anchor_x = player.x + player.width * 0.5F;
    const float anchor_y = player.y + player.height
#ifdef FFI_FOREST_TEMPLE
        * 0.5F;
#else
        + 3.0F;
#endif
    const bool facing_right =
        animation == CharacterAnimation::Air ? player.vx > 0.0F
                                             : player.facing_right;
    const float ground_right_rotation =
        -std::atan2(-contact_normal_y, contact_normal_x) + kPi * 0.5F;
    const float ground_head_rotation =
        facing_right
            ? ground_right_rotation
            : std::atan2(-contact_normal_y, contact_normal_x) - kPi * 0.5F;
    const float velocity_angle = static_cast<float>(std::atan2(player.vy, player.vx));
    const float air_rotation =
        facing_right ? velocity_angle : -velocity_angle - kPi;
    const auto draw_glow = [this, &player, anchor_x, anchor_y, facing_right](
                               const CharacterAnimation component,
                               const float rotation) noexcept {
        return draw_character_component(
            player,
            component,
            anchor_x,
            anchor_y,
            facing_right,
            rotation,
            true);
    };
#ifdef FFI_FOREST_TEMPLE
    static_cast<void>(draw_glow(animation, 0.0F));
#else
    bool glow_drawn = true;
    if (animation == CharacterAnimation::Air) {
        glow_drawn =
            draw_glow(CharacterAnimation::Air, 0.0F) &&
            draw_glow(CharacterAnimation::AirHead, air_rotation);
    } else if (animation == CharacterAnimation::Run) {
        glow_drawn =
            draw_glow(CharacterAnimation::Run, 0.0F) &&
            draw_glow(CharacterAnimation::GroundHead, ground_head_rotation);
    } else if (animation == CharacterAnimation::Ice &&
               player.id == game::PlayerId::Fireboy) {
        glow_drawn =
            draw_glow(CharacterAnimation::Melt, ground_right_rotation) &&
            draw_glow(CharacterAnimation::Ice, 0.0F) &&
            draw_glow(CharacterAnimation::GroundHead, ground_head_rotation);
    } else if (animation == CharacterAnimation::Ice) {
        glow_drawn =
            draw_glow(CharacterAnimation::Ice, 0.0F) &&
            draw_glow(CharacterAnimation::GroundHead, ground_head_rotation) &&
            draw_glow(CharacterAnimation::IceEffect, 0.0F);
    } else {
        glow_drawn = draw_glow(animation, 0.0F);
    }
    if (!glow_drawn) {
        return false;
    }
    if (animation == CharacterAnimation::Ice &&
        player.id == game::PlayerId::Fireboy &&
        !draw_character_component(
            player,
            CharacterAnimation::Melt,
            anchor_x,
            anchor_y,
            facing_right,
            ground_right_rotation)) {
        return false;
    }
#endif
    const float local_left =
        facing_right
            ? -static_cast<float>(frame->pivot_x)
            : -static_cast<float>(frame->width - frame->pivot_x);
    const float local_right =
        facing_right
            ? static_cast<float>(frame->width - frame->pivot_x)
            : static_cast<float>(frame->pivot_x);
    const float left =
        kWorldOffsetX + (anchor_x + local_left) * kWorldScale;
    const float top =
        (anchor_y - static_cast<float>(frame->pivot_y)) * kWorldScale;
    const float right =
        kWorldOffsetX + (anchor_x + local_right) * kWorldScale;
    const float bottom =
        (anchor_y - static_cast<float>(frame->pivot_y) +
         static_cast<float>(frame->height)) *
        kWorldScale;

    const float inset_u = frame->width > 1U ? 0.5F : 0.0F;
    const float inset_v = frame->height > 1U ? 0.5F : 0.0F;
    float left_u = static_cast<float>(frame->x) + inset_u;
    float right_u =
        static_cast<float>(frame->x + frame->width) - inset_u;
    if (!facing_right) {
        std::swap(left_u, right_u);
    }
    const float top_v = static_cast<float>(frame->y) + inset_v;
    const float bottom_v =
        static_cast<float>(frame->y + frame->height) - inset_v;

    bind_texture(
        texture,
        texture_width,
        texture_height,
        false,
        TextureFilter::Nearest);

    auto* vertices =
        static_cast<TexturedVertex*>(sceGuGetMemory(2 * sizeof(TexturedVertex)));
    vertices[0] = TexturedVertex{left_u, top_v, left, top, 0.0F};
    vertices[1] = TexturedVertex{right_u, bottom_v, right, bottom, 0.0F};
    sceGuDrawArray(
        GU_SPRITES,
        GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
        2,
        nullptr,
        vertices);
    unbind_texture();
#ifdef FFI_FOREST_TEMPLE
    return true;
#endif
    if (animation == CharacterAnimation::Air) {
        return draw_character_component(
            player,
            CharacterAnimation::AirHead,
            anchor_x,
            anchor_y,
            facing_right,
            air_rotation);
    }
    if (animation == CharacterAnimation::Run ||
        animation == CharacterAnimation::Ice) {
        if (!draw_character_component(
                player,
                CharacterAnimation::GroundHead,
                anchor_x,
                anchor_y,
                facing_right,
                ground_head_rotation)) {
            return false;
        }
        if (animation == CharacterAnimation::Ice &&
            player.id == game::PlayerId::Watergirl) {
            return draw_character_component(
                player,
                CharacterAnimation::IceEffect,
                anchor_x,
                anchor_y,
                facing_right,
                0.0F);
        }
    }
    return true;
}

bool PspRenderer::draw_character_component(
    const game::PlayerState& player,
    const CharacterAnimation animation,
    const float anchor_x,
    const float anchor_y,
    const bool facing_right,
    const float rotation,
    const bool glow) noexcept {
    const CharacterFrame* const frame = character_textures_.frame(
        player.id,
        animation,
        render_frame_);
    if (frame == nullptr) {
        return false;
    }
    const std::uint16_t* const texture =
        character_textures_.atlas_data(frame->atlas);
    const std::uint16_t texture_width =
        character_textures_.atlas_width(frame->atlas);
    const std::uint16_t texture_height =
        character_textures_.atlas_height(frame->atlas);
    if (texture == nullptr || texture_width == 0U || texture_height == 0U) {
        return false;
    }

    const std::uint16_t frame_x = glow ? frame->glow_x : frame->x;
    const std::uint16_t frame_y = glow ? frame->glow_y : frame->y;
    const std::uint16_t frame_width =
        glow ? frame->glow_width : frame->width;
    const std::uint16_t frame_height =
        glow ? frame->glow_height : frame->height;
    const std::int16_t pivot_x = glow ? frame->glow_pivot_x : frame->pivot_x;
    const std::int16_t pivot_y = glow ? frame->glow_pivot_y : frame->pivot_y;
    const std::int16_t rotation_pivot_x =
        glow ? frame->glow_rotation_pivot_x : frame->rotation_pivot_x;
    const std::int16_t rotation_pivot_y =
        glow ? frame->glow_rotation_pivot_y : frame->rotation_pivot_y;
    constexpr float kGlowTextureScale = 2.0F;
    const float geometry_scale = glow ? kGlowTextureScale : 1.0F;
    const float cosine = std::cos(rotation);
    const float sine = std::sin(rotation);
    const float facing_scale = facing_right ? 1.0F : -1.0F;
    const float origin_x =
        static_cast<float>(rotation_pivot_x - pivot_x) * geometry_scale;
    const float origin_y =
        static_cast<float>(rotation_pivot_y - pivot_y) * geometry_scale;
    const std::array<float, 4> local_x = {
        -static_cast<float>(rotation_pivot_x) * geometry_scale,
        static_cast<float>(frame_width - rotation_pivot_x) * geometry_scale,
        static_cast<float>(frame_width - rotation_pivot_x) * geometry_scale,
        -static_cast<float>(rotation_pivot_x) * geometry_scale,
    };
    const std::array<float, 4> local_y = {
        -static_cast<float>(rotation_pivot_y) * geometry_scale,
        -static_cast<float>(rotation_pivot_y) * geometry_scale,
        static_cast<float>(frame_height - rotation_pivot_y) * geometry_scale,
        static_cast<float>(frame_height - rotation_pivot_y) * geometry_scale,
    };
    const float inset_u = frame_width > 1U ? 0.5F : 0.0F;
    const float inset_v = frame_height > 1U ? 0.5F : 0.0F;
    const float left_u = static_cast<float>(frame_x) + inset_u;
    const float right_u =
        static_cast<float>(frame_x + frame_width) - inset_u;
    const float top_v = static_cast<float>(frame_y) + inset_v;
    const float bottom_v =
        static_cast<float>(frame_y + frame_height) - inset_v;
    const std::array<float, 4> texture_u = {
        left_u,
        right_u,
        right_u,
        left_u,
    };
    const std::array<float, 4> texture_v = {
        top_v,
        top_v,
        bottom_v,
        bottom_v,
    };

    bind_texture(
        texture,
        texture_width,
        texture_height,
        false,
        glow ? TextureFilter::Linear : TextureFilter::Nearest);
    auto* vertices = static_cast<TexturedVertex*>(
        sceGuGetMemory(4 * sizeof(TexturedVertex)));
    for (std::size_t index = 0; index < 4; ++index) {
        const float rotated_x =
            cosine * local_x[index] - sine * local_y[index];
        const float rotated_y =
            sine * local_x[index] + cosine * local_y[index];
        vertices[index] = TexturedVertex{
            texture_u[index],
            texture_v[index],
            kWorldOffsetX +
                (anchor_x + facing_scale * (origin_x + rotated_x)) *
                    kWorldScale,
            (anchor_y + origin_y + rotated_y) * kWorldScale,
            0.0F,
        };
    }
    sceGuDrawArray(
        GU_TRIANGLE_FAN,
        GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_2D,
        4,
        nullptr,
        vertices);
    unbind_texture();
    return true;
}

}  // namespace ffi::render
